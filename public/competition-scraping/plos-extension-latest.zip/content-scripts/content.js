var content=(function(){var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=(n,r,a)=>(a=n==null?{}:e(i(n)),s(r||!n||!n.__esModule?t(a,`default`,{value:n,enumerable:!0}):a,n));function l(e){return e}var u=class extends Error{status;constructor(e,t){super(t),this.status=e,this.name=`PlosApiError`}};async function d(e){let t;try{t=await chrome.runtime.sendMessage(e)}catch(e){throw new u(0,`Extension background unavailable — ${e instanceof Error?e.message:`Background did not respond`}`)}if(typeof t!=`object`||!t||!(`ok`in t))throw new u(0,`Malformed response from background`);let n=t;if(n.ok)return n.data;throw new u(n.error.status,n.error.message)}async function f(){return d({kind:`list-projects`})}async function p(e,t){return d({kind:`list-competitor-urls`,projectId:e,platform:t})}async function m(e,t){return d({kind:`list-captured-images`,projectId:e,urlId:t})}async function h(e,t){return d({kind:`list-captured-videos`,projectId:e,urlId:t})}async function g(e,t){return d({kind:`list-captured-texts`,projectId:e,urlId:t})}async function _(e,t){return d({kind:`create-competitor-url`,projectId:e,body:t})}async function v(e,t,n){return d({kind:`create-captured-text`,projectId:e,urlId:t,body:n})}async function y(e,t,n){return d({kind:`create-captured-review`,projectId:e,urlId:t,body:n})}async function b(e,t){return d({kind:`list-vocabulary`,projectId:e,vocabularyType:t})}async function x(e,t){return d({kind:`create-vocabulary-entry`,projectId:e,body:t})}async function S(e){return d({kind:`submit-image-capture`,projectId:e.projectId,urlId:e.urlId,srcUrl:e.srcUrl,request:e.request,finalize:e.finalize})}async function C(e){return e.sourceType===`DIRECT_BYTES`?d({kind:`submit-video-capture`,projectId:e.projectId,urlId:e.urlId,sourceType:`DIRECT_BYTES`,srcUrl:e.srcUrl,thumbnailDataUrl:e.thumbnailDataUrl,mimeTypeHint:e.mimeTypeHint,clientId:e.clientId,videoCategory:e.videoCategory,composition:e.composition,embeddedText:e.embeddedText,tags:e.tags,durationSeconds:e.durationSeconds,width:e.width,height:e.height}):d({kind:`submit-video-capture`,projectId:e.projectId,urlId:e.urlId,sourceType:`EMBED`,originalSrcUrl:e.originalSrcUrl,clientId:e.clientId,videoCategory:e.videoCategory,composition:e.composition,embeddedText:e.embeddedText,tags:e.tags})}async function w(){return d({kind:`capture-visible-tab`,format:`png`})}async function T(e){return d({kind:`submit-video-screen-recording-request-upload`,projectId:e.projectId,urlId:e.urlId,clientId:e.clientId,mimeType:e.mimeType,fileSize:e.fileSize})}async function E(e){return d({kind:`submit-video-screen-recording-finalize`,...e})}async function D(e={}){let t=e.minMs??1e3,n=e.maxMs??3e3,r=t+Math.random()*Math.max(0,n-t);return new Promise((t,n)=>{if(e.abortSignal?.aborted){n(O(`aborted before sleep`));return}let i=setTimeout(()=>{o(),t()},r),a=()=>{o(),clearTimeout(i),n(O(`aborted during sleep`))},o=()=>{e.abortSignal?.removeEventListener(`abort`,a)};e.abortSignal?.addEventListener(`abort`,a,{once:!0})})}function O(e){let t=Error(e);return t.name=`AbortError`,t}function k(e){return typeof e==`object`&&!!e&&`name`in e&&e.name===`AbortError`}var A=[`#captchacharacters`,`form[action*="validateCaptcha"]`,`img[src*="captcha"]`],j=[`iframe[src*="recaptcha"]`,`iframe[src*="hcaptcha"]`,`.g-recaptcha`,`.h-captcha`];function M(e){for(let t of e)try{if(document.querySelector(t))return!0}catch{}return!1}function N(e){return e===429||e===503}async function P(e){let t=[...e.captchaSelectors,...j];e.onProgress({kind:`starting`});let n=0,r=0;for(;;){if(e.abortSignal.aborted){let t={totalRowsCaptured:n,abortReason:`user-cancel`};return e.onProgress({kind:`aborted`,reason:`user-cancel`,totalRowsCaptured:n}),t}if(e.onProgress({kind:`page-loading`,pageIndex:r}),M(t))return e.onProgress({kind:`aborted`,reason:`captcha`,totalRowsCaptured:n,message:`Captcha detected. Finish the captcha in the tab then re-run the scrape.`}),{totalRowsCaptured:n,abortReason:`captcha`,abortMessage:`captcha detected`};let i=e.extractCurrentPageRows();e.onProgress({kind:`page-loaded`,pageIndex:r,rowsOnPage:i.length,totalRowsCaptured:n});for(let t of i){if(e.abortSignal.aborted)return e.onProgress({kind:`aborted`,reason:`user-cancel`,totalRowsCaptured:n}),{totalRowsCaptured:n,abortReason:`user-cancel`};if(n>=e.capRows)break;try{await e.saveRow(t)}catch(t){let r=F(t);return e.onProgress({kind:`aborted`,reason:r,totalRowsCaptured:n,message:I(t)??`Save failed.`}),{totalRowsCaptured:n,abortReason:r,abortMessage:I(t)}}n+=1,e.onProgress({kind:`row-saved`,totalRowsCaptured:n})}if(n>=e.capRows)break;try{await D({minMs:e.delayMinMs,maxMs:e.delayMaxMs,abortSignal:e.abortSignal})}catch(t){if(k(t))return e.onProgress({kind:`aborted`,reason:`user-cancel`,totalRowsCaptured:n}),{totalRowsCaptured:n,abortReason:`user-cancel`};throw t}let a;try{a=await e.advanceToNextPage(r)}catch(t){return k(t)?(e.onProgress({kind:`aborted`,reason:`user-cancel`,totalRowsCaptured:n}),{totalRowsCaptured:n,abortReason:`user-cancel`}):(e.onProgress({kind:`aborted`,reason:`error`,totalRowsCaptured:n,message:I(t)??`Pagination failed.`}),{totalRowsCaptured:n,abortReason:`error`,abortMessage:I(t)})}if(!a)break;r+=1}return e.onProgress({kind:`completed`,totalRowsCaptured:n}),{totalRowsCaptured:n}}function F(e){if(typeof e==`object`&&e){let t=e;if(typeof t.status==`number`&&N(t.status))return`rate-limit`;if(t.name===`AbortError`)return`user-cancel`}return`error`}function I(e){if(typeof e==`object`&&e&&`message`in e){let t=e.message;if(typeof t==`string`)return t}}var L=null,R=`
.plos-cs-scrape-indicator {
  position: fixed !important;
  top: 16px !important;
  right: 16px !important;
  min-width: 280px !important;
  max-width: 360px !important;
  background: #fff !important;
  color: #222 !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif !important;
  font-size: 13px !important;
  line-height: 1.4 !important;
  border-radius: 8px !important;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18) !important;
  padding: 12px 14px !important;
  z-index: 999998 !important;
  border: 1px solid #e0e0e0 !important;
}

.plos-cs-scrape-indicator-header {
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  margin-bottom: 6px !important;
}

.plos-cs-scrape-indicator-title {
  font-weight: 600 !important;
  font-size: 13px !important;
  color: #222 !important;
}

.plos-cs-scrape-indicator-close {
  background: none !important;
  border: none !important;
  color: #888 !important;
  font-size: 18px !important;
  line-height: 1 !important;
  cursor: pointer !important;
  padding: 0 4px !important;
}

.plos-cs-scrape-indicator-close:hover {
  color: #222 !important;
}

.plos-cs-scrape-indicator-status {
  color: #555 !important;
  margin-bottom: 6px !important;
}

.plos-cs-scrape-indicator-status.plos-cs-scrape-indicator-error {
  color: #c2185b !important;
  background: #ffebee !important;
  padding: 6px 8px !important;
  border-radius: 4px !important;
  margin-top: 4px !important;
}

.plos-cs-scrape-indicator-count {
  font-weight: 600 !important;
  color: #1976d2 !important;
  font-size: 16px !important;
  margin-bottom: 8px !important;
}

.plos-cs-scrape-indicator-breakdown {
  font-size: 12px !important;
  color: #555 !important;
  margin-bottom: 6px !important;
  letter-spacing: 0.2px !important;
}

.plos-cs-scrape-indicator-actions {
  display: flex !important;
  gap: 6px !important;
  justify-content: flex-end !important;
}

.plos-cs-scrape-indicator-button {
  font-family: inherit !important;
  font-size: 12px !important;
  padding: 6px 12px !important;
  border-radius: 4px !important;
  cursor: pointer !important;
  border: 1px solid #ccc !important;
  background: #fff !important;
  color: #555 !important;
}

.plos-cs-scrape-indicator-button:hover {
  background: #f5f5f5 !important;
}

.plos-cs-scrape-indicator-button-primary {
  background: #c62828 !important;
  border-color: #c62828 !important;
  color: #fff !important;
}

.plos-cs-scrape-indicator-button-primary:hover {
  background: #b71c1c !important;
}
`,z=3e3;function B(e){L&&=(L.destroy(),null);let t=document.createElement(`div`);t.setAttribute(`data-plos-cs-host`,`scrape-progress-indicator`),t.style.position=`fixed`,t.style.top=`0`,t.style.right=`0`,t.style.pointerEvents=`none`,t.style.zIndex=`999998`;let n=t.attachShadow({mode:`open`}),r=document.createElement(`style`);r.textContent=R,n.appendChild(r);let i=document.createElement(`div`);i.className=`plos-cs-scrape-indicator`,i.style.pointerEvents=`auto`;let a=document.createElement(`div`);a.className=`plos-cs-scrape-indicator-header`;let o=document.createElement(`div`);o.className=`plos-cs-scrape-indicator-title`,o.textContent=e.scopeLabel,a.appendChild(o);let s=document.createElement(`button`);s.className=`plos-cs-scrape-indicator-close`,s.setAttribute(`aria-label`,`Close progress indicator`),s.textContent=`×`,a.appendChild(s),i.appendChild(a);let c=document.createElement(`div`);c.className=`plos-cs-scrape-indicator-count`,c.textContent=`Starting…`,i.appendChild(c);let l=document.createElement(`div`);l.className=`plos-cs-scrape-indicator-breakdown`,l.style.display=`none`,i.appendChild(l);let u=document.createElement(`div`);u.className=`plos-cs-scrape-indicator-status`,u.textContent=``,i.appendChild(u);let d=document.createElement(`div`);d.className=`plos-cs-scrape-indicator-actions`;let f=document.createElement(`button`);f.className=`plos-cs-scrape-indicator-button plos-cs-scrape-indicator-button-primary`,f.textContent=`Cancel`,d.appendChild(f),i.appendChild(d),n.appendChild(i),document.body.appendChild(t);let p=!1,m=null,h=!1,g=new Map,_=null;function v(){if(g.size===0){l.style.display=`none`;return}let e=[];for(let[t,n]of g)n===null?e.push(`${String(t)}★: …`):e.push(`${String(t)}★: ${String(n)}`);l.textContent=e.join(`  ·  `),l.style.display=`block`}function y(){p||(p=!0,m!==null&&(clearTimeout(m),m=null),t.parentNode&&t.parentNode.removeChild(t),L===S&&(L=null))}function b(){if(!h){h=!0;try{e.onCancel()}catch(e){console.error(`[plos] scrape progress indicator onCancel threw:`,e)}u.textContent=`Cancelling…`,f.setAttribute(`disabled`,`true`),f.style.opacity=`0.6`}}s.addEventListener(`click`,()=>{b(),y()}),f.addEventListener(`click`,()=>{b()});function x(e){if(!p)switch(e.kind){case`starting`:c.textContent=`Starting…`,u.textContent=``;break;case`page-loading`:u.textContent=`${e.starContext?`${e.starContext} — `:``}Loading page ${String(e.pageIndex+1)}…`;break;case`page-loaded`:u.textContent=`${e.starContext?`${e.starContext} — `:``}Page ${String(e.pageIndex+1)} — ${String(e.rowsOnPage)} reviews on this page`,c.textContent=`${String(e.totalRowsCaptured)} reviews captured`;break;case`row-saved`:c.textContent=`${String(e.totalRowsCaptured)} reviews captured`;break;case`star-started`:_=e.starRating,g.set(e.starRating,null),v();break;case`star-completed`:g.set(e.starRating,e.rowsForStar),_===e.starRating&&(_=null),c.textContent=`${String(e.totalRowsCaptured)} reviews captured`,v();break;case`completed`:c.textContent=`${String(e.totalRowsCaptured)} reviews captured`,u.textContent=`Done.`,u.classList.remove(`plos-cs-scrape-indicator-error`),f.textContent=`Close`,f.removeAttribute(`disabled`),f.style.opacity=`1`,m=setTimeout(()=>{y()},z);break;case`aborted`:c.textContent=`${String(e.totalRowsCaptured)} reviews captured`,e.reason===`user-cancel`?(u.textContent=`Cancelled.`,u.classList.remove(`plos-cs-scrape-indicator-error`),m=setTimeout(()=>{y()},z)):(u.textContent=e.message??V(e.reason),u.classList.add(`plos-cs-scrape-indicator-error`),f.textContent=`Close`,f.removeAttribute(`disabled`),f.style.opacity=`1`);break}}let S={update:x,destroy:y};return L=S,S}function V(e){switch(e){case`captcha`:return`Captcha detected. Finish it in the tab and re-run the scrape.`;case`rate-limit`:return`The site is rate-limiting requests. Wait a few minutes and try again.`;case`error`:return`Something went wrong during the scrape.`;default:return`Stopped (${e}).`}}var H=/^https?:\/\/(www\.)?amazon\.com\//,U=/\/product-reviews\/([A-Z0-9]{10})\b/,W=/\/dp\/([A-Z0-9]{10})\b/,G=200,K=[`one_star`,`two_star`,`three_star`,`four_star`,`five_star`];function q(e){switch(e){case`one_star`:return 1;case`two_star`:return 2;case`three_star`:return 3;case`four_star`:return 4;case`five_star`:return 5}}function J(e){switch(e){case 1:return`one_star`;case 2:return`two_star`;case 3:return`three_star`;case 4:return`four_star`;case 5:return`five_star`;default:return null}}function Y(e,t,n=1){return`https://www.amazon.com/product-reviews/${e}/?filterByStar=${t}&pageNumber=${String(n)}`}function X(e){return`https://www.amazon.com/dp/${e}/`}function Z(e){return H.test(e)&&U.test(e)}function Q(e){return H.test(e)&&W.test(e)}function ee(e){return Z(e)||Q(e)}function te(e){let t=e.match(U);return t?t[1]??null:null}function ne(e){let t=e.match(W);return t?t[1]??null:null}function re(e){return te(e)??ne(e)}function ie(e,t){let n=re(e);return n?re(t)===n:!1}function ae(e){let t=e.match(/(\d+(?:\.\d+)?)\s+out\s+of/i);if(!t)return null;let n=parseFloat(t[1]??``);if(!Number.isFinite(n))return null;let r=Math.round(n);return r<1||r>5?null:r}function oe(e){let t=e.trim();if(/^one person/i.test(t))return 1;let n=t.match(/^(\d[\d,]*)\s+(?:people|person)/i);if(!n)return null;let r=parseInt((n[1]??``).replace(/,/g,``),10);return Number.isFinite(r)?r:null}function se(e){let t=e.match(/on\s+([A-Za-z]+\s+\d{1,2},\s+\d{4})/);if(!t)return null;let n=new Date(t[1]??``);return Number.isNaN(n.getTime())?null:n.toISOString()}function ce(e){let t=Array.from(e.querySelectorAll(`[data-hook="review"]`)),n=[];for(let e of t){let t=ae(e.querySelector(`[data-hook="review-star-rating"] .a-icon-alt`)?.textContent?.trim()??e.querySelector(`[data-hook="cmps-review-star-rating"] .a-icon-alt`)?.textContent?.trim()??``);if(t===null)continue;let r=(e.querySelector(`[data-hook="review-body"] span`)??e.querySelector(`[data-hook="review-body"]`))?.textContent?.trim()??``;if(!r)continue;let i=e.querySelector(`[data-hook="review-title"]`),a=null;i&&(a=Array.from(i.querySelectorAll(`span`)).find(e=>(e.textContent??``).trim().length>0&&!/out of \d+ stars/i.test(e.textContent??``))?.textContent?.trim()??i.textContent?.trim()??null,a&&a.length===0&&(a=null));let o=e.querySelector(`.a-profile-name`)?.textContent?.trim()||null,s=e.querySelector(`[data-hook="review-date"]`)?.textContent?.trim()??``,c=s?se(s):null,l=e.querySelector(`[data-hook="helpful-vote-statement"]`)?.textContent?.trim()??``,u=l?oe(l):null;n.push({starRating:t,body:r,title:a,reviewerName:o,reviewDate:c,helpfulCount:u})}return n}function le(e){return[...e].sort((e,t)=>{let n=e.helpfulCount??-1;return(t.helpfulCount??-1)-n})}function ue(e){for(let t of[`[data-hook="cr-insights-widget"]`,`#cr-summarization-attributes`,`[data-hook="cr-product-insights-block"]`,`#cr-summary-content`]){let n=e.querySelector(t);if(!n)continue;let r=n.textContent?.trim()??``;if(r.length>0)return r}return null}async function de(e){let t=new AbortController,n=B({scopeLabel:e.scopeLabel,onCancel:()=>t.abort()}),r=e=>n.update(e),i=e.capPerStar&&e.capPerStar>0?e.capPerStar:G,a=e.starsToVisit&&e.starsToVisit.length>0?e.starsToVisit:K,o={},s=0,c,l,u=!1;try{starLoop:for(let n of a){if(t.signal.aborted){c=`user-cancel`;break}let a=q(n);r({kind:`star-started`,starRating:a});let u=await fe({ctx:e,filter:n,capPerStar:i,controller:t,onProgress:r,startingRowOffset:s});if(o[n]=u.inserted,s+=u.inserted,r({kind:`star-completed`,starRating:a,rowsForStar:u.inserted,totalRowsCaptured:s}),u.abortReason!==void 0){c=u.abortReason,l=u.abortMessage;break starLoop}}if(c===void 0&&!t.signal.aborted)try{u=await pe({ctx:e,controller:t,totalInsertedSoFar:s,onProgress:r}),u&&(s+=1)}catch(e){console.warn(`[PLOS] Customers-say block capture failed:`,e)}return c===void 0&&r({kind:`completed`,totalRowsCaptured:s}),{inserted:s,insertedByStar:o,customersSayInserted:u,abortReason:c,abortMessage:l}}catch(e){return n.update({kind:`aborted`,reason:`error`,totalRowsCaptured:s,message:e instanceof Error?e.message:`Unexpected error`}),{inserted:s,insertedByStar:o,customersSayInserted:u,abortReason:`error`,abortMessage:e instanceof Error?e.message:`Unexpected error`}}}async function fe(e){let{ctx:t,filter:n,capPerStar:r,controller:i,onProgress:a,startingRowOffset:o}=e,s=q(n),c=null;Y(t.asin,n,1);let l=1,u=!0,d=[],f=`${String(s)}★`,p=await P({onProgress:e=>{e.kind===`page-loaded`?a({...e,starContext:f,totalRowsCaptured:o+e.totalRowsCaptured}):e.kind===`row-saved`?a({...e,totalRowsCaptured:o+e.totalRowsCaptured}):e.kind===`page-loading`?a({...e,starContext:f}):e.kind===`aborted`||e.kind===`completed`||a(e)},abortSignal:i.signal,captchaSelectors:[...A],capRows:r,extractCurrentPageRows:()=>c?ce(c):[],advanceToNextPage:async()=>{let e;u?(e=1,u=!1):e=l+1;let r=Y(t.asin,n,e),a=await fetch(r,{credentials:`include`,headers:{Accept:`text/html`},signal:i.signal});if(!a.ok){let e=Error(`Amazon per-star fetch returned ${String(a.status)} for ${n}`);throw e.status=a.status,e}let o=await a.text();return c=new DOMParser().parseFromString(o,`text/html`),l=e,ce(c).length!==0},saveRow:async e=>{d.push(e)}}),m=le(d),h=0;for(let e of m){if(i.signal.aborted)break;try{await t.saveReview({clientId:he(),starRating:e.starRating||s,body:e.body,title:e.title,reviewerName:e.reviewerName,reviewDate:e.reviewDate,helpfulCount:e.helpfulCount,platform:`amazon`,source:`extension-scrape`}),h+=1}catch(e){let t=me(e);return{inserted:h,abortReason:t,abortMessage:e instanceof Error?e.message:void 0}}}return{inserted:h,abortReason:p.abortReason,abortMessage:p.abortMessage}}async function pe(e){let{ctx:t,controller:n,totalInsertedSoFar:r,onProgress:i}=e,a=X(t.asin);i({kind:`page-loading`,pageIndex:9999});let o=await fetch(a,{credentials:`include`,headers:{Accept:`text/html`},signal:n.signal});if(!o.ok)return!1;let s=await o.text(),c=ue(new DOMParser().parseFromString(s,`text/html`));return c?(await t.saveReview({clientId:he(),starRating:5,body:c,title:`Customers say`,reviewerName:null,reviewDate:null,helpfulCount:null,platform:`amazon`,source:`extension-scrape:customers-say`}),i({kind:`row-saved`,totalRowsCaptured:r+1}),!0):!1}function me(e){if(typeof e==`object`&&e){let t=e;if(typeof t.status==`number`&&(t.status===429||t.status===503))return`rate-limit`;if(t.name===`AbortError`)return`user-cancel`}return`error`}function he(){return crypto.randomUUID()}var ge=/^https?:\/\/(www\.)?ebay\.com\//,_e=/\/itm\/(\d+)\b/,ve=/\/fdbk\/mweb_profile\b/,ye=200,be=[`NEUTRAL`,`NEGATIVE`];function xe(e){return e===`NEUTRAL`?3:1}function Se(e){return e===3?`NEUTRAL`:e===1?`NEGATIVE`:null}function Ce(e,t,n,r=1){return`https://www.ebay.com/fdbk/mweb_profile?${new URLSearchParams({fdbkType:`FeedbackReceivedAsSeller`,item_id:e,username:t,q:e,filter:`feedback_page:RECEIVED_AS_SELLER`,page_id_item:String(r),overall_rating_item:n,sort_item:`RELEVANCEV2`,filter_image_item:`false`,filter_video_item:`false`,filter_automated_feedback_item:`true`,filter_topic_item:``}).toString()}`}function we(e){return`https://www.ebay.com/itm/${e}`}function Te(e){return ge.test(e)&&_e.test(e)}function Ee(e){return ge.test(e)&&ve.test(e)}function De(e){return Te(e)||Ee(e)}function Oe(e){let t=e.match(_e);return t?t[1]??null:null}function ke(e){try{let t=new URL(e);if(!ve.test(t.pathname))return null;let n=t.searchParams.get(`item_id`);return n&&/^\d+$/.test(n)?n:null}catch{return null}}function Ae(e){return Oe(e)??ke(e)}function je(e){try{let t=new URL(e);if(!ve.test(t.pathname))return null;let n=t.searchParams.get(`username`);return n&&n.length>0?n:null}catch{return null}}function Me(e,t){let n=Ae(e);return n?Ae(t)===n:!1}function Ne(e){let t=e.querySelector(`[role=tabpanel]:not([hidden])`)??e,n=[`.fdbk-container`,`.fdbk-container__details`,`li.feedback-list-table-row`,`[data-test-id*="feedback-item"]`],r=[];for(let e of n)if(r=Array.from(t.querySelectorAll(e)),r.length>0)break;let i=[];for(let e of r){let t=Pe(e);if(!t)continue;let n=Fe(e),r=Ie(e);i.push({body:t,reviewerName:n,reviewDate:r})}return i}function Pe(e){for(let t of[`.fdbk-container__details__comment`,`.feedback-comment-text`,`[data-test-id*="feedback-comment"]`]){let n=e.querySelector(t)?.textContent?.trim()??``;if(n.length>0)return n}return``}function Fe(e){for(let t of[`.fdbk-container__details__user`,`.feedback-user`,`[data-test-id*="feedback-user"]`]){let n=e.querySelector(t)?.textContent?.trim()??``;if(n.length>0)return n}return null}function Ie(e){for(let t of[`.fdbk-container__details__date`,`.feedback-date`,`[data-test-id*="feedback-date"]`]){let n=e.querySelector(t)?.textContent?.trim()??``;if(n.length!==0)return Le(n)??n}return null}function Le(e){let t=e.trim();if(t.length===0||/^past\s/i.test(t))return null;let n=new Date(t);return Number.isNaN(n.getTime())?null:n.toISOString()}function Re(e){let t=e.match(/"sellerUserName":"([^"]+)"/);if(!t)return null;let n=t[1];return!n||n.length===0?null:n.replace(/\\u([0-9a-fA-F]{4})/g,(e,t)=>String.fromCharCode(parseInt(t,16)))}function ze(e){for(let t of[`[data-testid="x-sellercard-atf"] a[href*="/usr/"]`,`.x-sellercard-atf__info a[href*="/usr/"]`,`.ux-textspans a[href*="/usr/"]`]){let n=Be(e.querySelector(t));if(n)return n}let t=Array.from(e.querySelectorAll(`a[href*="/usr/"]`));for(let e of t){let t=Be(e);if(t)return t}return null}function Be(e){if(!e)return null;let t=e.getAttribute(`href`);if(!t)return null;let n=t.match(/\/usr\/([^/?#]+)/);if(!n)return null;let r=n[1];if(!r)return null;try{return decodeURIComponent(r)}catch{return r}}async function Ve(e){let t=new AbortController,n=B({scopeLabel:e.scopeLabel,onCancel:()=>t.abort()}),r=e=>n.update(e),i=e.capPerFilter&&e.capPerFilter>0?e.capPerFilter:ye,a=e.filtersToVisit&&e.filtersToVisit.length>0?e.filtersToVisit:be,o={},s=0,c,l;try{filterLoop:for(let n of a){if(t.signal.aborted){c=`user-cancel`;break}let a=xe(n);r({kind:`star-started`,starRating:a});let u=await He({ctx:e,filter:n,capPerFilter:i,controller:t,onProgress:r,startingRowOffset:s});if(o[n]=u.inserted,s+=u.inserted,r({kind:`star-completed`,starRating:a,rowsForStar:u.inserted,totalRowsCaptured:s}),u.abortReason!==void 0){c=u.abortReason,l=u.abortMessage;break filterLoop}}return c===void 0&&r({kind:`completed`,totalRowsCaptured:s}),{inserted:s,insertedByFilter:o,abortReason:c,abortMessage:l}}catch(e){return n.update({kind:`aborted`,reason:`error`,totalRowsCaptured:s,message:e instanceof Error?e.message:`Unexpected error`}),{inserted:s,insertedByFilter:o,abortReason:`error`,abortMessage:e instanceof Error?e.message:`Unexpected error`}}}async function He(e){let{ctx:t,filter:n,capPerFilter:r,controller:i,onProgress:a,startingRowOffset:o}=e,s=xe(n),c=null,l=1,u=!0,d=`${String(s)}★`,f=await P({onProgress:e=>{e.kind===`page-loaded`?a({...e,starContext:d,totalRowsCaptured:o+e.totalRowsCaptured}):e.kind===`row-saved`?a({...e,totalRowsCaptured:o+e.totalRowsCaptured}):e.kind===`page-loading`?a({...e,starContext:d}):e.kind===`aborted`||e.kind===`completed`||a(e)},abortSignal:i.signal,captchaSelectors:[`#captcha-image`,`form[action*="ebay.com/sec/captcha"]`,`img[src*="captcha"]`],capRows:r,extractCurrentPageRows:()=>c?Ne(c):[],advanceToNextPage:async()=>{let e;u?(e=1,u=!1):e=l+1;let r=Ce(t.itemId,t.seller,n,e),a=await fetch(r,{credentials:`include`,headers:{Accept:`text/html`},signal:i.signal});if(!a.ok){let e=Error(`eBay per-filter fetch returned ${String(a.status)} for ${n}`);throw e.status=a.status,e}let o=await a.text();return c=new DOMParser().parseFromString(o,`text/html`),l=e,Ne(c).length!==0},saveRow:async e=>{try{await t.saveReview({clientId:Ue(),starRating:s,body:e.body,title:null,reviewerName:e.reviewerName,reviewDate:e.reviewDate,helpfulCount:null,platform:`ebay`,source:`extension-scrape`})}catch(e){throw e}}});return{inserted:f.totalRowsCaptured,abortReason:f.abortReason,abortMessage:f.abortMessage}}function Ue(){return crypto.randomUUID()}var We=/^https?:\/\/(www\.)?etsy\.com\//,Ge=/\/listing\/(\d+)\b/,Ke=200,qe=8e3,Je=8e3,Ye=200,Xe=400,Ze=[1,2,3,4,5],Qe=[3,2,1];function $e(e){return e===1||e===2||e===3||e===4||e===5}function et(e){return We.test(e)&&Ge.test(e)}function tt(e){return et(e)}function nt(e){let t=e.match(Ge);return t?t[1]??null:null}function rt(e){return nt(e)}function it(e,t){let n=rt(e);return n?rt(t)===n:!1}function at(e){let t=Array.from(e.querySelectorAll(`.deep-dive-sheet`));for(let e of t)if(e.getAttribute(`aria-hidden`)!==`true`&&!(e.getAttribute(`class`)??``).split(/\s+/).includes(`wt-display-none`)&&!e.hasAttribute(`hidden`))return e;return null}function ot(e){return e.querySelector(`[data-deep-dive-reviews-container="true"]`)}function st(e,t){return e.querySelector(`[data-reviews-histogram="true"] button[data-rating-value="${String(t)}"]`)}function ct(e){return e.getAttribute(`aria-disabled`)===`true`||e.hasAttribute(`disabled`)}function lt(e){let t=e.querySelector(`nav[aria-label="Pagination of reviews"], nav[data-clg-id="WtPagination"]`);if(!t)return null;let n=Array.from(t.querySelectorAll(`button`));for(let e of n)if((e.querySelector(`.wt-screen-reader-only`)?.textContent?.trim()??``)===`Next`)return e;return null}function ut(e){return e.getAttribute(`aria-disabled`)===`true`||e.hasAttribute(`disabled`)}function dt(e){let t=`view all reviews for this item`,n=Array.from(e.querySelectorAll(`button, a`));for(let e of n)if((e.textContent??``).trim().toLowerCase()===t)return e;for(let e of n)if((e.textContent??``).trim().toLowerCase().startsWith(t))return e;for(let e of n)if((e.textContent??``).trim().toLowerCase().startsWith(`view all reviews`))return e;return null}function ft(e){let t=ot(e);if(!t)return[];let n=Array.from(t.querySelectorAll(`[data-review-region]`)),r=[];for(let e of n){let t=pt(e);if(!t)continue;let n=mt(e),i=ht(e),a=gt(e),o=e.getAttribute(`data-review-region`);r.push({body:t,reviewerName:n,reviewDate:i,starRating:a,reviewRegionId:o})}return r}function pt(e){for(let t of[`.wt-text-body`,`.shop-review-card__text`,`.review-text`]){let n=e.querySelector(t)?.textContent?.trim()??``;if(n.length>0)return n}return``}function mt(e){let t=e.querySelector(`a[href*="/people/"]`)?.textContent?.trim()??``;return t.length>0?t:null}function ht(e){let t=e.querySelector(`a[href*="/people/"]`);if(t?.parentElement){let e=Array.from(t.parentElement.children);for(let n of e){if(n===t||n.tagName!==`SPAN`)continue;let e=n.textContent?.trim()??``;if(e.length===0)continue;let r=vt(e);if(r)return r;if(/\d{4}/.test(e)||/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\b/i.test(e))return e}}for(let t of[`.wt-text-body-small--tight.wt-sem-text-secondary`,`.shop-review-card__date`,`.review-date`,`time`]){let n=e.querySelector(t),r=n?.dateTime;if(r){let e=vt(r);if(e)return e}let i=n?.textContent?.trim()??``;if(i.length!==0)return vt(i)??i}return null}function gt(e){let t=e.querySelector(`[role="img"][aria-label^="Rating:"]`)?.getAttribute(`aria-label`)?.trim()??``;if(t.length>0){let e=t.match(/Rating:\s*(\d+(?:\.\d+)?)/i);if(e){let t=parseFloat(e[1]??``);if(Number.isFinite(t)){let e=Math.round(t);if(e>=1&&e<=5)return e}}}let n=Array.from(e.querySelectorAll(`[aria-label]`));for(let e of n){let t=_t(e.getAttribute(`aria-label`)?.trim()??``);if(t!==null)return t}return null}function _t(e){let t=e.trim();if(t.length===0)return null;let n=t.match(/(\d+(?:\.\d+)?)\s*(?:out of \d+\s*)?stars?/i);if(!n)return null;let r=parseFloat(n[1]??``);if(!Number.isFinite(r))return null;let i=Math.round(r);return i<1||i>5?null:i}function vt(e){let t=e.trim();if(t.length===0)return null;let n=t.replace(/^Reviewed\s+/i,``),r=new Date(n);return Number.isNaN(r.getTime())?null:r.toISOString()}async function yt(e,t=document){let n=new AbortController,r=B({scopeLabel:e.scopeLabel,onCancel:()=>n.abort()}),i=e=>r.update(e),a=e.capPerStar&&e.capPerStar>0?e.capPerStar:Ke,o=e.starsToVisit&&e.starsToVisit.length>0?e.starsToVisit:Qe.filter($e),s={},c=[],l=0,u,d;i({kind:`starting`});try{let r=at(t);if(!r){let e=dt(t);if(!e){let e=`Couldn't find the 'View all reviews for this item' button on the listing page. Etsy may have changed the listing layout; re-load the page and try again.`;return i({kind:`aborted`,reason:`error`,totalRowsCaptured:0,message:e}),{inserted:0,insertedByStar:s,skippedStars:c,abortReason:`error`,abortMessage:e}}bt(e),r=await St(t,n.signal)}starLoop:for(let t of o){if(n.signal.aborted){u=`user-cancel`;break}if(M([...j,`#captcha`,`img[src*="captcha"]`])){u=`captcha`,d=`Captcha detected. Finish the captcha in the tab then re-run the scrape.`;break}i({kind:`star-started`,starRating:t});let o=st(r,t);if(!o){c.push(t),i({kind:`star-completed`,starRating:t,rowsForStar:0,totalRowsCaptured:l});continue}if(ct(o)){c.push(t),i({kind:`star-completed`,starRating:t,rowsForStar:0,totalRowsCaptured:l});continue}let f=xt(r);try{await D({abortSignal:n.signal})}catch{u=`user-cancel`;break}bt(o);try{await Ct(r,f,n.signal)}catch(e){if(n.signal.aborted){u=`user-cancel`;break}let r=e instanceof Error?e.message:`wait failed`;u=`error`,d=`Etsy ${String(t)}★ filter content didn't load: ${r}`;break}let p=1,m=0;for(;;){if(n.signal.aborted){u=`user-cancel`;break starLoop}i({kind:`page-loading`,pageIndex:p,starContext:`${String(t)}★`});let o=ft(r);i({kind:`page-loaded`,pageIndex:p,rowsOnPage:o.length,totalRowsCaptured:l,starContext:`${String(t)}★`});for(let r of o){if(n.signal.aborted){u=`user-cancel`;break starLoop}if(m>=a)break;try{await e.saveReview({clientId:Dt(),starRating:r.starRating??t,body:r.body,title:null,reviewerName:r.reviewerName,reviewDate:r.reviewDate,helpfulCount:null,platform:`etsy`,source:`extension-scrape`}),m+=1,l+=1,i({kind:`row-saved`,totalRowsCaptured:l})}catch(e){let t=Tt(e);t===429||t===503?u=`rate-limit`:Et(e)===`AbortError`?u=`user-cancel`:(u=`error`,d=e instanceof Error?e.message:`save failed`);break starLoop}}if(m>=a)break;let s=lt(r);if(!s||ut(s))break;let c=xt(r);try{await D({abortSignal:n.signal})}catch{u=`user-cancel`;break starLoop}bt(s);try{await Ct(r,c,n.signal)}catch{if(n.signal.aborted){u=`user-cancel`;break starLoop}break}p+=1}s[t]=m,i({kind:`star-completed`,starRating:t,rowsForStar:m,totalRowsCaptured:l})}return i(u===void 0?{kind:`completed`,totalRowsCaptured:l}:{kind:`aborted`,reason:u,totalRowsCaptured:l,message:d}),{inserted:l,insertedByStar:s,skippedStars:c,abortReason:u,abortMessage:d}}catch(e){let t=e instanceof Error?e.message:`Unexpected error`;return r.update({kind:`aborted`,reason:`error`,totalRowsCaptured:l,message:t}),{inserted:l,insertedByStar:s,skippedStars:c,abortReason:`error`,abortMessage:t}}}function bt(e){e.click()}function xt(e){let t=ot(e);return t?t.querySelector(`[data-review-region]`)?.getAttribute(`data-review-region`)??null:null}async function St(e,t){let n=Date.now();for(;;){if(t.aborted){let e=Error(`aborted while waiting for overlay`);throw e.name=`AbortError`,e}let r=at(e);if(r)return await wt(Xe),r;if(Date.now()-n>qe)throw Error(`timed out waiting for review overlay to open`);await wt(Ye)}}async function Ct(e,t,n){let r=Date.now(),i=0;for(;;){if(n.aborted){let e=Error(`aborted while waiting for reviews swap`);throw e.name=`AbortError`,e}let a=xt(e);if(a!==null&&a!==t){await wt(Xe);return}if(a===null&&(i+=1,i>=3)){await wt(Xe);return}if(Date.now()-r>Je)throw Error(`timed out waiting for reviews content swap`);await wt(Ye)}}function wt(e){return new Promise(t=>setTimeout(t,e))}function Tt(e){if(typeof e==`object`&&e){let t=e.status;if(typeof t==`number`)return t}}function Et(e){if(typeof e==`object`&&e){let t=e.name;if(typeof t==`string`)return t}}function Dt(){return crypto.randomUUID()}var Ot=/^https?:\/\/(www\.)?walmart\.com\//,kt=/\/ip\/(?:[^/?#]+\/)?(\d+)\b/,At=/\/reviews\/product\/(\d+)\b/,jt=200,Mt=[1,2,3,4,5],Nt=[5,4,3,2,1];function Pt(e){return e===1||e===2||e===3||e===4||e===5}function Ft(e){return Ot.test(e)&&kt.test(e)}function It(e){return Ot.test(e)&&At.test(e)}function Lt(e){return Ft(e)||It(e)}function Rt(e){let t=e.match(kt);return t?t[1]??null:null}function zt(e){let t=e.match(At);return t?t[1]??null:null}function Bt(e){return Rt(e)??zt(e)}function Vt(e,t){let n=Bt(e);return n?Bt(t)===n:!1}function Ht(e,t,n=1){return`https://www.walmart.com/reviews/product/${e}?${new URLSearchParams({ratings:String(t),page:String(n)}).toString()}`}function Ut(e){let t=e.match(/(\d+(?:\.\d+)?)\s*out\s+of\s+5/i);if(!t)return null;let n=parseFloat(t[1]??``);if(!Number.isFinite(n))return null;let r=Math.round(n);return r<1||r>5?null:r}function Wt(e){let t=e.trim();if(t.length===0)return null;let n=new Date(t);return Number.isNaN(n.getTime())?null:n.toISOString()}function Gt(e){let t=Array.from(e.querySelectorAll(`[data-testid="enhanced-review-content"]`)),n=[];for(let e of t){let t=e.closest(`.overflow-visible`);if(!t)continue;let r=Kt(t);if(r===null)continue;let i=Jt(e);if(!i)continue;let a=qt(t),o=Yt(t),s=Xt(t);n.push({starRating:r,body:i,title:a,reviewerName:o,reviewDate:s})}return n}function Kt(e){let t=e.querySelector(`.ld_Ec`);return t?Ut(t.textContent??``):null}function qt(e){let t=e.querySelector(`h3`)?.textContent?.trim()??``;return t.length>0?t:null}function Jt(e){return e.querySelector(`p`)?.textContent?.trim()??``}function Yt(e){let t=/\b(review|purchase|rating|upvote|downvote)\b/i,n=Array.from(e.querySelectorAll(`[aria-label]`));for(let e of n){if(e.tagName.toLowerCase()===`button`)continue;let n=e.getAttribute(`aria-label`)??``;if(n&&!t.test(n))return n}return null}function Xt(e){let t=e.querySelector(`.f7.gray`)?.textContent?.trim()??``;return t.length===0?null:Wt(t)??t}async function Zt(e){let t=new AbortController,n=B({scopeLabel:e.scopeLabel,onCancel:()=>t.abort()}),r=e=>n.update(e),i=e.capPerStar&&e.capPerStar>0?e.capPerStar:jt,a=e.starsToVisit&&e.starsToVisit.length>0?e.starsToVisit:[5,4,3,2,1],o={},s=0,c,l;try{starLoop:for(let n of a){if(t.signal.aborted){c=`user-cancel`;break}r({kind:`star-started`,starRating:n});let a=await Qt({ctx:e,starFilter:n,capPerStar:i,controller:t,onProgress:r,startingRowOffset:s});if(o[n]=a.inserted,s+=a.inserted,r({kind:`star-completed`,starRating:n,rowsForStar:a.inserted,totalRowsCaptured:s}),a.abortReason!==void 0){c=a.abortReason,l=a.abortMessage;break starLoop}}return c===void 0&&r({kind:`completed`,totalRowsCaptured:s}),{inserted:s,insertedByStar:o,abortReason:c,abortMessage:l}}catch(e){return n.update({kind:`aborted`,reason:`error`,totalRowsCaptured:s,message:e instanceof Error?e.message:`Unexpected error`}),{inserted:s,insertedByStar:o,abortReason:`error`,abortMessage:e instanceof Error?e.message:`Unexpected error`}}}async function Qt(e){let{ctx:t,starFilter:n,capPerStar:r,controller:i,onProgress:a,startingRowOffset:o}=e,s=null,c=1,l=!0,u=`${String(n)}★`,d=await P({onProgress:e=>{e.kind===`page-loaded`?a({...e,starContext:u,totalRowsCaptured:o+e.totalRowsCaptured}):e.kind===`row-saved`?a({...e,totalRowsCaptured:o+e.totalRowsCaptured}):e.kind===`page-loading`?a({...e,starContext:u}):e.kind===`aborted`||e.kind===`completed`||a(e)},abortSignal:i.signal,captchaSelectors:[`#px-captcha`,`div[id*="px-captcha"]`,`iframe[src*="perimeterx"]`],capRows:r,extractCurrentPageRows:()=>s?Gt(s):[],advanceToNextPage:async()=>{let e;l?(e=1,l=!1):e=c+1;let r=Ht(t.productId,n,e),a=await fetch(r,{credentials:`include`,headers:{Accept:`text/html`},signal:i.signal});if(!a.ok){let e=Error(`Walmart per-star fetch returned ${String(a.status)} for ${String(n)}★`);throw e.status=a.status,e}let o=await a.text();return s=new DOMParser().parseFromString(o,`text/html`),c=e,Gt(s).length!==0},saveRow:async e=>{try{await t.saveReview({clientId:$t(),starRating:e.starRating,body:e.body,title:e.title,reviewerName:e.reviewerName,reviewDate:e.reviewDate,helpfulCount:null,platform:`walmart`,source:`extension-scrape`})}catch(e){throw e}}});return{inserted:d.totalRowsCaptured,abortReason:d.abortReason,abortMessage:d.abortMessage}}function $t(){return crypto.randomUUID()}var en=1,tn=5e3,nn=[1,2,3,4,5];function rn(e){return sn(),new Promise(t=>{let n=document.createElement(`div`);n.setAttribute(`data-plos-cs-host`,`scrape-trigger-modal`),n.style.position=`fixed`,n.style.inset=`0`,n.style.zIndex=`999999`;let r=n.attachShadow({mode:`open`}),i=document.createElement(`style`);i.textContent=ln,r.appendChild(i);let a=document.createElement(`div`);a.className=`plos-cs-scrape-trigger-backdrop`;let o=document.createElement(`div`);o.className=`plos-cs-scrape-trigger-card`;let s=document.createElement(`div`);s.className=`plos-cs-scrape-trigger-header`;let c=document.createElement(`div`);c.className=`plos-cs-scrape-trigger-title`,c.textContent=e.scopeLabel,s.appendChild(c),o.appendChild(s);let l=document.createElement(`div`);l.className=`plos-cs-scrape-trigger-sub`,l.textContent=`Review scrape settings`,o.appendChild(l);let u=e.selectableStars&&e.selectableStars.length>0?[...e.selectableStars].sort((e,t)=>e-t):nn,d=new Set(e.defaultSelectedStars&&e.defaultSelectedStars.length>0?e.defaultSelectedStars:u),f=null;if(e.sellerInput){let t=document.createElement(`label`);if(t.className=`plos-cs-scrape-trigger-field-label`,t.textContent=e.sellerInput.label,f=document.createElement(`input`),f.className=`plos-cs-scrape-trigger-input`,f.type=`text`,f.value=e.sellerInput.defaultValue,f.setAttribute(`aria-label`,e.sellerInput.label),e.sellerInput.placeholder&&(f.placeholder=e.sellerInput.placeholder),t.appendChild(f),o.appendChild(t),e.sellerInput.hint){let t=document.createElement(`div`);t.className=`plos-cs-scrape-trigger-hint`,t.textContent=e.sellerInput.hint,o.appendChild(t)}}let p=document.createElement(`div`);p.className=`plos-cs-scrape-trigger-field-label`,p.textContent=`Stars to scrape`,o.appendChild(p);let m=document.createElement(`div`);m.className=`plos-cs-scrape-trigger-stars-row`;let h=new Map;for(let e of u){let t=document.createElement(`label`);t.className=`plos-cs-scrape-trigger-star-checkbox`;let n=document.createElement(`input`);n.type=`checkbox`,n.checked=d.has(e),n.setAttribute(`aria-label`,`${String(e)}-star reviews`);let r=document.createElement(`span`);r.textContent=`${String(e)}★`,t.appendChild(n),t.appendChild(r),m.appendChild(t),h.set(e,n)}o.appendChild(m);let g=document.createElement(`label`);g.className=`plos-cs-scrape-trigger-field-label`,g.textContent=`Per-star cap (1 – 5000)`,o.appendChild(g);let _=document.createElement(`input`);_.className=`plos-cs-scrape-trigger-input`,_.type=`number`,_.min=String(en),_.max=String(tn),_.step=`1`,_.value=String(cn(e.defaultCapPerStar)),_.setAttribute(`aria-label`,`Per-star cap`),g.appendChild(_);let v=document.createElement(`div`);v.className=`plos-cs-scrape-trigger-hint`,v.textContent=`Visits each checked star filter and scrapes up to this many reviews per filter. Saved per-URL value pre-fills the cap; override here for this one run only.`,o.appendChild(v);let y=document.createElement(`div`);y.className=`plos-cs-scrape-trigger-actions`;let b=document.createElement(`button`);b.type=`button`,b.className=`plos-cs-scrape-trigger-button`,b.textContent=`Cancel`;let x=document.createElement(`button`);x.type=`button`,x.className=`plos-cs-scrape-trigger-button plos-cs-scrape-trigger-button-primary`,x.textContent=`Start scrape`,y.appendChild(b),y.appendChild(x),o.appendChild(y),a.appendChild(o),r.appendChild(a),document.body.appendChild(n);let S=!1;function C(e){S||(S=!0,w(),t(e))}function w(){n.parentNode&&n.parentNode.removeChild(n),document.removeEventListener(`keydown`,j,!0),an===n&&(an=null)}function T(){let t=parseInt(_.value,10);return cn(Number.isFinite(t)?t:e.defaultCapPerStar)}function E(){let e=[];for(let[t,n]of h)n.checked&&e.push(t);return e.sort((e,t)=>e-t)}function D(){return f?.value.trim()??``}function O(){let e=E().length>0,t=f===null||D().length>0;e&&t?(x.removeAttribute(`disabled`),x.style.opacity=`1`,x.style.cursor=`pointer`):(x.setAttribute(`disabled`,`true`),x.style.opacity=`0.5`,x.style.cursor=`not-allowed`)}for(let e of h.values())e.addEventListener(`change`,O);f&&f.addEventListener(`input`,O);function k(){let e=E();if(e.length===0)return;let t=f?D():void 0;if(f&&!t)return;let n={capPerStar:T(),selectedStars:e};t&&(n.seller=t),C(n)}function A(){C(null)}function j(e){if(e.key===`Escape`){e.preventDefault(),A();return}e.key===`Enter`&&r.activeElement===_&&(e.preventDefault(),k())}a.addEventListener(`click`,e=>{e.target===a&&A()}),x.addEventListener(`click`,k),b.addEventListener(`click`,A),document.addEventListener(`keydown`,j,!0),O(),an=n,on=w,setTimeout(()=>{try{_.focus(),_.select()}catch{}},0)})}var an=null,on=null;function sn(){on&&=(on(),null),an=null}function cn(e){if(!Number.isFinite(e))return 200;let t=Math.floor(e);return t<en?en:t>tn?tn:t}var ln=`
.plos-cs-scrape-trigger-backdrop {
  position: fixed !important;
  inset: 0 !important;
  background: rgba(0, 0, 0, 0.45) !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
}

.plos-cs-scrape-trigger-card {
  background: #fff !important;
  color: #222 !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif !important;
  font-size: 13px !important;
  line-height: 1.4 !important;
  border-radius: 10px !important;
  box-shadow: 0 16px 48px rgba(0, 0, 0, 0.28) !important;
  padding: 20px 22px !important;
  min-width: 340px !important;
  max-width: 420px !important;
  border: 1px solid #ddd !important;
}

.plos-cs-scrape-trigger-header {
  margin-bottom: 4px !important;
}

.plos-cs-scrape-trigger-title {
  font-weight: 600 !important;
  font-size: 15px !important;
  color: #222 !important;
}

.plos-cs-scrape-trigger-sub {
  color: #777 !important;
  font-size: 12px !important;
  margin-bottom: 14px !important;
}

.plos-cs-scrape-trigger-field-label {
  display: block !important;
  font-weight: 600 !important;
  font-size: 12px !important;
  color: #444 !important;
  margin-bottom: 12px !important;
}

.plos-cs-scrape-trigger-stars-row {
  display: flex !important;
  gap: 12px !important;
  flex-wrap: wrap !important;
  margin-bottom: 16px !important;
  margin-top: -6px !important;
}

.plos-cs-scrape-trigger-star-checkbox {
  display: inline-flex !important;
  align-items: center !important;
  gap: 4px !important;
  font-size: 13px !important;
  color: #333 !important;
  cursor: pointer !important;
  user-select: none !important;
  font-weight: 500 !important;
}

.plos-cs-scrape-trigger-star-checkbox input[type="checkbox"] {
  cursor: pointer !important;
  width: 14px !important;
  height: 14px !important;
  margin: 0 !important;
}

.plos-cs-scrape-trigger-input {
  display: block !important;
  margin-top: 6px !important;
  width: 100% !important;
  padding: 8px 10px !important;
  font-family: inherit !important;
  font-size: 14px !important;
  border-radius: 6px !important;
  border: 1px solid #c2c2c2 !important;
  box-sizing: border-box !important;
}

.plos-cs-scrape-trigger-input:focus {
  outline: none !important;
  border-color: #1976d2 !important;
  box-shadow: 0 0 0 3px rgba(25, 118, 210, 0.18) !important;
}

.plos-cs-scrape-trigger-hint {
  font-size: 12px !important;
  color: #777 !important;
  margin-bottom: 16px !important;
}

.plos-cs-scrape-trigger-actions {
  display: flex !important;
  gap: 8px !important;
  justify-content: flex-end !important;
}

.plos-cs-scrape-trigger-button {
  font-family: inherit !important;
  font-size: 13px !important;
  padding: 8px 16px !important;
  border-radius: 6px !important;
  cursor: pointer !important;
  border: 1px solid #c2c2c2 !important;
  background: #fff !important;
  color: #444 !important;
}

.plos-cs-scrape-trigger-button:hover {
  background: #f5f5f5 !important;
}

.plos-cs-scrape-trigger-button-primary {
  background: #1976d2 !important;
  border-color: #1976d2 !important;
  color: #fff !important;
}

.plos-cs-scrape-trigger-button-primary:hover {
  background: #1565c0 !important;
}
`,un=`selectedProjectId`,dn=`selectedPlatform`,fn=`highlightTerms:`;function pn(){return typeof chrome<`u`&&chrome.storage?.local?chrome.storage.local:null}function mn(e){return`${fn}${e}`}async function hn(){let e=pn();if(!e)return null;let t=(await e.get(un))[un];return typeof t==`string`?t:null}async function gn(){let e=pn();if(!e)return null;let t=(await e.get(dn))[dn];return typeof t==`string`?t:null}async function _n(e){let t=pn();if(!t)return[];let n=mn(e),r=(await t.get(n))[n];return Array.isArray(r)?r.filter(e=>typeof e==`object`&&!!e&&typeof e.term==`string`&&typeof e.color==`string`):[]}var vn=/\/(?:dp|gp\/product)\/([A-Z0-9]{10})(?=\/|$|\?|#)/,yn=`/sspa/click`;function bn(e){let t;try{t=new URL(e)}catch{return null}if(t.pathname!==yn)return null;let n=t.searchParams.get(`url`);return!n||n.length===0?null:`${t.protocol}//${t.host}${n}`}var xn={platform:`amazon`,hostnames:[`amazon.com`],matchesProduct(e){if(typeof e!=`string`||e.length===0)return!1;if(vn.test(e))return!0;let t=bn(e);return!!(t!==null&&vn.test(t))},canonicalProductUrl(e){if(typeof e!=`string`||e.length===0)return null;let t=e.match(vn);if(t){let n;try{n=new URL(e)}catch{return null}return`${n.protocol}//${n.host}/dp/${t[1]}`}let n=bn(e);if(n!==null){let e=n.match(vn);if(e){let t;try{t=new URL(n)}catch{return null}return`${t.protocol}//${t.host}/dp/${e[1]}`}}return null},detectsAsSponsored(e){if(typeof e!=`string`||e.length===0)return!1;let t=bn(e);return t===null?!1:vn.test(t)}},Sn=/\/itm\/(?:[^/?#]+\/)?(\d{8,})(?=\/|$|\?|#)/,Cn={platform:`ebay`,hostnames:[`ebay.com`],matchesProduct(e){return typeof e!=`string`||e.length===0?!1:Sn.test(e)},canonicalProductUrl(e){if(typeof e!=`string`||e.length===0)return null;let t=e.match(Sn);if(!t)return null;let n;try{n=new URL(e)}catch{return null}return`${n.protocol}//${n.host}/itm/${t[1]}`}},wn=/\/listing\/(\d+)(?=\/|$|\?|#)/,Tn={platform:`etsy`,hostnames:[`etsy.com`],matchesProduct(e){return typeof e!=`string`||e.length===0?!1:wn.test(e)},canonicalProductUrl(e){if(typeof e!=`string`||e.length===0)return null;let t=e.match(wn);if(!t)return null;let n;try{n=new URL(e)}catch{return null}let r=n.pathname.indexOf(`/listing/`);if(r===-1)return null;let i=`${n.pathname.slice(0,r)}/listing/${t[1]}`;return`${n.protocol}//${n.host}${i}`}},En=/\/ip\/(?:[^/?#]+\/)?(\d+)(?=\/|$|\?|#)/,Dn=[xn,Cn,Tn,{platform:`walmart`,hostnames:[`walmart.com`],matchesProduct(e){return typeof e!=`string`||e.length===0?!1:En.test(e)},canonicalProductUrl(e){if(typeof e!=`string`||e.length===0)return null;let t=e.match(En);if(!t)return null;let n;try{n=new URL(e)}catch{return null}return`${n.protocol}//${n.host}/ip/${t[1]}`}}];function On(e){return typeof e!=`string`||e.length===0?null:Dn.find(t=>t.platform===e)??null}function kn(e){if(typeof e!=`string`||e.length===0)return null;let t=e.toLowerCase();return Dn.find(e=>e.hostnames.some(e=>t===e||t.endsWith(`.${e}`)))??null}function An(e){if(typeof e!=`string`||e.length===0)return``;let t=e.indexOf(`?`);return t===-1?e:e.slice(0,t)}function jn(e,t){let n=new Set;for(let r of e){let e=r?.url,i=An(typeof e==`string`&&t?t(e)??e:e);i!==``&&n.add(i)}return n}var Mn=`
.plos-cs-form-backdrop {
  position: fixed !important;
  inset: 0 !important;
  background: rgba(0, 0, 0, 0.45) !important;
  z-index: 999998 !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  padding: 16px !important;
}

.plos-cs-form {
  width: 100% !important;
  max-width: 480px !important;
  max-height: calc(100vh - 32px) !important;
  overflow-y: auto !important;
  background: #fff !important;
  color: #222 !important;
  font-size: 14px !important;
  line-height: 1.4 !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif !important;
  border-radius: 8px !important;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25) !important;
  padding: 20px !important;
  z-index: 999999 !important;
}

.plos-cs-form-title {
  font-size: 16px !important;
  font-weight: 600 !important;
  margin: 0 0 12px 0 !important;
  color: #222 !important;
}

.plos-cs-form-context {
  display: flex !important;
  flex-direction: column !important;
  gap: 4px !important;
  font-size: 12px !important;
  color: #555 !important;
  margin-bottom: 12px !important;
  padding: 8px 10px !important;
  background: #f5f5f5 !important;
  border-radius: 4px !important;
}

.plos-cs-form-context strong {
  color: #222 !important;
}

.plos-cs-form-field {
  display: flex !important;
  flex-direction: column !important;
  gap: 4px !important;
  margin-bottom: 10px !important;
}

.plos-cs-form-label {
  font-size: 12px !important;
  font-weight: 500 !important;
  color: #555 !important;
}

.plos-cs-form-input,
.plos-cs-form-textarea {
  font-family: inherit !important;
  font-size: 14px !important;
  color: #222 !important;
  background: #fff !important;
  padding: 8px 10px !important;
  border: 1px solid #ccc !important;
  border-radius: 4px !important;
  outline: none !important;
  width: 100% !important;
  box-sizing: border-box !important;
}

.plos-cs-form-input:focus,
.plos-cs-form-textarea:focus {
  border-color: #1976d2 !important;
}

.plos-cs-form-actions {
  display: flex !important;
  gap: 8px !important;
  justify-content: flex-end !important;
  margin-top: 16px !important;
}

.plos-cs-form-button {
  font-family: inherit !important;
  font-size: 14px !important;
  padding: 8px 14px !important;
  border-radius: 4px !important;
  cursor: pointer !important;
  border: 1px solid transparent !important;
}

.plos-cs-form-button-primary {
  background: #1976d2 !important;
  color: #fff !important;
}

.plos-cs-form-button-primary:disabled {
  background: #90caf9 !important;
  cursor: not-allowed !important;
}

.plos-cs-form-button-secondary {
  background: #fff !important;
  color: #555 !important;
  border-color: #ccc !important;
}

.plos-cs-form-error {
  margin-top: 8px !important;
  padding: 8px 10px !important;
  background: #ffebee !important;
  color: #c2185b !important;
  font-size: 13px !important;
  border-radius: 4px !important;
}

/* P-6 — Sponsored Ad checkbox row in the URL-add form. Inline-aligned with
   a small gap between the box and label so the click-target is the entire
   row (label is bound to the input via htmlFor). */
.plos-cs-form-field-checkbox {
  flex-direction: row !important;
  align-items: center !important;
  gap: 8px !important;
}

.plos-cs-form-checkbox-label {
  display: inline-flex !important;
  align-items: center !important;
  gap: 8px !important;
  font-size: 13px !important;
  font-weight: 500 !important;
  color: #444 !important;
  cursor: pointer !important;
  user-select: none !important;
}

.plos-cs-form-checkbox {
  width: 16px !important;
  height: 16px !important;
  margin: 0 !important;
  cursor: pointer !important;
  accent-color: #1976d2 !important;
}

/* Module 2 text-capture form — session 4 (2026-05-11).
   Reuses the existing form chrome (.plos-cs-form*, .plos-cs-form-input,
   .plos-cs-form-textarea, .plos-cs-form-button*, .plos-cs-form-error).
   New surfaces below: <select> dropdown, loading-status banner, the
   inline "add new category" input, and the tags chip-list. */
.plos-cs-form-select {
  font-family: inherit !important;
  font-size: 14px !important;
  color: #222 !important;
  background: #fff !important;
  padding: 8px 10px !important;
  border: 1px solid #ccc !important;
  border-radius: 4px !important;
  outline: none !important;
  width: 100% !important;
  box-sizing: border-box !important;
  cursor: pointer !important;
}

.plos-cs-form-select:focus {
  border-color: #1976d2 !important;
}

.plos-cs-form-select:disabled {
  background: #f5f5f5 !important;
  color: #888 !important;
  cursor: not-allowed !important;
}

.plos-cs-form-status {
  margin: 4px 0 12px !important;
  padding: 8px 10px !important;
  background: #e3f2fd !important;
  color: #1565c0 !important;
  font-size: 13px !important;
  border-radius: 4px !important;
}

.plos-cs-form-inline-add {
  margin-top: 6px !important;
}

.plos-cs-chip-row {
  display: flex !important;
  flex-wrap: wrap !important;
  gap: 6px !important;
  margin-bottom: 6px !important;
  min-height: 0 !important;
}

.plos-cs-chip {
  display: inline-flex !important;
  align-items: center !important;
  gap: 4px !important;
  padding: 3px 4px 3px 10px !important;
  background: #e8f0fe !important;
  color: #1a3a6c !important;
  font-size: 12px !important;
  border-radius: 12px !important;
  line-height: 1 !important;
}

.plos-cs-chip-remove {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  width: 18px !important;
  height: 18px !important;
  padding: 0 !important;
  border: none !important;
  background: rgba(26, 58, 108, 0.12) !important;
  color: #1a3a6c !important;
  border-radius: 50% !important;
  cursor: pointer !important;
  font-size: 14px !important;
  line-height: 1 !important;
}

.plos-cs-chip-remove:hover {
  background: rgba(26, 58, 108, 0.25) !important;
}

/* Module 2 image-capture form — session 5 (2026-05-12-i).
   Image preview block sits between the saved-URL picker and the category
   picker; bordered + max-height-clamped so a tall image doesn't push the
   Save button below the fold. Object-fit: contain so portrait/landscape
   images render uncropped. */
.plos-cs-form-image-preview-wrap {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  gap: 6px !important;
  margin-bottom: 10px !important;
  padding: 10px !important;
  background: #f9fafb !important;
  border: 1px solid #e5e7eb !important;
  border-radius: 4px !important;
}

.plos-cs-form-image-preview {
  display: block !important;
  max-width: 100% !important;
  max-height: 200px !important;
  width: auto !important;
  height: auto !important;
  object-fit: contain !important;
  background: #fff !important;
  border-radius: 3px !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06) !important;
}

.plos-cs-form-image-meta {
  font-size: 11px !important;
  color: #6b7280 !important;
  text-align: center !important;
  word-break: break-all !important;
  line-height: 1.3 !important;
}

.plos-cs-form-image-meta-failed {
  font-size: 11px !important;
  color: #c2185b !important;
  text-align: center !important;
}
`,Nn=`
.plos-cs-add-button {
  position: fixed !important;
  width: 24px !important;
  height: 24px !important;
  padding: 0 !important;
  margin: 0 !important;
  background: #1976d2 !important;
  color: #fff !important;
  font-size: 16px !important;
  line-height: 24px !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif !important;
  font-weight: 700 !important;
  text-align: center !important;
  border: 2px solid #fff !important;
  border-radius: 50% !important;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2) !important;
  cursor: pointer !important;
  z-index: 999990 !important;
  opacity: 0.85 !important;
  transition: opacity 120ms ease, transform 120ms ease !important;
  user-select: none !important;
}

.plos-cs-add-button:hover {
  opacity: 1 !important;
  transform: scale(1.1) !important;
}

.plos-cs-add-button-dismiss {
  position: fixed !important;
  width: 14px !important;
  height: 14px !important;
  padding: 0 !important;
  margin: 0 !important;
  background: #c2185b !important;
  color: #fff !important;
  font-size: 11px !important;
  line-height: 14px !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif !important;
  font-weight: 700 !important;
  text-align: center !important;
  border: 1px solid #fff !important;
  border-radius: 50% !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2) !important;
  cursor: pointer !important;
  z-index: 999990 !important;
  user-select: none !important;
}

.plos-cs-saved-icon {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  width: 28px !important;
  height: 28px !important;
  margin-right: 6px !important;
  background: #16a34a !important;
  color: #fff !important;
  font-size: 18px !important;
  line-height: 1 !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif !important;
  font-weight: 900 !important;
  text-align: center !important;
  border: 3px solid #fff !important;
  border-radius: 50% !important;
  box-shadow: 0 0 0 2px #16a34a, 0 3px 8px rgba(0, 0, 0, 0.4) !important;
  vertical-align: middle !important;
  user-select: none !important;
  flex-shrink: 0 !important;
  position: relative !important;
  z-index: 999990 !important;
}

.plos-cs-saved-image-icon,
.plos-cs-saved-video-icon {
  position: fixed !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  width: 28px !important;
  height: 28px !important;
  background: #16a34a !important;
  color: #fff !important;
  font-size: 18px !important;
  line-height: 1 !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif !important;
  font-weight: 900 !important;
  text-align: center !important;
  border: 3px solid #fff !important;
  border-radius: 50% !important;
  box-shadow: 0 0 0 2px #16a34a, 0 3px 8px rgba(0, 0, 0, 0.4) !important;
  user-select: none !important;
  pointer-events: none !important;
  z-index: 999990 !important;
}

/* P-25 saved-text haze. Renders via the CSS Custom Highlight API on the
   plos-cs-saved-text highlight registry (see saved-text-highlight.ts).
   Light-yellow background + faint underline gives a subtle already-
   saved cue that does not compete with the host page own text styling.
   The pseudo-element is non-DOM-modifying so the haze sits above the
   text without affecting layout. */
::highlight(plos-cs-saved-text) {
  background-color: rgba(255, 235, 59, 0.32) !important;
  text-decoration: underline dotted rgba(120, 80, 0, 0.45) !important;
}

.plos-cs-overlay-banner {
  position: fixed !important;
  top: 12px !important;
  right: 12px !important;
  padding: 10px 14px !important;
  background: #388e3c !important;
  color: #fff !important;
  font-size: 13px !important;
  line-height: 1.3 !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif !important;
  font-weight: 500 !important;
  border-radius: 6px !important;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.18) !important;
  z-index: 999990 !important;
  display: flex !important;
  align-items: center !important;
  gap: 8px !important;
  max-width: 320px !important;
  user-select: none !important;
}

.plos-cs-overlay-banner-close {
  background: transparent !important;
  color: #fff !important;
  border: none !important;
  font-size: 16px !important;
  line-height: 1 !important;
  cursor: pointer !important;
  padding: 0 !important;
  margin: 0 !important;
  opacity: 0.85 !important;
}

.plos-cs-overlay-banner-close:hover {
  opacity: 1 !important;
}

${Mn}

/* Live-page Highlight Terms — P-5 fix 2026-05-08-d.
   background-color + color are set inline per-term via the user's chosen
   palette entry; the rules here only handle layout/display so the inline
   color choices come through cleanly. We deliberately do NOT use
   !important on background/color so the inline style wins; everything
   else stays !important to defend against host-page CSS resetters. */
.plos-cs-highlight {
  display: inline !important;
  padding: 0 2px !important;
  margin: 0 !important;
  border-radius: 2px !important;
  font: inherit !important;
  text-decoration: inherit !important;
  vertical-align: baseline !important;
  /* background-color + color are set inline. */
}

/* ── Module 2 region-screenshot overlay (session 6 2026-05-13) ─────────
   Full-viewport transparent layer that captures the user's drag-rectangle.
   z-index sits above .plos-cs-form-backdrop so the overlay can be armed
   without interference from a stray open form (defensive — the
   orchestrator dismisses any open form before arming the overlay anyway).

   Layout: a single fixed-position container fills the viewport. Inside it,
   a top-pinned banner shows the always-visible hint copy. The drag rectangle
   itself is a child <div> whose dimensions follow the user's mouse during
   drag; the four sides outside the rectangle are rendered as four sibling
   <div>s with the dim background to give the "dim outside" effect described
   in STACK_DECISIONS §4. */
.plos-cs-region-screenshot-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: 2147483646;
  cursor: crosshair;
  /* Capture all pointer events even on top of host-page elements. */
  pointer-events: auto;
  /* No background here — the dim is provided by the four "outside" panels
     so the rectangle interior stays fully visible during drag. */
  background: transparent;
  /* Avoid the iframe-isolation gotcha — overlay should sit above any
     z-index:auto positioned host content but below browser chrome. */
}

.plos-cs-region-screenshot-banner {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  padding: 10px 14px;
  background: rgba(20, 20, 24, 0.92);
  color: #ffffff;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
    Helvetica, Arial, sans-serif;
  font-size: 13px;
  line-height: 1.4;
  text-align: center;
  /* The banner is informational, not interactive — let drags pass through
     when the user starts above it. */
  pointer-events: none;
}

.plos-cs-region-screenshot-banner kbd {
  display: inline-block;
  padding: 1px 6px;
  margin: 0 2px;
  background: rgba(255, 255, 255, 0.15);
  border-radius: 3px;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
    Helvetica, Arial, sans-serif;
  font-size: 12px;
}

/* The four "outside" panels — top / right / bottom / left — that dim the
   regions outside the user's drag rectangle. While the user is mid-drag,
   the overlay updates each panel's position so they collectively wrap the
   rectangle. Before the user starts dragging, only the top panel covers
   the whole viewport (the rectangle is hidden). */
.plos-cs-region-screenshot-dim {
  position: absolute;
  background: rgba(20, 20, 24, 0.42);
  pointer-events: none;
}

.plos-cs-region-screenshot-rect {
  position: absolute;
  border: 2px solid #ffffff;
  box-shadow:
    inset 0 0 0 1px rgba(0, 0, 0, 0.5),
    0 0 0 1px rgba(0, 0, 0, 0.5);
  /* No fill — the host-page content shows through the rectangle interior. */
  background: transparent;
  pointer-events: none;
}

/* "Processing…" state while we round-trip captureVisibleTab + crop.
   Replaces the rectangle + dim panels with a centered spinner-ish copy so
   the user knows something is happening. */
.plos-cs-region-screenshot-processing {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  padding: 16px 22px;
  background: rgba(20, 20, 24, 0.92);
  color: #ffffff;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
    Helvetica, Arial, sans-serif;
  font-size: 13px;
  line-height: 1.4;
  border-radius: 6px;
  pointer-events: none;
}

/* ── P-45 Build #1b — region-record overlay (2026-05-22) ───────────────────
   Forked from .plos-cs-region-screenshot-overlay — same layout primitives
   (fixed full-viewport container, crosshair cursor, banner, four dim
   panels, drag rectangle). Distinct class prefix so the two overlays can
   coexist in the stylesheet without selector collisions. */
.plos-cs-video-region-record-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: 2147483646;
  cursor: crosshair;
  pointer-events: auto;
  background: transparent;
}

.plos-cs-video-region-record-banner {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  padding: 10px 14px;
  background: rgba(20, 20, 24, 0.92);
  color: #ffffff;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
    Helvetica, Arial, sans-serif;
  font-size: 13px;
  line-height: 1.4;
  text-align: center;
  pointer-events: none;
}

.plos-cs-video-region-record-banner kbd {
  display: inline-block;
  padding: 1px 6px;
  margin: 0 2px;
  background: rgba(255, 255, 255, 0.15);
  border-radius: 3px;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
    Helvetica, Arial, sans-serif;
  font-size: 12px;
}

.plos-cs-video-region-record-dim {
  position: absolute;
  background: rgba(20, 20, 24, 0.42);
  pointer-events: none;
}

.plos-cs-video-region-record-rect {
  position: absolute;
  border: 2px solid #ffffff;
  box-shadow:
    inset 0 0 0 1px rgba(0, 0, 0, 0.5),
    0 0 0 1px rgba(0, 0, 0, 0.5);
  background: transparent;
  pointer-events: none;
}

/* ── P-45 Build #1b — recording indicator (2026-05-22) ─────────────────────
   Two synchronized UI elements that live during the recording itself
   (after the overlay closes + Chrome's "Choose what to share" dialog
   resolves):
   - .plos-cs-recording-indicator-region: an absolutely-positioned thin
     dashed border at the user's drawn rectangle. pointer-events: none so
     the user can still interact with the page below.
   - .plos-cs-recording-indicator-toolbar: a top-center floating bar with
     the REC badge, countdown, Stop button, Cancel button. */
.plos-cs-recording-indicator-region {
  position: absolute;
  z-index: 2147483646;
  pointer-events: none;
  background: transparent;
  box-sizing: border-box;
}

.plos-cs-recording-indicator-region--preparing {
  border: 2px dashed #888888;
}

.plos-cs-recording-indicator-region--recording {
  border: 2px dashed #dd0000;
  box-shadow:
    inset 0 0 0 1px rgba(0, 0, 0, 0.35),
    0 0 0 1px rgba(0, 0, 0, 0.35);
}

.plos-cs-recording-indicator-toolbar {
  position: fixed;
  top: 12px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 2147483646;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  background: rgba(20, 20, 24, 0.94);
  color: #ffffff;
  border-radius: 8px;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
    Helvetica, Arial, sans-serif;
  font-size: 13px;
  line-height: 1.2;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.35);
}

.plos-cs-recording-indicator-badge {
  display: inline-flex;
  align-items: center;
  padding: 3px 9px;
  background: #dd0000;
  color: #ffffff;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.3px;
  animation: plos-cs-rec-pulse 1.4s ease-in-out infinite;
}

.plos-cs-recording-indicator-badge--preparing {
  background: #555555;
  animation: none;
}

@keyframes plos-cs-rec-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.55; }
}

.plos-cs-recording-indicator-countdown {
  font-variant-numeric: tabular-nums;
  letter-spacing: 0.3px;
}

.plos-cs-recording-indicator-stop {
  padding: 5px 12px;
  background: #dd0000;
  color: #ffffff;
  border: none;
  border-radius: 4px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
}

.plos-cs-recording-indicator-stop:hover {
  background: #b90000;
}

.plos-cs-recording-indicator-cancel {
  padding: 5px 8px;
  background: transparent;
  color: #cccccc;
  border: none;
  font-size: 12px;
  cursor: pointer;
}

.plos-cs-recording-indicator-cancel:hover {
  color: #ffffff;
}
`,Pn=`plos-cs-styles`;function Fn(){if(document.getElementById(Pn))return;let e=document.createElement(`style`);e.id=Pn,e.textContent=Nn,document.head.appendChild(e)}var In=300,Ln=150;function Rn(e){let t=document.createElement(`button`);t.type=`button`,t.className=`plos-cs-add-button`,t.setAttribute(`aria-label`,`Add this URL to PLOS Competition Scraping`),t.title=`Add to PLOS Competition Scraping`,t.textContent=`+`,t.style.display=`none`;let n=document.createElement(`button`);n.type=`button`,n.className=`plos-cs-add-button-dismiss`,n.setAttribute(`aria-label`,`Hide the +Add button for this page`),n.title=`Hide for this page`,n.textContent=`×`,n.style.display=`none`;let r=null,i=null,a=!1,o=null,s=null;function c(){o!==null&&(clearTimeout(o),o=null)}function l(){s!==null&&(clearTimeout(s),s=null)}function u(){c(),l(),r=null,i=null,t.style.display=`none`,n.style.display=`none`}function d(){s===null&&(s=setTimeout(()=>{s=null,u()},Ln))}function f(e){let r=e.getBoundingClientRect(),i=Math.max(2,r.top-8),a=Math.max(2,r.right-12);t.style.top=`${i}px`,t.style.left=`${a}px`,n.style.top=`${i+2}px`,n.style.left=`${a+22}px`}return t.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),r!==null&&e.onClick(r,i)}),n.addEventListener(`click`,e=>{e.preventDefault(),e.stopPropagation(),a=!0,u()}),t.addEventListener(`mouseenter`,l),t.addEventListener(`mouseleave`,d),n.addEventListener(`mouseenter`,l),n.addEventListener(`mouseleave`,d),document.body.appendChild(t),document.body.appendChild(n),{showFor(e,s){a||(l(),c(),o=setTimeout(()=>{a||(r=s,i=e.getBoundingClientRect(),f(e),t.style.display=`block`,n.style.display=`block`)},In))},hide(){d()},isDismissedForSession(){return a},destroy(){c(),l(),t.remove(),n.remove()}}}var zn=`data-plos-cs-icon-for`,Bn=`data-plos-cs-has-icon`;function Vn(e,t){if(e.getAttribute(Bn)===`1`||!e.parentNode)return;let n=document.createElement(`span`);n.className=`plos-cs-saved-icon`,n.setAttribute(zn,t),n.setAttribute(`aria-label`,`This URL is already saved in your project`),n.title=`Already in your project`,n.textContent=`✓`,e.parentNode.insertBefore(n,e),e.setAttribute(Bn,`1`)}function Hn(){document.querySelectorAll(`.plos-cs-saved-icon`).forEach(e=>e.remove()),document.querySelectorAll(`[${Bn}="1"]`).forEach(e=>e.removeAttribute(Bn))}var Un=`data-plos-cs-image-icon-for`,Wn=`data-plos-cs-image-has-icon`,Gn=`plos-cs-saved-image-icon`;function Kn(e,t){if(e.getAttribute(Wn)===t){let n=document.querySelector(`.${Gn}[${Un}="${Yn(t)}"]`);if(n)return{iconEl:n,imgEl:e,savedImageId:t,reposition:()=>qn(n,e)}}let n=e.getBoundingClientRect();if(n.width===0||n.height===0)return null;let r=document.createElement(`span`);return r.className=Gn,r.setAttribute(Un,t),r.setAttribute(`aria-label`,`This image is already saved in your project`),r.title=`Already saved to PLOS`,r.textContent=`✓`,document.body.appendChild(r),e.setAttribute(Wn,t),qn(r,e),{iconEl:r,imgEl:e,savedImageId:t,reposition:()=>qn(r,e)}}function qn(e,t){let n=t.getBoundingClientRect();if(n.width===0||n.height===0){e.style.display=`none`;return}let r=Math.max(2,n.top-6),i=Math.max(2,n.right-22);e.style.top=`${r}px`,e.style.left=`${i}px`,e.style.display=`inline-flex`}function Jn(){document.querySelectorAll(`.${Gn}`).forEach(e=>e.remove()),document.querySelectorAll(`[${Wn}]`).forEach(e=>e.removeAttribute(Wn))}function Yn(e){return typeof globalThis.CSS?.escape==`function`?globalThis.CSS.escape(e):e.replace(/["\\]/g,`\\$&`)}var Xn=`data-plos-cs-video-icon-for`,Zn=`data-plos-cs-video-has-icon`,Qn=`plos-cs-saved-video-icon`;function $n(e,t){if(e.getAttribute(Zn)===t){let n=document.querySelector(`.${Qn}[${Xn}="${nr(t)}"]`);if(n)return{iconEl:n,targetEl:e,savedVideoId:t,reposition:()=>er(n,e)}}let n=e.getBoundingClientRect();if(n.width===0||n.height===0)return null;let r=document.createElement(`span`);return r.className=Qn,r.setAttribute(Xn,t),r.setAttribute(`aria-label`,`This video is already saved in your project`),r.title=`Already saved to PLOS`,r.textContent=`✓`,document.body.appendChild(r),e.setAttribute(Zn,t),er(r,e),{iconEl:r,targetEl:e,savedVideoId:t,reposition:()=>er(r,e)}}function er(e,t){let n=t.getBoundingClientRect();if(n.width===0||n.height===0){e.style.display=`none`;return}let r=Math.max(2,n.top-6),i=Math.max(2,n.right-22);e.style.top=`${r}px`,e.style.left=`${i}px`,e.style.display=`inline-flex`}function tr(){document.querySelectorAll(`.${Qn}`).forEach(e=>e.remove()),document.querySelectorAll(`[${Zn}]`).forEach(e=>e.removeAttribute(Zn))}function nr(e){return typeof globalThis.CSS?.escape==`function`?globalThis.CSS.escape(e):e.replace(/["\\]/g,`\\$&`)}var rr=`plos-cs-saved-text`,ir=new Map;function ar(){let e=globalThis.CSS;return e===void 0||e.highlights===void 0?null:e.highlights}function or(e){let t=e.get(rr);if(t!==void 0)return t;let n=globalThis.Highlight;if(n===void 0)return null;let r=new n;return e.set(rr,r),r}function sr(e,t){let n=ar();if(n===null)return!1;let r=or(n);if(r===null)return!1;let i=ir.get(t);return i!==void 0&&r.delete(i),r.add(e),ir.set(t,e),!0}function cr(e){let t=ir.get(e);if(t===void 0)return;ir.delete(e);let n=ar();if(n===null)return;let r=n.get(rr);r!==void 0&&r.delete(t)}function lr(){ir.clear();let e=ar();if(e===null)return;let t=e.get(rr);t!==void 0&&t.clear()}function ur(e){return JSON.stringify({xpath:e.xpath,startOffset:e.startOffset,endOffset:e.endOffset})}function dr(e){let t;try{t=JSON.parse(e)}catch{return null}if(typeof t!=`object`||!t)return null;let n=t;return typeof n.xpath!=`string`||typeof n.startOffset!=`number`||typeof n.endOffset!=`number`||!Number.isFinite(n.startOffset)||!Number.isFinite(n.endOffset)||n.startOffset<0||n.endOffset<n.startOffset?null:{xpath:n.xpath,startOffset:n.startOffset,endOffset:n.endOffset}}function fr(e){if(e===``||e===`/`)return[];if(!e.startsWith(`/`))return null;let t=e.slice(1).split(`/`),n=[];for(let e of t){if(e.length===0)return null;let t=/^([A-Z][A-Z0-9_-]*)(?:\[(\d+)\])?$/.exec(e);if(!t)return null;let r=t[1];if(typeof r!=`string`)return null;let i=t[2],a=i===void 0?1:parseInt(i,10);if(!Number.isFinite(a)||a<1)return null;n.push({tagName:r,index:a})}return n}function pr(e){return e.length===0?``:`/`+e.map(e=>`${e.tagName}[${e.index}]`).join(`/`)}function mr(e){return e!==null&&e.nodeType===1}function hr(e){return e!==null&&e.nodeType===3}function gr(e,t){let n=e;for(let e of t){let t=0,r=null;for(let i of n.childNodes)if(mr(i)&&i.tagName===e.tagName&&(t+=1,t===e.index)){r=i;break}if(r===null)return null;n=r}return n}function _r(e,t){if(t===e)return``;let n=[],r=t;for(;r!==null&&r!==e;){let e=r.parentNode;if(e===null)return null;let t=0,i=!1;for(let n of e.childNodes)if(mr(n)&&n.tagName===r.tagName&&(t+=1,n===r)){i=!0;break}if(!i)return null;n.unshift({tagName:r.tagName,index:t}),r=e}return r===e?pr(n):null}function vr(e){let t=[];function n(e){if(hr(e)){t.push(e);return}if(mr(e))for(let t of e.childNodes)n(t)}return n(e),t}function yr(e,t,n){if(t===e&&mr(t)){let e=0;for(let r=0;r<t.childNodes.length&&r<n;r+=1){let n=t.childNodes[r];if(n===void 0)break;e+=xr(n)}return e}if(!hr(t))return null;let r=vr(e),i=0;for(let e of r){if(e===t)return i+n;i+=e.data.length}return null}function br(e,t){if(t<0)return null;let n=vr(e);if(n.length===0)return null;let r=0;for(let e of n){if(t<=r+e.data.length)return{node:e,offsetInNode:t-r};r+=e.data.length}return null}function xr(e){if(hr(e))return e.data.length;if(mr(e)){let t=0;for(let n of e.childNodes)t+=xr(n);return t}return 0}function Sr(e,t){let n=new Set,r=Cr(e);for(;r!==null;)n.add(r),r=r.parentNode;for(r=Cr(t);r!==null;){if(n.has(r))return r;r=r.parentNode}return null}function Cr(e){return mr(e)?e:hr(e)?e.parentNode??null:null}function wr(e,t){let n=e.startContainer,r=e.endContainer,i=t,a=Sr(n,r);if(a===null||!Er(i,a))return null;let o=_r(i,a);if(o===null)return null;let s=yr(a,n,e.startOffset),c=yr(a,r,e.endOffset);return s===null||c===null||c<s?null:{xpath:o,startOffset:s,endOffset:c}}function Tr(e,t,n=typeof Range<`u`?Range:void 0){if(n===void 0)return null;let r=fr(e.xpath);if(r===null)return null;let i=gr(t,r);if(i===null)return null;let a=br(i,e.startOffset),o=br(i,e.endOffset);if(a===null||o===null)return null;let s=new n;return s.setStart(a.node,a.offsetInNode),s.setEnd(o.node,o.offsetInNode),s}function Er(e,t){let n=t;for(;n!==null;){if(n===e)return!0;n=n.parentNode}return!1}var Dr=5e3,Or=null;function kr(e,t={}){let n=t.muteMutationObserver??(async e=>e());Or!==null&&(Or.destroy(),Or=null);let r=document.createElement(`div`);r.className=`plos-cs-overlay-banner`,r.setAttribute(`role`,`status`),r.setAttribute(`aria-live`,`polite`);let i=document.createElement(`span`);i.textContent=`✓`,i.style.fontWeight=`700`,r.appendChild(i);let a=document.createElement(`span`);a.textContent=`This URL is already in your project${e?` · ${e}`:``}`,r.appendChild(a);let o=document.createElement(`button`);o.type=`button`,o.className=`plos-cs-overlay-banner-close`,o.setAttribute(`aria-label`,`Close`),o.textContent=`×`,r.appendChild(o);let s=null,c={destroy(){s!==null&&(clearTimeout(s),s=null),n(async()=>{r.remove()}),Or===c&&(Or=null)}};return o.addEventListener(`click`,()=>c.destroy()),document.body.appendChild(r),s=setTimeout(()=>c.destroy(),Dr),Or=c,c}var Ar=[{value:`amazon`,label:`Amazon.com`},{value:`ebay`,label:`Ebay.com`},{value:`etsy`,label:`Etsy.com`},{value:`walmart`,label:`Walmart.com`},{value:`google-shopping`,label:`Google Shopping`},{value:`google-ads`,label:`Google Ads`},{value:`independent-website`,label:`Independent Website`}];function jr(e){return e===null?null:Ar.find(t=>t.value===e)?.label??null}var Mr=`__plos_add_new_competition_category__`,Nr=480,Pr=16;function Fr(e){if(!e)return null;let t=window.innerWidth,n=e.left+e.width/2<t/2,r;return r=n?t-Nr-Pr:Pr,r<Pr&&(r=Pr),r+Nr>t-Pr&&(r=Math.max(Pr,t-Nr-Pr)),{left:r,top:Pr}}var Ir=null;function Lr(e){Ir!==null&&(Ir.destroy(),Ir=null);let t=document.createElement(`div`);t.className=`plos-cs-form-backdrop`,t.setAttribute(`role`,`dialog`),t.setAttribute(`aria-modal`,`true`),t.setAttribute(`aria-label`,`Add competitor URL`);let n=document.createElement(`form`);n.className=`plos-cs-form`,n.noValidate=!0;let r=document.createElement(`h2`);r.className=`plos-cs-form-title`,r.textContent=`Add competitor URL`,n.appendChild(r);let i=document.createElement(`div`);i.className=`plos-cs-form-context`;let a=document.createElement(`div`);a.innerHTML=``;let o=document.createElement(`span`);o.textContent=`Project: `;let s=document.createElement(`strong`);s.textContent=e.projectName??`(unnamed project)`,a.appendChild(o),a.appendChild(s),i.appendChild(a);let c=document.createElement(`div`),l=document.createElement(`span`);l.textContent=`Platform: `;let d=document.createElement(`strong`);d.textContent=jr(e.platform)??e.platform,c.appendChild(l),c.appendChild(d),i.appendChild(c),n.appendChild(i);function f(e,t,n,r,i=!1){let a=document.createElement(`div`);a.className=`plos-cs-form-field`;let o=document.createElement(`label`);o.className=`plos-cs-form-label`,o.textContent=e,o.htmlFor=`plos-cs-${t}`;let s=document.createElement(`input`);return s.id=`plos-cs-${t}`,s.name=t,s.type=i?`url`:`text`,s.className=`plos-cs-form-input`,s.value=n,s.placeholder=r,a.appendChild(o),a.appendChild(s),{wrap:a,input:s}}function p(e,t,n,r=3){let i=document.createElement(`div`);i.className=`plos-cs-form-field`;let a=document.createElement(`label`);a.className=`plos-cs-form-label`,a.textContent=e,a.htmlFor=`plos-cs-${t}`;let o=document.createElement(`textarea`);return o.id=`plos-cs-${t}`,o.name=t,o.className=`plos-cs-form-input`,o.placeholder=n,o.rows=r,i.appendChild(a),i.appendChild(o),{wrap:i,input:o}}function m(){let e=document.createElement(`div`);e.className=`plos-cs-form-field`;let t=document.createElement(`label`);t.className=`plos-cs-form-label`,t.textContent=`Competition Category (optional)`,t.htmlFor=`plos-cs-category`,e.appendChild(t);let n=document.createElement(`select`);n.id=`plos-cs-category`,n.name=`category`,n.className=`plos-cs-form-input`;let r=document.createElement(`option`);r.value=``,r.textContent=`Pick or add a category…`,n.appendChild(r);let i=document.createElement(`option`);i.value=Mr,i.textContent=`+ Add new…`,n.appendChild(i),e.appendChild(n);let a=document.createElement(`input`);a.type=`text`,a.className=`plos-cs-form-input`,a.placeholder=`Type the new category name`,a.style.marginTop=`6px`,a.hidden=!0,e.appendChild(a);let o=document.createElement(`div`);return o.className=`plos-cs-form-help`,o.style.marginTop=`4px`,o.style.fontSize=`12px`,o.style.color=`#f0883e`,o.hidden=!0,e.appendChild(o),n.addEventListener(`change`,()=>{n.value===Mr?(a.hidden=!1,setTimeout(()=>a.focus(),0)):(a.hidden=!0,a.value=``)}),{wrap:e,getValue(){return n.value===Mr?a.value.trim():n.value},isAddingNew(){return n.value===Mr},setDisabled(e){n.disabled=e,a.disabled=e},populateEntries(e){let t=[...e].sort((e,t)=>e.value.localeCompare(t.value,void 0,{sensitivity:`base`}));for(let e of t){let t=document.createElement(`option`);t.value=e.value,t.textContent=e.value,n.insertBefore(t,i)}},setLoadError(e){e===null?(o.hidden=!0,o.textContent=``):(o.hidden=!1,o.textContent=e)},absorbNewEntry(e){if(!Array.from(n.options).find(t=>t.value===e.value)){let t=document.createElement(`option`);t.value=e.value,t.textContent=e.value,n.insertBefore(t,i)}n.value=e.value,a.hidden=!0,a.value=``}}}let h=f(`URL`,`url`,e.initialUrl,`https://...`,!0),g=m(),v=f(`Product Name (optional)`,`product-name`,``,`e.g., Brand X red light therapy device`),y=f(`Brand Name (optional)`,`brand-name`,``,`e.g., Brand X`),S=f(`Type (optional)`,`type`,``,`e.g., Red light therapy panel`),C=p(`Description 1 (optional)`,`description1`,`Longer prose — key product details, claims, positioning`),w=p(`Description 2 (optional)`,`description2`,`A second batch of prose — anything else worth capturing`),T=f(`Price (optional)`,`price`,``,`e.g., $299 or 299.00 or $250–$350`);n.appendChild(h.wrap),n.appendChild(g.wrap),n.appendChild(v.wrap),n.appendChild(y.wrap),n.appendChild(S.wrap),n.appendChild(C.wrap),n.appendChild(w.wrap),n.appendChild(T.wrap);let E=document.createElement(`div`);E.className=`plos-cs-form-field plos-cs-form-field-checkbox`;let D=document.createElement(`label`);D.className=`plos-cs-form-checkbox-label`,D.htmlFor=`plos-cs-is-sponsored-ad`;let O=document.createElement(`input`);O.id=`plos-cs-is-sponsored-ad`,O.name=`is-sponsored-ad`,O.type=`checkbox`,O.className=`plos-cs-form-checkbox`,O.checked=e.defaultIsSponsoredAd===!0;let k=document.createElement(`span`);k.textContent=`Sponsored Ad`,D.appendChild(O),D.appendChild(k),E.appendChild(D),n.appendChild(E);let A=document.createElement(`div`);A.className=`plos-cs-form-error`,A.style.display=`none`,n.appendChild(A);let j=document.createElement(`div`);j.className=`plos-cs-form-actions`;let M=document.createElement(`button`);M.type=`button`,M.className=`plos-cs-form-button plos-cs-form-button-secondary`,M.textContent=`Cancel`,j.appendChild(M);let N=document.createElement(`button`);N.type=`submit`,N.className=`plos-cs-form-button plos-cs-form-button-primary`,N.textContent=`Save`,j.appendChild(N),n.appendChild(j),t.appendChild(n);function P(){B.destroy(),e.onClose()}function F(e){e===null?(A.style.display=`none`,A.textContent=``):(A.style.display=`block`,A.textContent=e)}function I(e){N.disabled=e,M.disabled=e,h.input.disabled=e,g.setDisabled(e),v.input.disabled=e,y.input.disabled=e,S.input.disabled=e,C.input.disabled=e,w.input.disabled=e,T.input.disabled=e,O.disabled=e,N.textContent=e?`Saving…`:`Save`}async function L(t){t.preventDefault(),F(null);let n=h.input.value.trim();if(n.length===0){F(`URL is required.`);return}let r=g.getValue();if(g.isAddingNew()&&r.length===0){F(`You picked "+ Add new…" — please type the new category name, or pick a different option.`);return}I(!0);try{if(g.isAddingNew()&&r.length>0){let t=await x(e.projectId,{vocabularyType:`competition-category`,value:r,addedByWorkflow:`competition-scraping`});g.absorbNewEntry(t)}let t=await _(e.projectId,{platform:e.platform,url:n,...r?{competitionCategory:r}:{},...v.input.value.trim()?{productName:v.input.value.trim()}:{},...y.input.value.trim()?{brandName:y.input.value.trim()}:{},...S.input.value.trim()?{type:S.input.value.trim()}:{},...C.input.value.trim()?{description1:C.input.value.trim()}:{},...w.input.value.trim()?{description2:w.input.value.trim()}:{},...T.input.value.trim()?{price:T.input.value.trim()}:{},...O.checked?{isSponsoredAd:!0}:{}});I(!1),B.destroy(),e.onSaved(t)}catch(e){I(!1),e instanceof u?F(`Save failed (HTTP ${e.status}): ${e.message}`):F(`Save failed: ${e instanceof Error?e.message:`Unknown error`}`)}}n.addEventListener(`submit`,L),M.addEventListener(`click`,P),t.addEventListener(`mousedown`,e=>{e.target===t&&P()});function R(e){e.key===`Escape`&&(e.preventDefault(),P())}document.addEventListener(`keydown`,R),document.body.appendChild(t);let z=Fr(e.triggerRect??null);z&&(n.style.position=`fixed`,n.style.left=`${z.left}px`,n.style.top=`${z.top}px`),setTimeout(()=>h.input.focus(),0),b(e.projectId,`competition-category`).then(e=>{g.populateEntries(e)}).catch(e=>{let t=e instanceof u?`${e.message} (HTTP ${e.status})`:e instanceof Error?e.message:`Couldn't load existing categories`;g.setLoadError(`Could not load existing categories (${t}). You can still type a new one via "+ Add new…".`)});let B={destroy(){document.removeEventListener(`keydown`,R),t.remove(),Ir===B&&(Ir=null)}};return Ir=B,B}var Rr=`—`,zr=60,Br=57,Vr=80,Hr=77;function Ur(e){let t=typeof e.productName==`string`?e.productName.trim():``;return t.length>0?`${t} ${Rr} ${Wr(e.url,zr,Br)}`:Wr(e.url,Vr,Hr)}function Wr(e,t,n){return e.length>t?e.slice(0,n)+`…`:e}function Gr(e,t=Jr){return e.competitorUrlId.trim()?e.text.trim()?e.contentCategory.trim()?{ok:!0,payload:{clientId:t(),contentCategory:e.contentCategory.trim(),text:e.text,tags:Kr(e.tags)}}:{ok:!1,reason:`category-required`}:{ok:!1,reason:`text-required`}:{ok:!1,reason:`url-required`}}function Kr(e){let t=new Set,n=[];for(let r of e){if(typeof r!=`string`)continue;let e=r.trim();if(!e)continue;let i=e.toLowerCase();t.has(i)||(t.add(i),n.push(e))}return n}function qr(e,t,n){if(t.length===0)return null;let r=An(typeof e==`string`&&n?n(e)??e:e);if(!r)return null;for(let e of t){let t=An(typeof e.url==`string`&&n?n(e.url)??e.url:e.url);if(t&&t===r)return e}return null}function Jr(){return crypto.randomUUID()}var Yr=null,Xr=`__plos_add_new_category__`;function Zr(e){Yr!==null&&(Yr.destroy(),Yr=null);let t=document.createElement(`div`);t.className=`plos-cs-form-backdrop`,t.setAttribute(`role`,`dialog`),t.setAttribute(`aria-modal`,`true`),t.setAttribute(`aria-label`,`Add captured text`);let n=document.createElement(`form`);n.className=`plos-cs-form`,n.noValidate=!0;let r=document.createElement(`h2`);r.className=`plos-cs-form-title`,r.textContent=`Add captured text to PLOS`,n.appendChild(r);let i=document.createElement(`div`);i.className=`plos-cs-form-context`;let a=document.createElement(`div`),o=document.createElement(`span`);o.textContent=`Project: `;let s=document.createElement(`strong`);s.textContent=e.projectName??`(unnamed project)`,a.appendChild(o),a.appendChild(s),i.appendChild(a);let c=document.createElement(`div`),l=document.createElement(`span`);l.textContent=`Platform: `;let d=document.createElement(`strong`);d.textContent=jr(e.platform)??e.platform,c.appendChild(l),c.appendChild(d),i.appendChild(c),n.appendChild(i);let f=document.createElement(`div`);f.className=`plos-cs-form-status`,f.textContent=`Loading your saved URLs and categories…`,n.appendChild(f);let m=document.createElement(`div`);m.className=`plos-cs-form-field`;let h=document.createElement(`label`);h.className=`plos-cs-form-label`,h.htmlFor=`plos-cs-text-url`,h.textContent=`Attach to which saved URL?`;let g=document.createElement(`select`);g.id=`plos-cs-text-url`,g.name=`url`,g.className=`plos-cs-form-select`,g.disabled=!0;let _=document.createElement(`option`);_.value=``,_.textContent=`Loading…`,g.appendChild(_),m.appendChild(h),m.appendChild(g),n.appendChild(m);let y=document.createElement(`div`);y.className=`plos-cs-form-field`;let S=document.createElement(`label`);S.className=`plos-cs-form-label`,S.htmlFor=`plos-cs-text-body`,S.textContent=`Captured text`;let C=document.createElement(`textarea`);C.id=`plos-cs-text-body`,C.name=`text`,C.className=`plos-cs-form-textarea`,C.rows=5,C.value=e.initialText,C.placeholder=`Paste or edit the text you want to save against this URL.`,y.appendChild(S),y.appendChild(C),n.appendChild(y);let w=document.createElement(`div`);w.className=`plos-cs-form-field`;let T=document.createElement(`label`);T.className=`plos-cs-form-label`,T.htmlFor=`plos-cs-text-category`,T.textContent=`Content category`;let E=document.createElement(`select`);E.id=`plos-cs-text-category`,E.name=`category`,E.className=`plos-cs-form-select`,E.disabled=!0;let D=document.createElement(`option`);D.value=``,D.textContent=`Loading…`,E.appendChild(D),w.appendChild(T),w.appendChild(E);let O=document.createElement(`div`);O.className=`plos-cs-form-inline-add`,O.style.display=`none`;let k=document.createElement(`input`);k.type=`text`,k.className=`plos-cs-form-input`,k.placeholder=`Type new category name`,O.appendChild(k),w.appendChild(O),n.appendChild(w);let A=document.createElement(`div`);A.className=`plos-cs-form-field`;let j=document.createElement(`label`);j.className=`plos-cs-form-label`,j.htmlFor=`plos-cs-text-tags-input`,j.textContent=`Tags (optional)`;let M=document.createElement(`div`);M.className=`plos-cs-chip-row`;let N=document.createElement(`input`);N.type=`text`,N.id=`plos-cs-text-tags-input`,N.className=`plos-cs-form-input`,N.placeholder=`Type a tag and press Enter`,A.appendChild(j),A.appendChild(M),A.appendChild(N),n.appendChild(A);let P=document.createElement(`div`);P.className=`plos-cs-form-error`,P.style.display=`none`,n.appendChild(P);let F=document.createElement(`div`);F.className=`plos-cs-form-actions`;let I=document.createElement(`button`);I.type=`button`,I.className=`plos-cs-form-button plos-cs-form-button-secondary`,I.textContent=`Cancel`,F.appendChild(I);let L=document.createElement(`button`);L.type=`submit`,L.className=`plos-cs-form-button plos-cs-form-button-primary`,L.textContent=`Save`,L.disabled=!0,F.appendChild(L),n.appendChild(F),t.appendChild(n);let R=[];function z(){M.innerHTML=``;for(let e of R){let t=document.createElement(`span`);t.className=`plos-cs-chip`;let n=document.createElement(`span`);n.textContent=e,t.appendChild(n);let r=document.createElement(`button`);r.type=`button`,r.className=`plos-cs-chip-remove`,r.setAttribute(`aria-label`,`Remove tag ${e}`),r.textContent=`×`,r.addEventListener(`click`,()=>{R=R.filter(t=>t!==e),z()}),t.appendChild(r),M.appendChild(t)}}function B(){let e=N.value.split(`,`);R=Kr([...R,...e]),N.value=``,z()}N.addEventListener(`keydown`,e=>{if(e.key===`Enter`){e.preventDefault(),B();return}e.key===`,`&&(e.preventDefault(),B())}),N.addEventListener(`blur`,()=>{N.value.trim().length>0&&B()}),E.addEventListener(`change`,()=>{E.value===Xr?(O.style.display=`block`,k.focus()):(O.style.display=`none`,k.value=``)});function V(e){e===null?(P.style.display=`none`,P.textContent=``):(P.style.display=`block`,P.textContent=e)}function H(e){L.disabled=e,I.disabled=e,g.disabled=e,C.disabled=e,E.disabled=e,k.disabled=e,N.disabled=e,L.textContent=e?`Saving…`:`Save`}async function U(t){t.preventDefault(),V(null);let n=E.value;n===Xr&&(n=k.value);let r=Gr({competitorUrlId:g.value,text:C.value,contentCategory:n,tags:R});if(!r.ok){V({"url-required":`Pick the saved URL this text belongs to.`,"text-required":`The captured text can’t be empty.`,"category-required":`Pick a content category, or add a new one via "+ Add new…".`}[r.reason]);return}H(!0);try{E.value===Xr&&await x(e.projectId,{vocabularyType:`content-category`,value:r.payload.contentCategory??``});let t=e.selectorJson===null?r.payload:{...r.payload,selector:e.selectorJson};await v(e.projectId,g.value,t),e.onSaved(),G()}catch(e){V(e instanceof u?`Couldn’t save (${e.status||`network`}): ${e.message}`:`Couldn’t save: unknown error.`),H(!1)}}n.addEventListener(`submit`,e=>{U(e)}),I.addEventListener(`click`,()=>{G()}),t.addEventListener(`mousedown`,e=>{e.target===t&&G()});function W(e){e.key===`Escape`&&(e.preventDefault(),G())}document.addEventListener(`keydown`,W),document.body.appendChild(t),setTimeout(()=>{C.focus();let e=C.value.length;C.setSelectionRange(e,e)},0),(async()=>{try{let[t,n]=await Promise.all([p(e.projectId,e.platform),b(e.projectId,`content-category`)]);if(g.innerHTML=``,t.length===0){let t=document.createElement(`option`);t.value=``,t.textContent=`No saved ${jr(e.platform)??e.platform} URLs yet — capture one via "+ Add" first`,g.appendChild(t),g.disabled=!0,L.disabled=!0}else{let n=document.createElement(`option`);n.value=``,n.textContent=`Pick a saved URL…`,g.appendChild(n);for(let e of t){let t=document.createElement(`option`);t.value=e.id,t.textContent=Ur(e),g.appendChild(t)}let r=On(e.platform),i=qr(e.pageUrl,t,r?e=>r.canonicalProductUrl(e):void 0);i&&(g.value=i.id),g.disabled=!1}E.innerHTML=``;let r=document.createElement(`option`);r.value=``,r.textContent=`Pick a content category…`,E.appendChild(r);for(let e of n){let t=document.createElement(`option`);t.value=e.value,t.textContent=e.value,E.appendChild(t)}let i=document.createElement(`option`);i.value=Xr,i.textContent=`+ Add new…`,E.appendChild(i),E.disabled=!1,f.style.display=`none`,t.length>0&&(L.disabled=!1)}catch(e){let t=e instanceof u?`Couldn’t load your saved URLs or categories (${e.status||`network`}): ${e.message}`:`Couldn’t load your saved URLs or categories.`;f.style.display=`none`,V(t),L.disabled=!0}})();function G(){K.destroy(),e.onClose()}let K={destroy(){t.parentNode&&t.parentNode.removeChild(t),document.removeEventListener(`keydown`,W),Yr===K&&(Yr=null)}};return Yr=K,K}var Qr=[`image/jpeg`,`image/png`,`image/webp`];function $r(e){return typeof e==`string`&&Qr.includes(e)}var ei=[`regular`,`region-screenshot`];function ti(e){return typeof e==`string`&&ei.includes(e)}var ni=[`video/mp4`,`video/webm`,`video/quicktime`];function ri(e){return typeof e==`string`&&ni.includes(e)}var ii=[`EMBED`,`DIRECT_BYTES`,`SCREEN_RECORDING`];function ai(e){return typeof e==`string`&&ii.includes(e)}function oi(e,t=ci){return e.competitorUrlId.trim()?$r(e.mimeType)?e.fileSize<=0?{ok:!1,reason:`image-required`}:e.fileSize>5242880?{ok:!1,reason:`image-too-large`}:ti(e.sourceType)?e.imageCategory.trim()?{ok:!0,payload:{clientId:t(),competitorUrlId:e.competitorUrlId,mimeType:e.mimeType,sourceType:e.sourceType,imageCategory:e.imageCategory.trim(),composition:e.composition.trim()?e.composition.trim():null,embeddedText:e.embeddedText.trim()?e.embeddedText.trim():null,tags:si(e.tags)}}:{ok:!1,reason:`category-required`}:{ok:!1,reason:`source-type-invalid`}:!e.mimeType||e.fileSize<=0?{ok:!1,reason:`image-required`}:{ok:!1,reason:`image-mime-rejected`}:{ok:!1,reason:`url-required`}}function si(e){let t=new Set,n=[];for(let r of e){if(typeof r!=`string`)continue;let e=r.trim();if(!e)continue;let i=e.toLowerCase();t.has(i)||(t.add(i),n.push(e))}return n}function ci(){return crypto.randomUUID()}var li=null,ui=`__plos_add_new_image_category__`;function di(e){li!==null&&(li.destroy(),li=null);let t=document.createElement(`div`);t.className=`plos-cs-form-backdrop`,t.setAttribute(`role`,`dialog`),t.setAttribute(`aria-modal`,`true`),t.setAttribute(`aria-label`,`Add captured image`);let n=document.createElement(`form`);n.className=`plos-cs-form`,n.noValidate=!0;let r=document.createElement(`h2`);r.className=`plos-cs-form-title`,r.textContent=`Add captured image to PLOS`,n.appendChild(r);let i=document.createElement(`div`);i.className=`plos-cs-form-context`;let a=document.createElement(`div`),o=document.createElement(`span`);o.textContent=`Project: `;let s=document.createElement(`strong`);s.textContent=e.projectName??`(unnamed project)`,a.appendChild(o),a.appendChild(s),i.appendChild(a);let c=document.createElement(`div`),l=document.createElement(`span`);l.textContent=`Platform: `;let d=document.createElement(`strong`);d.textContent=jr(e.platform)??e.platform,c.appendChild(l),c.appendChild(d),i.appendChild(c),n.appendChild(i);let f=document.createElement(`div`);f.className=`plos-cs-form-status`,f.textContent=`Loading your saved URLs and image categories…`,n.appendChild(f);let m=document.createElement(`div`);m.className=`plos-cs-form-image-preview-wrap`;let h=document.createElement(`img`);h.className=`plos-cs-form-image-preview`,h.alt=`Preview of the image you right-clicked`,h.src=e.srcUrl,m.appendChild(h);let g=document.createElement(`div`);g.className=`plos-cs-form-image-meta`,g.textContent=`Loading preview…`,m.appendChild(g),h.addEventListener(`load`,()=>{let e=h.naturalWidth,t=h.naturalHeight;e>0&&t>0?g.textContent=`${e} × ${t} pixels`:g.textContent=``}),h.addEventListener(`error`,()=>{g.className=`plos-cs-form-image-meta-failed`,g.textContent=`Couldn't preview the image — Save will still try the upload.`}),n.appendChild(m);let _=document.createElement(`div`);_.className=`plos-cs-form-field`;let v=document.createElement(`label`);v.className=`plos-cs-form-label`,v.htmlFor=`plos-cs-image-url`,v.textContent=`Attach to which saved URL?`;let y=document.createElement(`select`);y.id=`plos-cs-image-url`,y.name=`url`,y.className=`plos-cs-form-select`,y.disabled=!0;let C=document.createElement(`option`);C.value=``,C.textContent=`Loading…`,y.appendChild(C),_.appendChild(v),_.appendChild(y),n.appendChild(_);let w=document.createElement(`div`);w.className=`plos-cs-form-field`;let T=document.createElement(`label`);T.className=`plos-cs-form-label`,T.htmlFor=`plos-cs-image-category`,T.textContent=`Image category`;let E=document.createElement(`select`);E.id=`plos-cs-image-category`,E.name=`category`,E.className=`plos-cs-form-select`,E.disabled=!0;let D=document.createElement(`option`);D.value=``,D.textContent=`Loading…`,E.appendChild(D),w.appendChild(T),w.appendChild(E);let O=document.createElement(`div`);O.className=`plos-cs-form-inline-add`,O.style.display=`none`;let k=document.createElement(`input`);k.type=`text`,k.className=`plos-cs-form-input`,k.placeholder=`Type new image-category name`,O.appendChild(k),w.appendChild(O),n.appendChild(w);let A=document.createElement(`div`);A.className=`plos-cs-form-field`;let j=document.createElement(`label`);j.className=`plos-cs-form-label`,j.htmlFor=`plos-cs-image-composition`,j.textContent=`Composition (optional)`;let M=document.createElement(`textarea`);M.id=`plos-cs-image-composition`,M.name=`composition`,M.className=`plos-cs-form-textarea`,M.rows=2,M.placeholder=`Describe what's in the image (e.g., 'wireless headphones on a white background').`,A.appendChild(j),A.appendChild(M),n.appendChild(A);let N=document.createElement(`div`);N.className=`plos-cs-form-field`;let P=document.createElement(`label`);P.className=`plos-cs-form-label`,P.htmlFor=`plos-cs-image-embedded-text`,P.textContent=`Embedded text (optional)`;let F=document.createElement(`textarea`);F.id=`plos-cs-image-embedded-text`,F.name=`embeddedText`,F.className=`plos-cs-form-textarea`,F.rows=2,F.placeholder=`Text that appears INSIDE the image (e.g., overlay headline, watermark).`,N.appendChild(P),N.appendChild(F),n.appendChild(N);let I=document.createElement(`div`);I.className=`plos-cs-form-field`;let L=document.createElement(`label`);L.className=`plos-cs-form-label`,L.htmlFor=`plos-cs-image-tags-input`,L.textContent=`Tags (optional)`;let R=document.createElement(`div`);R.className=`plos-cs-chip-row`;let z=document.createElement(`input`);z.type=`text`,z.id=`plos-cs-image-tags-input`,z.className=`plos-cs-form-input`,z.placeholder=`Type a tag and press Enter`,I.appendChild(L),I.appendChild(R),I.appendChild(z),n.appendChild(I);let B=document.createElement(`div`);B.className=`plos-cs-form-error`,B.style.display=`none`,n.appendChild(B);let V=document.createElement(`div`);V.className=`plos-cs-form-actions`;let H=document.createElement(`button`);H.type=`button`,H.className=`plos-cs-form-button plos-cs-form-button-secondary`,H.textContent=`Cancel`,V.appendChild(H);let U=document.createElement(`button`);U.type=`submit`,U.className=`plos-cs-form-button plos-cs-form-button-primary`,U.textContent=`Save`,U.disabled=!0,V.appendChild(U),n.appendChild(V),t.appendChild(n);let W=[];function G(){R.innerHTML=``;for(let e of W){let t=document.createElement(`span`);t.className=`plos-cs-chip`;let n=document.createElement(`span`);n.textContent=e,t.appendChild(n);let r=document.createElement(`button`);r.type=`button`,r.className=`plos-cs-chip-remove`,r.setAttribute(`aria-label`,`Remove tag ${e}`),r.textContent=`×`,r.addEventListener(`click`,()=>{W=W.filter(t=>t!==e),G()}),t.appendChild(r),R.appendChild(t)}}function K(){let e=z.value.split(`,`);W=si([...W,...e]),z.value=``,G()}z.addEventListener(`keydown`,e=>{if(e.key===`Enter`){e.preventDefault(),K();return}e.key===`,`&&(e.preventDefault(),K())}),z.addEventListener(`blur`,()=>{z.value.trim().length>0&&K()}),E.addEventListener(`change`,()=>{E.value===ui?(O.style.display=`block`,k.focus()):(O.style.display=`none`,k.value=``)});function q(e){e===null?(B.style.display=`none`,B.textContent=``):(B.style.display=`block`,B.textContent=e)}function J(e){U.disabled=e,H.disabled=e,y.disabled=e,E.disabled=e,k.disabled=e,M.disabled=e,F.disabled=e,z.disabled=e,U.textContent=e?`Saving…`:`Save`}async function Y(t){t.preventDefault(),q(null);let n=E.value;n===ui&&(n=k.value);let r=oi({competitorUrlId:y.value,mimeType:`image/jpeg`,fileSize:1,sourceType:e.sourceType??`regular`,imageCategory:n,composition:M.value,embeddedText:F.value,tags:W});if(!r.ok){q(fi(r.reason));return}J(!0);try{E.value===ui&&await x(e.projectId,{vocabularyType:`image-category`,value:r.payload.imageCategory}),await S({projectId:e.projectId,urlId:y.value,srcUrl:e.srcUrl,request:{clientId:r.payload.clientId,mimeType:r.payload.mimeType,sourceType:r.payload.sourceType,imageCategory:r.payload.imageCategory},finalize:{imageCategory:r.payload.imageCategory,composition:r.payload.composition??void 0,embeddedText:r.payload.embeddedText??void 0,tags:r.payload.tags}}),e.onSaved(),Z()}catch(e){q(e instanceof u?`Couldn’t save (${e.status||`network`}): ${e.message}`:`Couldn’t save: unknown error.`),J(!1)}}n.addEventListener(`submit`,e=>{Y(e)}),H.addEventListener(`click`,()=>{Z()}),t.addEventListener(`mousedown`,e=>{e.target===t&&Z()});function X(e){e.key===`Escape`&&(e.preventDefault(),Z())}document.addEventListener(`keydown`,X),document.body.appendChild(t),setTimeout(()=>{y.focus()},0),(async()=>{try{let[t,n]=await Promise.all([p(e.projectId,e.platform),b(e.projectId,`image-category`)]);if(y.innerHTML=``,t.length===0){let t=document.createElement(`option`);t.value=``,t.textContent=`No saved ${jr(e.platform)??e.platform} URLs yet — capture one via "+ Add" first`,y.appendChild(t),y.disabled=!0,U.disabled=!0}else{let n=document.createElement(`option`);n.value=``,n.textContent=`Pick a saved URL…`,y.appendChild(n);for(let e of t){let t=document.createElement(`option`);t.value=e.id,t.textContent=Ur(e),y.appendChild(t)}let r=On(e.platform),i=qr(e.pageUrl,t,r?e=>r.canonicalProductUrl(e):void 0);i&&(y.value=i.id),y.disabled=!1}E.innerHTML=``;let r=document.createElement(`option`);r.value=``,r.textContent=`Pick an image category…`,E.appendChild(r);for(let e of n){let t=document.createElement(`option`);t.value=e.value,t.textContent=e.value,E.appendChild(t)}let i=document.createElement(`option`);i.value=ui,i.textContent=`+ Add new…`,E.appendChild(i),E.disabled=!1,f.style.display=`none`,t.length>0&&(U.disabled=!1)}catch(e){let t=e instanceof u?`Couldn’t load your saved URLs or image categories (${e.status||`network`}): ${e.message}`:`Couldn’t load your saved URLs or image categories.`;f.style.display=`none`,q(t),U.disabled=!0}})();function Z(){Q.destroy(),e.onClose()}let Q={destroy(){t.parentNode&&t.parentNode.removeChild(t),document.removeEventListener(`keydown`,X),li===Q&&(li=null)}};return li=Q,Q}function fi(e){switch(e){case`url-required`:return`Pick the saved URL this image belongs to.`;case`image-required`:return`No image to upload — close this form and right-click an image again.`;case`image-mime-rejected`:return`Unsupported image type. PLOS accepts ${Qr.join(`, `)}.`;case`image-too-large`:return`Image exceeds the 5 MB cap. Try a smaller version of the same image.`;case`source-type-invalid`:return`Internal error — unrecognized image source.`;case`category-required`:return`Pick an image category, or add a new one via "+ Add new…".`}}var pi=.85;function mi(){return{createObjectURL(e){return URL.createObjectURL(e)},revokeObjectURL(e){URL.revokeObjectURL(e)},createVideoElement(){return document.createElement(`video`)},createCanvas(e,t){let n=document.createElement(`canvas`);return n.width=e,n.height=t,n}}}async function hi(e,t=mi()){if(e.blob.size===0||e.width<=0||e.height<=0)return null;let n=t.createObjectURL(e.blob),r=t.createVideoElement();r.muted=!0,r.playsInline=!0,r.preload=`auto`;try{return await new Promise(i=>{let a=!1;function o(e){a||(a=!0,t.revokeObjectURL(n),i(e))}r.addEventListener(`error`,()=>{o(null)}),r.addEventListener(`seeked`,()=>{try{let n=t.createCanvas(e.width,e.height),i=n.getContext(`2d`);if(i===null){o(null);return}i.drawImage(r,0,0,e.width,e.height),n.toBlob(e=>{o(e)},`image/jpeg`,pi)}catch{o(null)}}),r.addEventListener(`loadedmetadata`,()=>{try{r.currentTime=0}catch{o(null)}}),r.src=n})}catch{return t.revokeObjectURL(n),null}}function gi(e){let t=(e.split(`;`)[0]??``).trim().toLowerCase();return t===`video/mp4`||t===`video/webm`||t===`video/quicktime`?t:`video/webm`}async function _i(e){let t=crypto.randomUUID(),n=gi(e.blob.type||`video/webm`),r=e.blob.size,i=await T({projectId:e.projectId,urlId:e.urlId,clientId:t,mimeType:n,fileSize:r}),a=await fetch(i.videoUploadUrl,{method:`PUT`,body:e.blob,headers:{"Content-Type":n}});if(!a.ok)throw new u(a.status,`Failed to upload recording bytes (HTTP ${String(a.status)}).`);let o=!1;if(e.thumbnailBlob)try{(await fetch(i.thumbnailUploadUrl,{method:`PUT`,body:e.thumbnailBlob,headers:{"Content-Type":`image/jpeg`}})).ok&&(o=!0)}catch{}return E({projectId:e.projectId,urlId:e.urlId,clientId:t,capturedVideoId:i.capturedVideoId,videoStoragePath:i.videoStoragePath,...o?{thumbnailStoragePath:i.thumbnailStoragePath}:{},mimeType:n,fileSize:r,durationSeconds:e.durationSeconds,width:e.width,height:e.height,originalSrcUrl:e.pageUrl,videoCategory:e.videoCategory,composition:e.composition,embeddedText:e.embeddedText,tags:e.tags})}var vi=[{name:`youtube`,pattern:/^https?:\/\/(?:www\.)?youtube\.com\/watch\?(?:[^#]*&)?v=[a-zA-Z0-9_-]{11}/},{name:`youtube`,pattern:/^https?:\/\/youtu\.be\/[a-zA-Z0-9_-]{11}/},{name:`youtube`,pattern:/^https?:\/\/(?:www\.)?youtube\.com\/embed\/[a-zA-Z0-9_-]{11}/},{name:`vimeo`,pattern:/^https?:\/\/(?:www\.)?vimeo\.com\/[0-9]+/},{name:`vimeo`,pattern:/^https?:\/\/player\.vimeo\.com\/video\/[0-9]+/},{name:`wistia`,pattern:/^https?:\/\/[a-zA-Z0-9_-]+\.wistia\.com\/medias\/[a-zA-Z0-9]+/},{name:`wistia`,pattern:/^https?:\/\/fast\.wistia\.net\/embed\/iframe\/[a-zA-Z0-9]+/},{name:`brightcove`,pattern:/^https?:\/\/players\.brightcove\.net\/[^/]+\/[^/]+\/index\.html\?videoId=[0-9]+/},{name:`dailymotion`,pattern:/^https?:\/\/(?:www\.)?dailymotion\.com\/video\/[a-zA-Z0-9]+/},{name:`dailymotion`,pattern:/^https?:\/\/dai\.ly\/[a-zA-Z0-9]+/},{name:`loom`,pattern:/^https?:\/\/(?:www\.)?loom\.com\/share\/[a-zA-Z0-9]+/}];function yi(e){if(typeof e!=`string`)return null;let t=e.trim();if(t.length===0)return null;for(let{name:e,pattern:n}of vi)if(n.test(t))return e;return null}function bi(e,t=Si){if(!e.competitorUrlId.trim())return{ok:!1,reason:`url-required`};if(!ai(e.sourceType))return{ok:!1,reason:`source-type-invalid`};if(!e.originalSrcUrl.trim())return{ok:!1,reason:e.sourceType===`EMBED`?`embed-url-required`:`url-required`};if(!e.videoCategory.trim())return{ok:!1,reason:`category-required`};let n=null,r=null;if(e.sourceType===`DIRECT_BYTES`||e.sourceType===`SCREEN_RECORDING`){if(e.fileSize<=0)return{ok:!1,reason:`bytes-required`};if(e.fileSize>104857600)return{ok:!1,reason:`video-too-large`};if(e.mimeType&&!ri(e.mimeType))return{ok:!1,reason:`video-mime-rejected`};n=ri(e.mimeType)?e.mimeType:null}else{let t=yi(e.originalSrcUrl);if(!t)return{ok:!1,reason:`embed-url-unrecognized`};r=t}return{ok:!0,payload:{clientId:t(),competitorUrlId:e.competitorUrlId,sourceType:e.sourceType,originalSrcUrl:e.originalSrcUrl.trim(),mimeType:n,videoCategory:e.videoCategory.trim(),composition:e.composition.trim()?e.composition.trim():null,embeddedText:e.embeddedText.trim()?e.embeddedText.trim():null,tags:xi(e.tags),embedPlatform:r}}}function xi(e){let t=new Set,n=[];for(let r of e){if(typeof r!=`string`)continue;let e=r.trim();if(!e)continue;let i=e.toLowerCase();t.has(i)||(t.add(i),n.push(e))}return n}function Si(){return crypto.randomUUID()}var Ci=null,wi=`__plos_add_new_video_category__`,Ti=200,Ei=3,Di=.85;function Oi(e){Ci!==null&&(Ci.destroy(),Ci=null);let t=e.platform,n=document.createElement(`div`);n.setAttribute(`data-plos-cs-host`,`video-capture-form`),n.style.position=`fixed`,n.style.inset=`0`,n.style.zIndex=`999998`;let r=n.attachShadow({mode:`open`}),i=document.createElement(`style`);i.textContent=Mn,r.appendChild(i);let a=document.createElement(`div`);a.className=`plos-cs-form-backdrop`,a.setAttribute(`role`,`dialog`),a.setAttribute(`aria-modal`,`true`),a.setAttribute(`aria-label`,`Add captured video`);let o=document.createElement(`form`);o.className=`plos-cs-form`,o.noValidate=!0;let s=document.createElement(`h2`);s.className=`plos-cs-form-title`,s.textContent=`Add captured video to PLOS`,o.appendChild(s);let c=document.createElement(`div`);c.className=`plos-cs-form-context`;let l=document.createElement(`div`),d=document.createElement(`span`);d.textContent=`Project: `;let f=document.createElement(`strong`);f.textContent=e.projectName??`(unnamed project)`,l.appendChild(d),l.appendChild(f),c.appendChild(l);let m=document.createElement(`div`),h=document.createElement(`span`);h.textContent=`Platform: `;let g=document.createElement(`strong`);g.textContent=jr(t)??t,m.appendChild(h),m.appendChild(g),c.appendChild(m),o.appendChild(c);let _=document.createElement(`div`);if(_.className=`plos-cs-form-status`,e.kind===`direct`)_.textContent=`Direct video — will upload the video file plus a thumbnail frame.`;else if(e.kind===`screen-recording`){let t=(e.blob.size/(1024*1024)).toFixed(1),n=Math.round(e.durationSeconds);_.textContent=`Screen recording (${String(n)}s, ${t} MB) — will upload the recording plus a first-frame thumbnail.`}else _.textContent=`Recognized as ${e.embedPlatform.charAt(0).toUpperCase()+e.embedPlatform.slice(1)} — will save the embed link only.`;o.appendChild(_);let v=document.createElement(`div`);v.className=`plos-cs-form-status`,v.textContent=`Loading your saved URLs and video categories…`,o.appendChild(v);let y=document.createElement(`div`);if(y.className=`plos-cs-form-image-preview-wrap`,e.kind===`direct`){let t=document.createElement(`video`);t.className=`plos-cs-form-image-preview`,t.src=e.src,t.muted=!0,t.preload=`metadata`,t.style.maxHeight=`160px`,t.crossOrigin=`anonymous`,y.appendChild(t);let n=document.createElement(`div`);n.className=`plos-cs-form-image-meta`,n.textContent=`Loading preview…`,y.appendChild(n);let r=!1;function S(){if(r)return;r=!0,t.style.display=`none`;let e=document.createElement(`div`);e.className=`plos-cs-form-video-preview-fallback`,Object.assign(e.style,{display:`flex`,alignItems:`center`,justifyContent:`center`,height:`120px`,background:`#f3f4f6`,border:`1px dashed #9ca3af`,borderRadius:`6px`,color:`#374151`,fontSize:`13px`,fontWeight:`500`,textAlign:`center`,padding:`0 16px`}),e.textContent=`▶ Video preview unavailable — Save will still try to capture the file.`,y.insertBefore(e,t),n.className=`plos-cs-form-image-meta-failed`,n.textContent=`Couldn't preview the video — Save will still try the upload.`}t.addEventListener(`loadedmetadata`,()=>{r=!0;let e=t.videoWidth,i=t.videoHeight,a=t.duration,o=[];if(e>0&&i>0&&o.push(`${e} × ${i} pixels`),Number.isFinite(a)&&a>0){let e=Math.floor(a/60),t=Math.floor(a%60);o.push(`${e}:${t.toString().padStart(2,`0`)}`)}n.textContent=o.length>0?o.join(` · `):`(no metadata)`}),t.addEventListener(`error`,()=>{S()}),setTimeout(()=>{!r&&t.readyState<1&&S()},5e3)}else if(e.kind===`screen-recording`){let t=document.createElement(`video`);t.className=`plos-cs-form-image-preview`,t.controls=!0,t.muted=!0,t.style.maxHeight=`200px`,t.style.maxWidth=`100%`;let n=URL.createObjectURL(e.blob);t.src=n,t._plosBlobUrl=n,y.appendChild(t);let r=document.createElement(`div`);r.className=`plos-cs-form-image-meta`;let i=Math.round(e.durationSeconds);r.textContent=`${String(e.width)} × ${String(e.height)} pixels · ${String(i)}s`,y.appendChild(r)}else{let t=document.createElement(`div`);t.className=`plos-cs-form-image-meta`,t.textContent=e.src,y.appendChild(t)}o.appendChild(y);let w=document.createElement(`div`);w.className=`plos-cs-form-field`;let T=document.createElement(`label`);T.className=`plos-cs-form-label`,T.htmlFor=`plos-cs-video-url`,T.textContent=`Attach to which saved URL?`;let E=document.createElement(`select`);E.id=`plos-cs-video-url`,E.name=`url`,E.className=`plos-cs-form-select`,E.disabled=!0;let D=document.createElement(`option`);D.value=``,D.textContent=`Loading…`,E.appendChild(D),w.appendChild(T),w.appendChild(E),o.appendChild(w);let O=document.createElement(`div`);O.className=`plos-cs-form-field`;let k=document.createElement(`label`);k.className=`plos-cs-form-label`,k.htmlFor=`plos-cs-video-category`,k.textContent=`Video category`;let A=document.createElement(`select`);A.id=`plos-cs-video-category`,A.name=`category`,A.className=`plos-cs-form-select`,A.disabled=!0;let j=document.createElement(`option`);j.value=``,j.textContent=`Loading…`,A.appendChild(j),O.appendChild(k),O.appendChild(A);let M=document.createElement(`div`);M.className=`plos-cs-form-inline-add`,M.style.display=`none`;let N=document.createElement(`input`);N.type=`text`,N.className=`plos-cs-form-input`,N.placeholder=`Type new video-category name`,M.appendChild(N),O.appendChild(M),o.appendChild(O);let P=document.createElement(`div`);P.className=`plos-cs-form-field`;let F=document.createElement(`label`);F.className=`plos-cs-form-label`,F.htmlFor=`plos-cs-video-composition`,F.textContent=`Composition (optional)`;let I=document.createElement(`textarea`);I.id=`plos-cs-video-composition`,I.name=`composition`,I.className=`plos-cs-form-textarea`,I.rows=2,I.placeholder=`Describe what's in the video (e.g., '30-second product demo showing wireless setup').`,P.appendChild(F),P.appendChild(I),o.appendChild(P);let L=document.createElement(`div`);L.className=`plos-cs-form-field`;let R=document.createElement(`label`);R.className=`plos-cs-form-label`,R.htmlFor=`plos-cs-video-embedded-text`,R.textContent=`Embedded text (optional)`;let z=document.createElement(`textarea`);z.id=`plos-cs-video-embedded-text`,z.name=`embeddedText`,z.className=`plos-cs-form-textarea`,z.rows=2,z.placeholder=`Text that appears IN the video (overlay headlines, captions).`,L.appendChild(R),L.appendChild(z),o.appendChild(L);let B=document.createElement(`div`);B.className=`plos-cs-form-field`;let V=document.createElement(`label`);V.className=`plos-cs-form-label`,V.htmlFor=`plos-cs-video-tags-input`,V.textContent=`Tags (optional)`;let H=document.createElement(`div`);H.className=`plos-cs-chip-row`;let U=document.createElement(`input`);U.type=`text`,U.id=`plos-cs-video-tags-input`,U.className=`plos-cs-form-input`,U.placeholder=`Type a tag and press Enter`,B.appendChild(V),B.appendChild(H),B.appendChild(U),o.appendChild(B);let W=document.createElement(`div`);W.className=`plos-cs-form-error`,W.style.display=`none`,o.appendChild(W);let G=document.createElement(`div`);G.className=`plos-cs-form-actions`;let K=document.createElement(`button`);K.type=`button`,K.className=`plos-cs-form-button plos-cs-form-button-secondary`,K.textContent=`Cancel`,G.appendChild(K);let q=document.createElement(`button`);q.type=`submit`,q.className=`plos-cs-form-button plos-cs-form-button-primary`,q.textContent=`Save`,q.disabled=!0,G.appendChild(q),o.appendChild(G),a.appendChild(o);let J=[];function Y(){H.innerHTML=``;for(let e of J){let t=document.createElement(`span`);t.className=`plos-cs-chip`;let n=document.createElement(`span`);n.textContent=e,t.appendChild(n);let r=document.createElement(`button`);r.type=`button`,r.className=`plos-cs-chip-remove`,r.setAttribute(`aria-label`,`Remove tag ${e}`),r.textContent=`×`,r.addEventListener(`click`,()=>{J=J.filter(t=>t!==e),Y()}),t.appendChild(r),H.appendChild(t)}}function X(){let e=U.value.split(`,`),t=[],n=new Set;for(let r of[...J,...e]){if(typeof r!=`string`)continue;let e=r.trim();if(!e)continue;let i=e.toLowerCase();n.has(i)||(n.add(i),t.push(e))}J=t,U.value=``,Y()}U.addEventListener(`keydown`,e=>{if(e.key===`Enter`){e.preventDefault(),X();return}e.key===`,`&&(e.preventDefault(),X())}),U.addEventListener(`blur`,()=>{U.value.trim().length>0&&X()}),A.addEventListener(`change`,()=>{A.value===wi?(M.style.display=`block`,Z()):(M.style.display=`none`,N.value=``)});function Z(){let e=()=>{try{let e=r.activeElement;e&&e!==N&&e.blur?.()}catch{}N.focus({preventScroll:!0})};requestAnimationFrame(()=>{requestAnimationFrame(e)}),setTimeout(()=>{M.style.display!==`none`&&r.activeElement!==N&&e()},50)}function Q(e){e===null?(W.style.display=`none`,W.textContent=``):(W.style.display=`block`,W.textContent=e)}function ee(e){q.disabled=e,K.disabled=e,E.disabled=e,A.disabled=e,N.disabled=e,I.disabled=e,z.disabled=e,U.disabled=e,q.textContent=e?`Saving…`:`Save`}async function te(t){t.preventDefault(),Q(null);let n=A.value;n===wi&&(n=N.value);let r,i,a,o;e.kind===`direct`?(r=1,i=e.mimeTypeHint??``,a=e.src,o=`DIRECT_BYTES`):e.kind===`screen-recording`?(r=e.blob.size,i=gi(e.blob.type||e.mimeType),a=e.pageUrl,o=`SCREEN_RECORDING`):(r=0,i=``,a=e.src,o=`EMBED`);let s=bi({competitorUrlId:E.value,sourceType:o,originalSrcUrl:a,mimeType:i,fileSize:r,videoCategory:n,composition:I.value,embeddedText:z.value,tags:J});if(!s.ok){Q(Ni(s.reason));return}ee(!0);try{if(A.value===wi&&await x(e.projectId,{vocabularyType:`video-category`,value:s.payload.videoCategory}),e.kind===`direct`){let t=await ki(e.element),n=Ai(e.element),r=ri(e.mimeTypeHint)?e.mimeTypeHint:null;await C({projectId:e.projectId,urlId:E.value,sourceType:`DIRECT_BYTES`,srcUrl:e.src,thumbnailDataUrl:t,mimeTypeHint:r,clientId:s.payload.clientId,videoCategory:s.payload.videoCategory,composition:s.payload.composition,embeddedText:s.payload.embeddedText,tags:s.payload.tags,durationSeconds:n.duration,width:n.width,height:n.height})}else if(e.kind===`screen-recording`){let t=await hi({blob:e.blob,width:e.width,height:e.height});await _i({projectId:e.projectId,urlId:E.value,blob:e.blob,thumbnailBlob:t,pageUrl:e.pageUrl,durationSeconds:e.durationSeconds,width:e.width,height:e.height,videoCategory:s.payload.videoCategory,composition:s.payload.composition,embeddedText:s.payload.embeddedText,tags:s.payload.tags})}else await C({projectId:e.projectId,urlId:E.value,sourceType:`EMBED`,originalSrcUrl:e.src,clientId:s.payload.clientId,videoCategory:s.payload.videoCategory,composition:s.payload.composition,embeddedText:s.payload.embeddedText,tags:s.payload.tags});Mi(),e.onSaved(),re()}catch(e){Q(e instanceof u?`Couldn’t save (${e.status||`network`}): ${e.message}`:`Couldn’t save: unknown error.`),ee(!1)}}o.addEventListener(`submit`,e=>{te(e)}),K.addEventListener(`click`,()=>{re()}),a.addEventListener(`mousedown`,e=>{e.target===a&&re()});function ne(e){e.key===`Escape`&&(e.preventDefault(),re())}document.addEventListener(`keydown`,ne),r.appendChild(a),document.body.appendChild(n),setTimeout(()=>{E.focus()},0),(async()=>{try{let[n,r]=await Promise.all([p(e.projectId,t),b(e.projectId,`video-category`)]);if(E.innerHTML=``,n.length===0){let e=document.createElement(`option`);e.value=``,e.textContent=`No saved ${jr(t)??t} URLs yet — capture one via "+ Add" first`,E.appendChild(e),E.disabled=!0,q.disabled=!0}else{let r=document.createElement(`option`);r.value=``,r.textContent=`Pick a saved URL…`,E.appendChild(r);for(let e of n){let t=document.createElement(`option`);t.value=e.id,t.textContent=Ur(e),E.appendChild(t)}let i=On(t),a=qr(e.pageUrl,n,i?e=>i.canonicalProductUrl(e):void 0);a&&(E.value=a.id),E.disabled=!1}A.innerHTML=``;let i=document.createElement(`option`);i.value=``,i.textContent=`Pick a video category…`,A.appendChild(i);for(let e of r){let t=document.createElement(`option`);t.value=e.value,t.textContent=e.value,A.appendChild(t)}let a=document.createElement(`option`);a.value=wi,a.textContent=`+ Add new…`,A.appendChild(a),A.disabled=!1,v.style.display=`none`,n.length>0&&(q.disabled=!1)}catch(e){let t=e instanceof u?`Couldn’t load your saved URLs or video categories (${e.status||`network`}): ${e.message}`:`Couldn’t load your saved URLs or video categories.`;v.style.display=`none`,Q(t),q.disabled=!0}})();function re(){ie.destroy(),e.onClose()}let ie={destroy(){y.querySelectorAll(`video`).forEach(e=>{let t=e._plosBlobUrl;typeof t==`string`&&t.startsWith(`blob:`)&&URL.revokeObjectURL(t)}),n.parentNode&&n.parentNode.removeChild(n),document.removeEventListener(`keydown`,ne),Ci===ie&&(Ci=null)}};return Ci=ie,ie}async function ki(e){for(let t=0;t<Ei;t++){if(e.readyState>=2&&e.videoWidth>0&&e.videoHeight>0)try{let t=document.createElement(`canvas`);t.width=e.videoWidth,t.height=e.videoHeight;let n=t.getContext(`2d`);return n?(n.drawImage(e,0,0,t.width,t.height),t.toDataURL(`image/jpeg`,Di)):null}catch{return null}await ji(Ti)}return null}function Ai(e){return{duration:Number.isFinite(e.duration)&&e.duration>0?e.duration:null,width:e.videoWidth>0?e.videoWidth:null,height:e.videoHeight>0?e.videoHeight:null}}function ji(e){return new Promise(t=>setTimeout(t,e))}function Mi(){let e=document.createElement(`div`);e.textContent=`Saved!`,e.setAttribute(`role`,`status`),e.style.position=`fixed`,e.style.right=`16px`,e.style.bottom=`16px`,e.style.zIndex=`2147483647`,e.style.padding=`10px 14px`,e.style.background=`#16a34a`,e.style.color=`#fff`,e.style.borderRadius=`6px`,e.style.font=`500 13px/1.4 system-ui, sans-serif`,e.style.boxShadow=`0 4px 12px rgba(0,0,0,.25)`,document.body.appendChild(e),setTimeout(()=>{e.parentNode&&e.parentNode.removeChild(e)},1600)}function Ni(e){switch(e){case`url-required`:return`Pick the saved URL this video belongs to.`;case`source-type-invalid`:return`Internal error — unrecognized video source type.`;case`embed-url-required`:return`No embed URL detected — close this form and right-click a YouTube/Vimeo/etc. video.`;case`embed-url-unrecognized`:return`That URL doesn't look like a supported video embed (YouTube, Vimeo, Wistia, Brightcove, Dailymotion, or Loom).`;case`bytes-required`:return`No video bytes to upload — close this form and right-click a <video> again.`;case`video-mime-rejected`:return`Unsupported video type. PLOS accepts MP4, WebM, and QuickTime (MOV).`;case`video-too-large`:return`Video exceeds the 100 MB cap. Try the YouTube/Vimeo embed path instead, or upload the video to YouTube/Vimeo and paste the share URL.`;case`category-required`:return`Pick a video category, or add a new one via "+ Add new…".`}}function Pi(e,t){return{x:Math.min(e.x,t.x),y:Math.min(e.y,t.y),width:Math.abs(t.x-e.x),height:Math.abs(t.y-e.y)}}function Fi(e,t){let n=Math.max(0,Math.min(e.x,t.width)),r=Math.max(0,Math.min(e.y,t.height)),i=Math.max(0,Math.min(e.x+e.width,t.width)),a=Math.max(0,Math.min(e.y+e.height,t.height)),o=i-n,s=a-r;return o<=0||s<=0?null:{x:n,y:r,width:o,height:s}}function Ii(e){return e.width<8||e.height<8}function Li(e,t){let n=t>0?t:1,r=Math.round(e.x*n),i=Math.round(e.y*n),a=Math.round(e.width*n),o=Math.round(e.height*n);return{sourceX:r,sourceY:i,sourceWidth:a,sourceHeight:o,destWidth:a,destHeight:o}}var Ri=`plos-cs-region-screenshot-overlay`,zi=`plos-cs-region-screenshot-banner`,Bi=`plos-cs-region-screenshot-rect`,Vi=`plos-cs-region-screenshot-dim`,Hi=`plos-cs-region-screenshot-processing`,Ui=`Drag a rectangle around the module — release to capture, or press Esc to cancel. If the module is taller than your screen, scroll to fit it first; for very tall modules, capture in two halves.`,Wi=null;function Gi(e){Wi!==null&&(Wi.destroy(),Wi=null);let t=document.createElement(`div`);t.className=Ri,t.setAttribute(`role`,`presentation`);let n=document.createElement(`div`);n.className=zi,n.appendChild(document.createTextNode(Ui+` Cancel with `));let r=document.createElement(`kbd`);r.textContent=`Esc`,n.appendChild(r),n.appendChild(document.createTextNode(`.`)),t.appendChild(n);let i=document.createElement(`div`),a=document.createElement(`div`),o=document.createElement(`div`),s=document.createElement(`div`);[i,a,o,s].forEach(e=>{e.className=Vi,t.appendChild(e)}),Object.assign(i.style,{top:`0`,left:`0`,width:`100vw`,height:`100vh`});let c=document.createElement(`div`);c.className=Bi,c.style.display=`none`,t.appendChild(c),document.body.appendChild(t);let l=null,u=!1;function d(e){c.style.display=`block`,c.style.left=`${e.x}px`,c.style.top=`${e.y}px`,c.style.width=`${e.width}px`,c.style.height=`${e.height}px`;let t=window.innerWidth,n=window.innerHeight;Object.assign(i.style,{top:`0`,left:`0`,width:`${t}px`,height:`${e.y}px`}),Object.assign(a.style,{top:`${e.y}px`,left:`${e.x+e.width}px`,width:`${t-e.x-e.width}px`,height:`${e.height}px`}),Object.assign(o.style,{top:`${e.y+e.height}px`,left:`0`,width:`${t}px`,height:`${n-e.y-e.height}px`}),Object.assign(s.style,{top:`${e.y}px`,left:`0`,width:`${e.x}px`,height:`${e.height}px`})}function f(e){e.button===0&&(e.preventDefault(),l={x:e.clientX,y:e.clientY},u=!0)}function p(e){!u||l===null||(e.preventDefault(),d(Pi(l,{x:e.clientX,y:e.clientY})))}async function m(n){if(!u||l===null)return;n.preventDefault(),u=!1;let r=Pi(l,{x:n.clientX,y:n.clientY});l=null;let d=Fi(r,{width:window.innerWidth,height:window.innerHeight});if(d===null){e.onCancel(`rect-outside-viewport`);return}if(Ii(d)){e.onCancel(`rect-too-small`);return}c.style.display=`none`,[i,a,o,s].forEach(e=>{e.style.display=`none`});let f=document.createElement(`div`);f.className=Hi,f.textContent=`Capturing region…`,t.appendChild(f);try{let t=await Ki(d);e.onCaptured(t)}catch(t){let n=t instanceof Error?t.message:`Could not capture this region (unknown error).`;e.onError(n)}}function h(t){t.key===`Escape`&&(t.preventDefault(),e.onCancel(`escape`))}t.addEventListener(`mousedown`,f),t.addEventListener(`mousemove`,p),t.addEventListener(`mouseup`,m),window.addEventListener(`keydown`,h,!0);function g(){t.removeEventListener(`mousedown`,f),t.removeEventListener(`mousemove`,p),t.removeEventListener(`mouseup`,m),window.removeEventListener(`keydown`,h,!0),t.remove(),Wi===_&&(Wi=null)}let _={destroy:g};return Wi=_,_}async function Ki(e){let t=await qi((await w()).dataUrl),n=Li(e,window.devicePixelRatio||1),r=document.createElement(`canvas`);r.width=n.destWidth,r.height=n.destHeight;let i=r.getContext(`2d`);if(i===null)throw Error(`Could not create a 2D drawing context to crop the region.`);return i.drawImage(t,n.sourceX,n.sourceY,n.sourceWidth,n.sourceHeight,0,0,n.destWidth,n.destHeight),r.toDataURL(`image/png`)}function qi(e){return new Promise((t,n)=>{let r=new Image;r.onload=()=>t(r),r.onerror=()=>n(Error(`Could not decode the captured viewport image.`)),r.src=e})}var Ji=`plos-cs-video-region-record-overlay`,Yi=`plos-cs-video-region-record-banner`,Xi=`plos-cs-video-region-record-rect`,Zi=`plos-cs-video-region-record-dim`,Qi=`Drag a rectangle around the area to record — release to start recording. Audio + video; up to about 3 minutes per clip.`,$i=null;function ea(e){$i!==null&&($i.destroy(),$i=null);let t=document.createElement(`div`);t.className=Ji,t.setAttribute(`role`,`presentation`);let n=document.createElement(`div`);n.className=Yi,n.appendChild(document.createTextNode(Qi+` Cancel with `));let r=document.createElement(`kbd`);r.textContent=`Esc`,n.appendChild(r),n.appendChild(document.createTextNode(`.`)),t.appendChild(n);let i=document.createElement(`div`),a=document.createElement(`div`),o=document.createElement(`div`),s=document.createElement(`div`);[i,a,o,s].forEach(e=>{e.className=Zi,t.appendChild(e)}),Object.assign(i.style,{top:`0`,left:`0`,width:`100vw`,height:`100vh`});let c=document.createElement(`div`);c.className=Xi,c.style.display=`none`,t.appendChild(c),document.body.appendChild(t);let l=null,u=!1;function d(e){c.style.display=`block`,c.style.left=`${String(e.x)}px`,c.style.top=`${String(e.y)}px`,c.style.width=`${String(e.width)}px`,c.style.height=`${String(e.height)}px`;let t=window.innerWidth,n=window.innerHeight;Object.assign(i.style,{top:`0`,left:`0`,width:`${String(t)}px`,height:`${String(e.y)}px`}),Object.assign(a.style,{top:`${String(e.y)}px`,left:`${String(e.x+e.width)}px`,width:`${String(t-e.x-e.width)}px`,height:`${String(e.height)}px`}),Object.assign(o.style,{top:`${String(e.y+e.height)}px`,left:`0`,width:`${String(t)}px`,height:`${String(n-e.y-e.height)}px`}),Object.assign(s.style,{top:`${String(e.y)}px`,left:`0`,width:`${String(e.x)}px`,height:`${String(e.height)}px`})}function f(e){e.button===0&&(e.preventDefault(),l={x:e.clientX,y:e.clientY},u=!0)}function p(e){!u||l===null||(e.preventDefault(),d(Pi(l,{x:e.clientX,y:e.clientY})))}function m(t){if(!u||l===null)return;t.preventDefault(),u=!1;let n=Pi(l,{x:t.clientX,y:t.clientY});l=null;let r=Fi(n,{width:window.innerWidth,height:window.innerHeight});if(r===null){e.onCancel(`rect-outside-viewport`);return}if(Ii(r)){e.onCancel(`rect-too-small`);return}e.onRegionPicked(r)}function h(t){t.key===`Escape`&&(t.preventDefault(),e.onCancel(`escape`))}t.addEventListener(`mousedown`,f),t.addEventListener(`mousemove`,p),t.addEventListener(`mouseup`,m),window.addEventListener(`keydown`,h,!0);function g(){t.removeEventListener(`mousedown`,f),t.removeEventListener(`mousemove`,p),t.removeEventListener(`mouseup`,m),window.removeEventListener(`keydown`,h,!0),t.remove(),$i===_&&($i=null)}let _={destroy:g};return $i=_,_}var ta=`plos-cs-recording-indicator-region`,na=`plos-cs-recording-indicator-region--preparing`,ra=`plos-cs-recording-indicator-region--recording`,ia=`plos-cs-recording-indicator-toolbar`,aa=`plos-cs-recording-indicator-badge`,oa=`plos-cs-recording-indicator-badge--preparing`,sa=`plos-cs-recording-indicator-countdown`,ca=`plos-cs-recording-indicator-stop`,la=`plos-cs-recording-indicator-cancel`,ua=180;function da(e){let t=Math.max(0,Math.floor(e)),n=Math.floor(t/60),r=t%60,i=r<10?`0${String(r)}`:String(r);return`${String(n)}:${i}`}var fa=null;function pa(e){fa!==null&&(fa.destroy(),fa=null);let t=da(e.maxDurationSeconds??ua),n=document.createElement(`div`);n.className=`${ta} ${na}`,Object.assign(n.style,{left:`${String(e.region.x)}px`,top:`${String(e.region.y)}px`,width:`${String(e.region.width)}px`,height:`${String(e.region.height)}px`}),document.body.appendChild(n);let r=document.createElement(`div`);r.className=ia;let i=document.createElement(`span`);i.className=`${aa} ${oa}`,i.textContent=`PREPARING…`,r.appendChild(i);let a=document.createElement(`span`);a.className=sa,a.textContent=`0:00 / ${t}`,r.appendChild(a);let o=document.createElement(`button`);o.className=ca,o.type=`button`,o.textContent=`Stop`,o.addEventListener(`click`,()=>{e.onStopClicked()}),r.appendChild(o);let s=document.createElement(`button`);s.className=la,s.type=`button`,s.textContent=`Cancel`,s.addEventListener(`click`,()=>{e.onCancelClicked()}),r.appendChild(s),document.body.appendChild(r);let c=!1;function l(){c||(n.className=`${ta} ${ra}`,i.className=aa,i.textContent=`REC ●`)}function u(e){c||(a.textContent=`${da(e)} / ${t}`)}function d(){c||(c=!0,n.remove(),r.remove(),fa===f&&(fa=null))}let f={setRecording:l,setElapsed:u,destroy:d};return fa=f,f}var ma=c(o(((e,t)=>{(function(e,n){typeof define==`function`&&define.amd?define(n):t!==void 0&&t.exports?t.exports=n():window.ysFixWebmDuration=n()})(`fix-webm-duration`,function(){var e={172351395:{name:`EBML`,type:`Container`},646:{name:`EBMLVersion`,type:`Uint`},759:{name:`EBMLReadVersion`,type:`Uint`},754:{name:`EBMLMaxIDLength`,type:`Uint`},755:{name:`EBMLMaxSizeLength`,type:`Uint`},642:{name:`DocType`,type:`String`},647:{name:`DocTypeVersion`,type:`Uint`},645:{name:`DocTypeReadVersion`,type:`Uint`},108:{name:`Void`,type:`Binary`},63:{name:`CRC-32`,type:`Binary`},190023271:{name:`SignatureSlot`,type:`Container`},16010:{name:`SignatureAlgo`,type:`Uint`},16026:{name:`SignatureHash`,type:`Uint`},16037:{name:`SignaturePublicKey`,type:`Binary`},16053:{name:`Signature`,type:`Binary`},15963:{name:`SignatureElements`,type:`Container`},15995:{name:`SignatureElementList`,type:`Container`},9522:{name:`SignedElement`,type:`Binary`},139690087:{name:`Segment`,type:`Container`},21863284:{name:`SeekHead`,type:`Container`},3515:{name:`Seek`,type:`Container`},5035:{name:`SeekID`,type:`Binary`},5036:{name:`SeekPosition`,type:`Uint`},88713574:{name:`Info`,type:`Container`},13220:{name:`SegmentUID`,type:`Binary`},13188:{name:`SegmentFilename`,type:`String`},1882403:{name:`PrevUID`,type:`Binary`},1868715:{name:`PrevFilename`,type:`String`},2013475:{name:`NextUID`,type:`Binary`},1999803:{name:`NextFilename`,type:`String`},1092:{name:`SegmentFamily`,type:`Binary`},10532:{name:`ChapterTranslate`,type:`Container`},10748:{name:`ChapterTranslateEditionUID`,type:`Uint`},10687:{name:`ChapterTranslateCodec`,type:`Uint`},10661:{name:`ChapterTranslateID`,type:`Binary`},710577:{name:`TimecodeScale`,type:`Uint`},1161:{name:`Duration`,type:`Float`},1121:{name:`DateUTC`,type:`Date`},15273:{name:`Title`,type:`String`},3456:{name:`MuxingApp`,type:`String`},5953:{name:`WritingApp`,type:`String`},103:{name:`Timecode`,type:`Uint`},6228:{name:`SilentTracks`,type:`Container`},6359:{name:`SilentTrackNumber`,type:`Uint`},39:{name:`Position`,type:`Uint`},43:{name:`PrevSize`,type:`Uint`},35:{name:`SimpleBlock`,type:`Binary`},32:{name:`BlockGroup`,type:`Container`},33:{name:`Block`,type:`Binary`},34:{name:`BlockVirtual`,type:`Binary`},13729:{name:`BlockAdditions`,type:`Container`},38:{name:`BlockMore`,type:`Container`},110:{name:`BlockAddID`,type:`Uint`},37:{name:`BlockAdditional`,type:`Binary`},27:{name:`BlockDuration`,type:`Uint`},122:{name:`ReferencePriority`,type:`Uint`},123:{name:`ReferenceBlock`,type:`Int`},125:{name:`ReferenceVirtual`,type:`Int`},36:{name:`CodecState`,type:`Binary`},13730:{name:`DiscardPadding`,type:`Int`},14:{name:`Slices`,type:`Container`},104:{name:`TimeSlice`,type:`Container`},76:{name:`LaceNumber`,type:`Uint`},77:{name:`FrameNumber`,type:`Uint`},75:{name:`BlockAdditionID`,type:`Uint`},78:{name:`Delay`,type:`Uint`},79:{name:`SliceDuration`,type:`Uint`},72:{name:`ReferenceFrame`,type:`Container`},73:{name:`ReferenceOffset`,type:`Uint`},74:{name:`ReferenceTimeCode`,type:`Uint`},47:{name:`EncryptedBlock`,type:`Binary`},106212971:{name:`Tracks`,type:`Container`},46:{name:`TrackEntry`,type:`Container`},87:{name:`TrackNumber`,type:`Uint`},13253:{name:`TrackUID`,type:`Uint`},3:{name:`TrackType`,type:`Uint`},57:{name:`FlagEnabled`,type:`Uint`},8:{name:`FlagDefault`,type:`Uint`},5546:{name:`FlagForced`,type:`Uint`},28:{name:`FlagLacing`,type:`Uint`},11751:{name:`MinCache`,type:`Uint`},11768:{name:`MaxCache`,type:`Uint`},254851:{name:`DefaultDuration`,type:`Uint`},216698:{name:`DefaultDecodedFieldDuration`,type:`Uint`},209231:{name:`TrackTimecodeScale`,type:`Float`},4991:{name:`TrackOffset`,type:`Int`},5614:{name:`MaxBlockAdditionID`,type:`Uint`},4974:{name:`Name`,type:`String`},177564:{name:`Language`,type:`String`},6:{name:`CodecID`,type:`String`},9122:{name:`CodecPrivate`,type:`Binary`},362120:{name:`CodecName`,type:`String`},13382:{name:`AttachmentLink`,type:`Uint`},1742487:{name:`CodecSettings`,type:`String`},1785920:{name:`CodecInfoURL`,type:`String`},438848:{name:`CodecDownloadURL`,type:`String`},42:{name:`CodecDecodeAll`,type:`Uint`},12203:{name:`TrackOverlay`,type:`Uint`},5802:{name:`CodecDelay`,type:`Uint`},5819:{name:`SeekPreRoll`,type:`Uint`},9764:{name:`TrackTranslate`,type:`Container`},9980:{name:`TrackTranslateEditionUID`,type:`Uint`},9919:{name:`TrackTranslateCodec`,type:`Uint`},9893:{name:`TrackTranslateTrackID`,type:`Binary`},96:{name:`Video`,type:`Container`},26:{name:`FlagInterlaced`,type:`Uint`},5048:{name:`StereoMode`,type:`Uint`},5056:{name:`AlphaMode`,type:`Uint`},5049:{name:`OldStereoMode`,type:`Uint`},48:{name:`PixelWidth`,type:`Uint`},58:{name:`PixelHeight`,type:`Uint`},5290:{name:`PixelCropBottom`,type:`Uint`},5307:{name:`PixelCropTop`,type:`Uint`},5324:{name:`PixelCropLeft`,type:`Uint`},5341:{name:`PixelCropRight`,type:`Uint`},5296:{name:`DisplayWidth`,type:`Uint`},5306:{name:`DisplayHeight`,type:`Uint`},5298:{name:`DisplayUnit`,type:`Uint`},5299:{name:`AspectRatioType`,type:`Uint`},963876:{name:`ColourSpace`,type:`Binary`},1029411:{name:`GammaValue`,type:`Float`},230371:{name:`FrameRate`,type:`Float`},97:{name:`Audio`,type:`Container`},53:{name:`SamplingFrequency`,type:`Float`},14517:{name:`OutputSamplingFrequency`,type:`Float`},31:{name:`Channels`,type:`Uint`},15739:{name:`ChannelPositions`,type:`Binary`},8804:{name:`BitDepth`,type:`Uint`},98:{name:`TrackOperation`,type:`Container`},99:{name:`TrackCombinePlanes`,type:`Container`},100:{name:`TrackPlane`,type:`Container`},101:{name:`TrackPlaneUID`,type:`Uint`},102:{name:`TrackPlaneType`,type:`Uint`},105:{name:`TrackJoinBlocks`,type:`Container`},109:{name:`TrackJoinUID`,type:`Uint`},64:{name:`TrickTrackUID`,type:`Uint`},65:{name:`TrickTrackSegmentUID`,type:`Binary`},70:{name:`TrickTrackFlag`,type:`Uint`},71:{name:`TrickMasterTrackUID`,type:`Uint`},68:{name:`TrickMasterTrackSegmentUID`,type:`Binary`},11648:{name:`ContentEncodings`,type:`Container`},8768:{name:`ContentEncoding`,type:`Container`},4145:{name:`ContentEncodingOrder`,type:`Uint`},4146:{name:`ContentEncodingScope`,type:`Uint`},4147:{name:`ContentEncodingType`,type:`Uint`},4148:{name:`ContentCompression`,type:`Container`},596:{name:`ContentCompAlgo`,type:`Uint`},597:{name:`ContentCompSettings`,type:`Binary`},4149:{name:`ContentEncryption`,type:`Container`},2017:{name:`ContentEncAlgo`,type:`Uint`},2018:{name:`ContentEncKeyID`,type:`Binary`},2019:{name:`ContentSignature`,type:`Binary`},2020:{name:`ContentSigKeyID`,type:`Binary`},2021:{name:`ContentSigAlgo`,type:`Uint`},2022:{name:`ContentSigHashAlgo`,type:`Uint`},206814059:{name:`Cues`,type:`Container`},59:{name:`CuePoint`,type:`Container`},51:{name:`CueTime`,type:`Uint`},55:{name:`CueTrackPositions`,type:`Container`},119:{name:`CueTrack`,type:`Uint`},113:{name:`CueClusterPosition`,type:`Uint`},112:{name:`CueRelativePosition`,type:`Uint`},50:{name:`CueDuration`,type:`Uint`},4984:{name:`CueBlockNumber`,type:`Uint`},106:{name:`CueCodecState`,type:`Uint`},91:{name:`CueReference`,type:`Container`},22:{name:`CueRefTime`,type:`Uint`},23:{name:`CueRefCluster`,type:`Uint`},4959:{name:`CueRefNumber`,type:`Uint`},107:{name:`CueRefCodecState`,type:`Uint`},155296873:{name:`Attachments`,type:`Container`},8615:{name:`AttachedFile`,type:`Container`},1662:{name:`FileDescription`,type:`String`},1646:{name:`FileName`,type:`String`},1632:{name:`FileMimeType`,type:`String`},1628:{name:`FileData`,type:`Binary`},1710:{name:`FileUID`,type:`Uint`},1653:{name:`FileReferral`,type:`Binary`},1633:{name:`FileUsedStartTime`,type:`Uint`},1634:{name:`FileUsedEndTime`,type:`Uint`},4433776:{name:`Chapters`,type:`Container`},1465:{name:`EditionEntry`,type:`Container`},1468:{name:`EditionUID`,type:`Uint`},1469:{name:`EditionFlagHidden`,type:`Uint`},1499:{name:`EditionFlagDefault`,type:`Uint`},1501:{name:`EditionFlagOrdered`,type:`Uint`},54:{name:`ChapterAtom`,type:`Container`},13252:{name:`ChapterUID`,type:`Uint`},5716:{name:`ChapterStringUID`,type:`String`},17:{name:`ChapterTimeStart`,type:`Uint`},18:{name:`ChapterTimeEnd`,type:`Uint`},24:{name:`ChapterFlagHidden`,type:`Uint`},1432:{name:`ChapterFlagEnabled`,type:`Uint`},11879:{name:`ChapterSegmentUID`,type:`Binary`},11964:{name:`ChapterSegmentEditionUID`,type:`Uint`},9155:{name:`ChapterPhysicalEquiv`,type:`Uint`},15:{name:`ChapterTrack`,type:`Container`},9:{name:`ChapterTrackNumber`,type:`Uint`},0:{name:`ChapterDisplay`,type:`Container`},5:{name:`ChapString`,type:`String`},892:{name:`ChapLanguage`,type:`String`},894:{name:`ChapCountry`,type:`String`},10564:{name:`ChapProcess`,type:`Container`},10581:{name:`ChapProcessCodecID`,type:`Uint`},1293:{name:`ChapProcessPrivate`,type:`Binary`},10513:{name:`ChapProcessCommand`,type:`Container`},10530:{name:`ChapProcessTime`,type:`Uint`},10547:{name:`ChapProcessData`,type:`Binary`},39109479:{name:`Tags`,type:`Container`},13171:{name:`Tag`,type:`Container`},9152:{name:`Targets`,type:`Container`},10442:{name:`TargetTypeValue`,type:`Uint`},9162:{name:`TargetType`,type:`String`},9157:{name:`TagTrackUID`,type:`Uint`},9161:{name:`TagEditionUID`,type:`Uint`},9156:{name:`TagChapterUID`,type:`Uint`},9158:{name:`TagAttachmentUID`,type:`Uint`},10184:{name:`SimpleTag`,type:`Container`},1443:{name:`TagName`,type:`String`},1146:{name:`TagLanguage`,type:`String`},1156:{name:`TagDefault`,type:`Uint`},1159:{name:`TagString`,type:`String`},1157:{name:`TagBinary`,type:`Binary`}};function t(e,t){e.prototype=Object.create(t.prototype),e.prototype.constructor=e}function n(e,t){this.name=e||`Unknown`,this.type=t||`Unknown`}n.prototype.updateBySource=function(){},n.prototype.setSource=function(e){this.source=e,this.updateBySource()},n.prototype.updateByData=function(){},n.prototype.setData=function(e){this.data=e,this.updateByData()};function r(e,t){n.call(this,e,t||`Uint`)}t(r,n);function i(e){return e.length%2==1?`0`+e:e}r.prototype.updateBySource=function(){this.data=``;for(var e=0;e<this.source.length;e++){var t=this.source[e].toString(16);this.data+=i(t)}},r.prototype.updateByData=function(){var e=this.data.length/2;this.source=new Uint8Array(e);for(var t=0;t<e;t++){var n=this.data.substr(t*2,2);this.source[t]=parseInt(n,16)}},r.prototype.getValue=function(){return parseInt(this.data,16)},r.prototype.setValue=function(e){this.setData(i(e.toString(16)))};function a(e,t){n.call(this,e,t||`Float`)}t(a,n),a.prototype.getFloatArrayType=function(){return this.source&&this.source.length===4?Float32Array:Float64Array},a.prototype.updateBySource=function(){var e=this.source.reverse(),t=new(this.getFloatArrayType())(e.buffer);this.data=t[0]},a.prototype.updateByData=function(){var e=new(this.getFloatArrayType())([this.data]),t=new Uint8Array(e.buffer);this.source=t.reverse()},a.prototype.getValue=function(){return this.data},a.prototype.setValue=function(e){this.setData(e)};function o(e,t){n.call(this,e,t||`Container`)}t(o,n),o.prototype.readByte=function(){return this.source[this.offset++]},o.prototype.readUint=function(){for(var e=this.readByte(),t=8-e.toString(2).length,n=e-(1<<7-t),r=0;r<t;r++)n*=256,n+=this.readByte();return n},o.prototype.updateBySource=function(){for(this.data=[],this.offset=0;this.offset<this.source.length;this.offset=s){var t=this.readUint(),i=this.readUint(),s=Math.min(this.offset+i,this.source.length),c=this.source.slice(this.offset,s),l=e[t]||{name:`Unknown`,type:`Unknown`},u=n;switch(l.type){case`Container`:u=o;break;case`Uint`:u=r;break;case`Float`:u=a;break}var d=new u(l.name,l.type);d.setSource(c),this.data.push({id:t,idHex:t.toString(16),data:d})}},o.prototype.writeUint=function(e,t){for(var n=1,r=128;e>=r&&n<8;n++,r*=128);if(!t)for(var i=r+e,a=n-1;a>=0;a--){var o=i%256;this.source[this.offset+a]=o,i=(i-o)/256}this.offset+=n},o.prototype.writeSections=function(e){this.offset=0;for(var t=0;t<this.data.length;t++){var n=this.data[t],r=n.data.source,i=r.length;this.writeUint(n.id,e),this.writeUint(i,e),e||this.source.set(r,this.offset),this.offset+=i}return this.offset},o.prototype.updateByData=function(){var e=this.writeSections(`draft`);this.source=new Uint8Array(e),this.writeSections()},o.prototype.getSectionById=function(e){for(var t=0;t<this.data.length;t++){var n=this.data[t];if(n.id===e)return n.data}return null};function s(e){o.call(this,`File`,`File`),this.setSource(e)}t(s,o),s.prototype.fixDuration=function(e,t){var n=t&&t.logger;n===void 0?n=function(e){console.log(e)}:n||=function(){};var r=this.getSectionById(139690087);if(!r)return n(`[fix-webm-duration] Segment section is missing`),!1;var i=r.getSectionById(88713574);if(!i)return n(`[fix-webm-duration] Info section is missing`),!1;var o=i.getSectionById(710577);if(!o)return n(`[fix-webm-duration] TimecodeScale section is missing`),!1;var s=i.getSectionById(1161);if(s)if(s.getValue()<=0)n(`[fix-webm-duration] Duration section is present, but the value is ${s.getValue()}`),s.setValue(e);else return n(`[fix-webm-duration] Duration section is present, and the value is ${s.getValue()}`),!1;else n(`[fix-webm-duration] Duration section is missing`),s=new a(`Duration`,`Float`),s.setValue(e),i.data.push({id:1161,data:s});return o.setValue(1e6),i.updateByData(),r.updateByData(),this.updateByData(),!0},s.prototype.toBlob=function(e){return new Blob([this.source.buffer],{type:e||`video/webm`})};function c(e,t,n,r){if(typeof n==`object`&&(r=n,n=void 0),!n)return new Promise(function(n){c(e,t,n,r)});try{var i=new FileReader;i.onloadend=function(){try{var a=new s(new Uint8Array(i.result));a.fixDuration(t,r)&&(e=a.toBlob(e.type))}catch{}n(e)},i.readAsArrayBuffer(e)}catch{n(e)}}return c.default=c,c})}))(),1),ha=[`video/webm;codecs=vp9,opus`,`video/webm;codecs=vp8,opus`,`video/webm`],ga=25e5,_a=1e3;function va(){return{getDisplayMedia(e){let t={...e,selfBrowserSurface:`include`};return navigator.mediaDevices.getDisplayMedia(t)},createMediaRecorder(e,t){return new MediaRecorder(e,t)},isTypeSupported(e){return typeof MediaRecorder<`u`&&MediaRecorder.isTypeSupported(e)},now(){return performance.now()},setTimeout(e,t){return globalThis.setTimeout(e,t)},clearTimeout(e){globalThis.clearTimeout(e)},setInterval(e,t){return globalThis.setInterval(e,t)},clearInterval(e){globalThis.clearInterval(e)},cropStreamToRegion:ya,fixWebmDuration(e,t){return(0,ma.default)(e,t)}}}function ya(e,t){let n=document.createElement(`video`);n.muted=!0,n.playsInline=!0,n.srcObject=e,n.style.position=`fixed`,n.style.top=`0`,n.style.left=`0`,n.style.width=`1px`,n.style.height=`1px`,n.style.opacity=`0`,n.style.pointerEvents=`none`,n.style.zIndex=`-2147483648`,document.body.appendChild(n),n.play().catch(()=>{});let r=document.createElement(`canvas`);r.width=t.width,r.height=t.height;let i=r.getContext(`2d`),a=0;function o(){i!==null&&n.readyState>=2&&i.drawImage(n,t.x,t.y,t.width,t.height,0,0,t.width,t.height),a=requestAnimationFrame(o)}a=requestAnimationFrame(o);let s=r.captureStream(30);for(let t of e.getAudioTracks())s.addTrack(t);return{stream:s,teardown(){a!==0&&(cancelAnimationFrame(a),a=0);try{n.pause()}catch{}n.srcObject=null,n.parentNode!==null&&n.parentNode.removeChild(n)}}}function ba(e){if(e.width<8||e.height<8)throw Error(`Region too small: ${String(e.width)}x${String(e.height)}; minimum is 8px on each side.`);return{x:Math.round(e.x),y:Math.round(e.y),width:e.width%2==0?e.width:e.width+1,height:e.height%2==0?e.height:e.height+1}}function xa(e){for(let t of ha)if(e(t))return t;return`video/webm`}function Sa(e=va()){let t=`idle`,n=null,r=null,i=null,a=[],o=``,s={x:0,y:0,width:0,height:0},c=0,l=null,u=null,d=null,f=!1;function p(){if(r!==null){try{r.teardown()}catch{}r=null}if(n!==null){try{for(let e of n.getTracks())e.stop()}catch{}n=null}}function m(){l!==null&&(e.clearTimeout(l),l=null),u!==null&&(e.clearInterval(u),u=null)}async function h(){if(f)return;f=!0;let n=(e.now()-c)/1e3,r=new Blob(a,{type:o});t=`stopped`,p(),m();let i=r;if(e.fixWebmDuration)try{i=await e.fixWebmDuration(r,n*1e3)}catch{i=r}d?.onStopped({blob:i,mimeType:o,durationSeconds:n,region:s})}function g(e,n){if(!(t===`canceled`||t===`stopped`)){if(t=`canceled`,m(),i!==null&&i.state!==`inactive`)try{i.stop()}catch{}p(),d?.onCanceled?.(e,n)}}async function _(p){if(t!==`idle`)throw Error(`Cannot start: controller is already in state '${t}'.`);s=ba(p.region),d=p,a=[],f=!1,t=`asking-tab`;let m;try{m=await e.getDisplayMedia({video:!0,audio:!0})}catch(e){t=`canceled`;let n=e instanceof Error?e.message:`getDisplayMedia rejected`;p.onCanceled?.(`dialog-dismissed`,n);return}if(t!==`asking-tab`){try{for(let e of m.getTracks())e.stop()}catch{}return}n=m;let _=m;if(e.cropStreamToRegion)try{r=e.cropStreamToRegion(m,s),_=r.stream}catch(e){g(`recorder-error`,e instanceof Error?e.message:`canvas-crop pipeline failed`);return}o=xa(e.isTypeSupported);try{i=e.createMediaRecorder(_,{mimeType:o,videoBitsPerSecond:ga})}catch(e){g(`recorder-error`,e instanceof Error?e.message:`MediaRecorder construction failed`);return}i.ondataavailable=e=>{e.data.size>0&&a.push(e.data)},i.onerror=e=>{g(`recorder-error`,e.error?.message??`MediaRecorder error`)},i.onstop=()=>{t===`recording`&&h()},c=e.now(),i.start(_a),t=`recording`;let y=p.maxDurationSeconds??180;if(l=e.setTimeout(()=>{v()},y*1e3),p.onTick){let t=0,n=p.onTick;u=e.setInterval(()=>{t+=1,n(t)},1e3)}p.onStarted?.()}function v(){t===`recording`&&(m(),i!==null&&i.state!==`inactive`?i.stop():h())}function y(){g(`user-cancel`)}function b(){return t}return{start:_,stop:v,cancel:y,getState:b}}var Ca=10;function wa(e){if(!e)return null;let t=e,n=0;for(;t&&n<=Ca;){if(Ta(t))return Ea(t);let e=t.querySelector(`img`);if(e&&Ta(e)){let t=Ea(e);if(t)return t}t=t.parentElement,n+=1}return null}function Ta(e){if(e.tagName!==`IMG`)return!1;let t=e;return!!(t.currentSrc||t.src)}function Ea(e){return e.currentSrc||e.src||null}var Da=10;function Oa(e,t){if(!e)return{kind:`none`};let n=ka(e);if(n.kind!==`none`)return n;let r=t?.clickX,i=t?.clickY;if(typeof r!=`number`||typeof i!=`number`)return{kind:`none`};let a=(t?.getStackedElements??Aa)(r,i);for(let t of a){if(t===e)continue;let n=ka(t);if(n.kind!==`none`)return n}return{kind:`none`}}function ka(e){let t=e,n=0;for(;t&&n<=Da;){if(ja(t)){let e=Na(t);if(e)return e}let e=t.querySelector(`video`);if(e&&ja(e)){let t=Na(e);if(t)return t}if(Ma(t)){let e=Pa(t);if(e)return e}let r=t.querySelectorAll(`iframe`);for(let e of Array.from(r)){let t=Pa(e);if(t)return t}t=t.parentElement,n+=1}return{kind:`none`}}function Aa(e,t){return typeof document>`u`||!document.elementsFromPoint?[]:Array.from(document.elementsFromPoint(e,t))}function ja(e){if(e.tagName!==`VIDEO`)return!1;let t=e;if(t.currentSrc||t.src)return!0;for(let e of Array.from(t.querySelectorAll(`source`))){let t=e.getAttribute(`src`);if(t&&t.trim().length>0)return!0}return!1}function Ma(e){return e.tagName===`IFRAME`}function Na(e){let t=e.currentSrc||e.src||``;if(!t)for(let n of Array.from(e.querySelectorAll(`source`))){let e=n.getAttribute(`src`);if(e&&e.trim().length>0){t=e.trim();break}}if(!t)return null;let n=null,r=e.querySelectorAll(`source`);for(let e of Array.from(r)){let t=e.getAttribute(`type`);if(t&&t.trim()){n=t.trim().toLowerCase();break}}return{kind:`direct`,src:t,mimeType:n,element:e}}function Pa(e){let t=e.src||``;if(!t)return null;let n=yi(t);return n?{kind:`embed`,platform:n,src:t}:null}var Fa=`plos-cs-capture-failure-toast`,Ia=4e3,La=null;function $(e){if(typeof document>`u`||!document.body)return;let t=document.getElementById(Fa);t||(t=document.createElement(`div`),t.id=Fa,Object.assign(t.style,{position:`fixed`,bottom:`24px`,right:`24px`,maxWidth:`320px`,padding:`12px 16px`,background:`#1f2937`,color:`#f9fafb`,fontFamily:`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`,fontSize:`14px`,lineHeight:`1.4`,borderRadius:`6px`,boxShadow:`0 4px 12px rgba(0,0,0,0.25)`,zIndex:`999991`,pointerEvents:`none`,opacity:`0`,transition:`opacity 150ms ease-out`}),document.body.appendChild(t),t.offsetHeight,t.style.opacity=`1`),t.textContent=e,La!==null&&clearTimeout(La),La=setTimeout(()=>{let e=document.getElementById(Fa);e&&(e.style.opacity=`0`,setTimeout(()=>{e.remove()},200),La=null)},Ia)}function Ra(e){if(typeof e!=`object`||!e)return!1;let t=e;return t.kind===`open-url-add-form`?typeof t.href==`string`:t.kind===`open-text-capture-form`?typeof t.selectedText==`string`&&typeof t.pageUrl==`string`:t.kind===`open-image-capture-form`||t.kind===`open-video-capture-form`?typeof t.srcUrl==`string`&&typeof t.pageUrl==`string`:t.kind===`enter-region-screenshot-mode`||t.kind===`enter-video-region-record-mode`||t.kind===`start-review-scrape`?typeof t.pageUrl==`string`:!1}var za=[{hex:`#FFEB3B`,name:`Banana yellow`,isLight:!0},{hex:`#F8BBD0`,name:`Rose pink`,isLight:!0},{hex:`#B2EBF2`,name:`Sky cyan`,isLight:!0},{hex:`#C8E6C9`,name:`Mint green`,isLight:!0},{hex:`#E1BEE7`,name:`Lilac`,isLight:!0},{hex:`#FFCCBC`,name:`Peach`,isLight:!0},{hex:`#DCEDC8`,name:`Lime`,isLight:!0},{hex:`#FFAB91`,name:`Coral`,isLight:!0},{hex:`#B2DFDB`,name:`Sage`,isLight:!0},{hex:`#C5CAE9`,name:`Periwinkle`,isLight:!0},{hex:`#1976D2`,name:`Royal blue`,isLight:!1},{hex:`#388E3C`,name:`Forest green`,isLight:!1},{hex:`#C2185B`,name:`Crimson`,isLight:!1},{hex:`#303F9F`,name:`Navy`,isLight:!1},{hex:`#E64A19`,name:`Burnt orange`,isLight:!1},{hex:`#00796B`,name:`Teal`,isLight:!1},{hex:`#512DA8`,name:`Indigo`,isLight:!1},{hex:`#AD1457`,name:`Magenta`,isLight:!1},{hex:`#7B1FA2`,name:`Burgundy`,isLight:!1},{hex:`#455A64`,name:`Slate`,isLight:!1}];function Ba(e){let t=e.trim().toUpperCase(),n=za.find(e=>e.hex===t);return n?n.isLight?`#000000`:`#FFFFFF`:Va(t)>.5?`#000000`:`#FFFFFF`}function Va(e){let t=/^#([0-9A-F]{6})$/i.exec(e.trim());if(!t)return .5;let n=t[1],[r,i,a]=[parseInt(n.slice(0,2),16)/255,parseInt(n.slice(2,4),16)/255,parseInt(n.slice(4,6),16)/255].map(e=>e<=.03928?e/12.92:((e+.055)/1.055)**2.4);return .2126*r+.7152*i+.0722*a}var Ha=`plos-cs-highlight`,Ua=`data-plos-cs-highlight-term`,Wa=new Set([`SCRIPT`,`STYLE`,`NOSCRIPT`,`TEXTAREA`,`INPUT`,`IFRAME`,`SVG`,`MATH`,`CODE`,`PRE`]),Ga=`plos-cs-`,Ka=50,qa=500;function Ja(e){return e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`)}function Ya(e){if(!e||e.length===0)return null;let t=e.map(e=>e?.term?.trim()).filter(e=>typeof e==`string`&&e.length>0);if(t.length===0)return null;t.sort((e,t)=>t.length-e.length);let n=t.map(e=>Ja(e).replace(/ /g,`\\s+`));return RegExp(`\\b(?:${n.join(`|`)})\\b`,`gi`)}function Xa(e){let t=new Map;for(let n of e)n?.term?.trim()&&t.set(n.term.trim().toLowerCase(),n.color);return t}function Za(e){for(let t of e.classList)if(t.startsWith(Ga))return!0;return!1}function Qa(e){if(Wa.has(e.tagName)||Za(e)||e.classList.contains(Ha))return!0;let t=e.getAttribute(`contenteditable`);return t!==null&&t!==`false`}async function $a(e,t,n={}){let r=n.chunkSize??qa,i=n.signal,a=n.yieldFn??eo,o=0;for(let n of e){if(i?.cancelled)return;t(n),o++,o%r===0&&o<e.length&&await a()}}function eo(){return new Promise(e=>{let t=window;typeof t.requestIdleCallback==`function`?t.requestIdleCallback(()=>e()):setTimeout(()=>e(),0)})}async function to(e,t,n,r={}){if(!e)return;let i=r.signal,a=t.source,o=t.flags,s=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode(t){let n=t.parentElement;if(!n)return NodeFilter.FILTER_REJECT;let r=n;for(;r;){if(Qa(r))return NodeFilter.FILTER_REJECT;if(r===e)break;r=r.parentElement}return!t.nodeValue||t.nodeValue.trim().length===0?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),c=[],l=s.nextNode();for(;l;){if(i?.cancelled)return;c.push(l),l=s.nextNode()}await $a(c,e=>no(e,a,o,n),r)}function no(e,t,n,r){let i=e.nodeValue;if(!i)return;let a=new RegExp(t,n),o=[],s;for(;(s=a.exec(i))!==null;)o.push({start:s.index,end:s.index+s[0].length,matched:s[0]}),s[0].length===0&&a.lastIndex++;if(o.length===0)return;let c=document.createDocumentFragment(),l=0;for(let e of o){e.start>l&&c.appendChild(document.createTextNode(i.slice(l,e.start)));let t=document.createElement(`mark`);t.className=Ha,t.setAttribute(Ua,e.matched);let n=r.get(e.matched.trim().toLowerCase());n&&(t.style.backgroundColor=n,t.style.color=Ba(n)),t.textContent=e.matched,c.appendChild(t),l=e.end}l<i.length&&c.appendChild(document.createTextNode(i.slice(l))),e.replaceWith(c)}function ro(e){let t=5381;for(let n of e){let e=n.matched;for(let n=0;n<e.length;n++)t=(t<<5)+t+e.charCodeAt(n)|0;t=(t<<5)+t+n.index|0}return`${e.length}:${t}`}function io(e,t){let n=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode(t){let n=t.parentElement;if(!n)return NodeFilter.FILTER_REJECT;let r=n;for(;r;){if(Qa(r))return NodeFilter.FILTER_REJECT;if(r===e)break;r=r.parentElement}return!t.nodeValue||t.nodeValue.trim().length===0?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),r=[],i=t.source,a=t.flags,o=n.nextNode();for(;o;){let e=o.nodeValue||``,t=new RegExp(i,a),s;for(;(s=t.exec(e))!==null;)r.push({matched:s[0],index:s.index}),s[0].length===0&&t.lastIndex++;o=n.nextNode()}return ro(r)}function ao(e){return!e||e.isCollapsed||e.rangeCount===0?!1:e.toString().trim().length>0}function oo(e=document.body){if(!e)return;let t=e.querySelectorAll(`.${Ha}`),n=new Set;t.forEach(e=>{let t=e.parentNode;if(!t)return;let r=e.textContent??``;t.replaceChild(document.createTextNode(r),e),t instanceof Element&&n.add(t)}),n.forEach(e=>e.normalize())}async function so(e,t={}){let n=t.muteMutationObserver??(async e=>e()),r=[],i=null,a=new Map,o=!1,s=null,c=null,l=!1;function u(){return typeof window>`u`||typeof window.getSelection!=`function`?null:window.getSelection()}async function d(){if(o)return;let t=await _n(e);t.length>Ka&&(console.warn(`[PLOS] highlightTerms count (${t.length}) exceeds soft cap (${Ka}); only the first ${Ka} will highlight.`),t=t.slice(0,Ka)),r=t,i=Ya(r),a=Xa(r)}async function f(){if(!o){if(ao(u())){l=!0;return}if(i!==null){if(io(document.body,i)===c)return}else if(c===null)return;await n(async()=>{if(s!==null&&(s.cancelled=!0,s=null),!i){oo(),c=null;return}oo();let e={cancelled:!1};s=e;try{await to(document.body,i,a,{signal:e}),!e.cancelled&&!o&&(c=io(document.body,i))}finally{s===e&&(s=null)}})}}await d();let p=window;typeof p.requestIdleCallback==`function`?p.requestIdleCallback(()=>{f()}):setTimeout(()=>{f()},0);let m=`highlightTerms:${e}`,h=(e,t)=>{t===`local`&&m in e&&(async()=>{await d(),c=null,f()})()};typeof chrome<`u`&&chrome.storage?.onChanged&&chrome.storage.onChanged.addListener(h);let g=()=>{o||l&&(ao(u())||(l=!1,f()))};return typeof document<`u`&&document.addEventListener&&document.addEventListener(`selectionchange`,g),{refresh:f,destroy(){o=!0,s!==null&&(s.cancelled=!0,s=null),typeof chrome<`u`&&chrome.storage?.onChanged&&chrome.storage.onChanged.removeListener(h),typeof document<`u`&&document.removeEventListener&&document.removeEventListener(`selectionchange`,g),oo()}}}var co=`data-plos-cs-handled`,lo=250,uo=150,fo=`data-plos-cs-active`;async function po(){if(document.body.getAttribute(fo)===`1`)return()=>{};document.body.setAttribute(fo,`1`);let e=null,t=null,n=null,r=r=>{let i=r.target instanceof Element?r.target:null;e=wa(i),n=Oa(i,{clickX:r.clientX,clickY:r.clientY}),t=null;try{let e=window.getSelection();if(e!==null&&!e.isCollapsed&&e.rangeCount>0&&document.body!==null){let n=wr(e.getRangeAt(0),document.body);n!==null&&(t=ur(n))}}catch{}};document.addEventListener(`contextmenu`,r,{capture:!0});function i(){document.removeEventListener(`contextmenu`,r,{capture:!0})}let[a,o]=await Promise.all([hn(),gn()]);if(!a||!o)return i(),mo(),()=>void 0;let s=a,c=o,l=On(c);if(!l)return i(),mo(),()=>void 0;let u=l;if(kn(location.hostname)?.platform!==u.platform)return i(),mo(),()=>void 0;let d=new Set,_=new Map,v=[];try{let e=await p(s,c);d=jn(e,e=>u.canonicalProductUrl(e));for(let t of e){if(typeof t.url!=`string`||typeof t.id!=`string`)continue;let e=An(u.canonicalProductUrl(t.url)??t.url);e!==``&&_.set(e,t.id)}v=e.map(e=>({id:e.id,url:e.url,reviewScrapeCap:e.reviewScrapeCap,productName:e.productName}))}catch(e){console.warn(`[PLOS] could not load saved URLs for recognition`,e)}let b=null;try{b=(await f()).find(e=>e.id===s)?.name??null}catch{}Fn();let x=null;async function S(e){x?.disconnect();try{return await e()}finally{x?.takeRecords(),x?.observe(document.body,{childList:!0,subtree:!0})}}let C=null;try{C=await so(s,{muteMutationObserver:S})}catch(e){console.warn(`[PLOS] could not start live highlight terms`,e)}let w=Rn({onClick(e,t){T(e,t)}});function T(e,t){let n=u.canonicalProductUrl(e)??e,r=u.detectsAsSponsored?.(e)??!1;w.hide(),Lr({initialUrl:n,projectId:s,projectName:b,platform:u.platform,triggerRect:t,defaultIsSponsoredAd:r,onSaved(e){let t=An(u.canonicalProductUrl(e.url)??e.url);t&&d.add(t),E()},onClose(){}})}function E(){let e=document.querySelectorAll(`a[href]`),t=new Set;document.querySelectorAll(`a[data-plos-cs-has-icon="1"]`).forEach(e=>{let n=An(u.canonicalProductUrl(e.href)??e.href);n&&t.add(n)});for(let n of e){let e=n.href;if(!u.matchesProduct(e))continue;let r=An(u.canonicalProductUrl(e)??e);r&&d.has(r)&&!t.has(r)&&(Vn(n,r),t.add(r)),n.getAttribute(co)!==`1`&&(n.setAttribute(co,`1`),n.addEventListener(`mouseenter`,()=>{w.showFor(n,e)}),n.addEventListener(`mouseleave`,()=>{w.hide()}))}}let D=new Map,O=null,k=new Map,A=new Map,j=new Set;async function M(e){if(!D.has(e))try{let t=await m(s,e);D.set(e,t)}catch(t){console.warn(`[PLOS] could not load saved images for recognition`,t),D.set(e,[])}}function N(){if(O===null)return;let e=D.get(O);if(!e||e.length===0)return;let t=new Map;for(let n of e)n.originalSrcUrl&&t.set(n.originalSrcUrl,n);if(t.size===0)return;let n=new Set,r=document.querySelectorAll(`img`);for(let e of r){let r=t.get(e.currentSrc)??t.get(e.src)??null;if(!r||n.has(r.id))continue;let i=k.get(r.id);if(i&&i.imgEl===e)i.reposition();else{i&&(i.iconEl.remove(),k.delete(r.id));let t=Kn(e,r.id);t&&k.set(r.id,t)}n.add(r.id)}for(let[e,t]of Array.from(k.entries()))n.has(e)||(t.iconEl.remove(),k.delete(e))}function P(){for(let e of k.values())e.reposition()}function F(){Jn(),k.clear(),O=null}let I=new Map,L=new Map;async function R(e){if(!I.has(e))try{let t=await h(s,e);I.set(e,t)}catch(t){console.warn(`[PLOS] could not load saved videos for recognition`,t),I.set(e,[])}}function z(){if(O===null)return;let e=I.get(O);if(!e||e.length===0)return;let t=new Map;for(let n of e)n.originalSrcUrl&&t.set(n.originalSrcUrl,n);if(t.size===0)return;let n=new Set,r=document.querySelectorAll(`video`);for(let e of r){let r=t.get(e.currentSrc)??t.get(e.src)??null;if(!r||n.has(r.id))continue;let i=L.get(r.id);if(i&&i.targetEl===e)i.reposition();else{i&&(i.iconEl.remove(),L.delete(r.id));let t=$n(e,r.id);t&&L.set(r.id,t)}n.add(r.id)}let i=document.querySelectorAll(`iframe`);for(let e of i){let r=t.get(e.src)??null;if(!r||n.has(r.id))continue;let i=L.get(r.id);if(i&&i.targetEl===e)i.reposition();else{i&&(i.iconEl.remove(),L.delete(r.id));let t=$n(e,r.id);t&&L.set(r.id,t)}n.add(r.id)}for(let[e,t]of Array.from(L.entries()))n.has(e)||(t.iconEl.remove(),L.delete(e))}function B(){for(let e of L.values())e.reposition()}function V(){tr(),L.clear()}async function H(e){if(!A.has(e))try{let t=await g(s,e);A.set(e,t)}catch(t){console.warn(`[PLOS] could not load saved texts for haze`,t),A.set(e,[])}}function U(e){let t=A.get(e);if(!t||t.length===0)return;let n=new Set;for(let e of t){if(e.selector===null)continue;let t=dr(e.selector);if(t===null)continue;let r=Tr(t,document.body);r!==null&&(sr(r,e.id),n.add(e.id))}for(let e of Array.from(j))n.has(e)||(cr(e),j.delete(e));for(let e of n)j.add(e)}function W(){lr(),j.clear()}let G=null;function K(){if(G===location.href)return;G=location.href;let e=An(u.canonicalProductUrl(location.href)??location.href);if(!e){k.size>0&&F(),L.size>0&&V();return}if(!d.has(e)){k.size>0&&F(),L.size>0&&V(),j.size>0&&W();return}kr(b,{muteMutationObserver:S});let t=_.get(e)??null;if(t===null){k.size>0&&F(),L.size>0&&V(),j.size>0&&W();return}O!==t&&(Jn(),k.clear(),tr(),L.clear(),W(),O=t),M(t).then(()=>{O===t&&N()}),R(t).then(()=>{O===t&&z()}),H(t).then(()=>{O===t&&U(t)})}let q=null;function Y(){q!==null&&clearTimeout(q),q=setTimeout(()=>{q=null,K(),C!==null&&C.refresh()},uo)}let X=location.href;E(),Y();let Z=null;x=new MutationObserver(()=>{Z===null&&(Z=setTimeout(()=>{Z=null,E(),N(),z(),O!==null&&U(O),C!==null&&C.refresh(),location.href!==X&&(X=location.href,Y())},lo))}),x.observe(document.body,{childList:!0,subtree:!0});let Q=()=>{location.href!==X&&(X=location.href),Y()};window.addEventListener(`popstate`,Q);let te=()=>{P(),B()};window.addEventListener(`scroll`,te,{passive:!0,capture:!0}),window.addEventListener(`resize`,te,{passive:!0});let ne=(r,i,a)=>{if(Ra(r)){if(r.kind===`open-url-add-form`){T(r.href,null),a({ok:!0});return}if(r.kind===`open-text-capture-form`){let e=t;t=null,Zr({initialText:r.selectedText,pageUrl:r.pageUrl,projectId:s,projectName:b,platform:u.platform,selectorJson:e,onSaved(){},onClose(){}}),a({ok:!0});return}if(r.kind===`open-image-capture-form`){let t=r.srcUrl||e||``;if(!t){a({ok:!1,reason:`no-image-found`});return}di({srcUrl:t,pageUrl:r.pageUrl,projectId:s,projectName:b,platform:u.platform,onSaved(){},onClose(){}}),a({ok:!0});return}if(r.kind===`open-video-capture-form`){let e=n;n=null;let t=e??{kind:`none`};if(t.kind===`none`){$(`Couldn't find a video to capture at that spot. Try right-clicking directly on the video player.`),a({ok:!1,reason:`no-video-found`});return}t.kind===`direct`?Oi({kind:`direct`,src:t.src,mimeTypeHint:t.mimeType,element:t.element,pageUrl:r.pageUrl,projectId:s,projectName:b,platform:u.platform,onSaved(){},onClose(){}}):Oi({kind:`embed`,src:t.src,embedPlatform:t.platform,pageUrl:r.pageUrl,projectId:s,projectName:b,platform:u.platform,onSaved(){},onClose(){}}),a({ok:!0});return}if(r.kind===`enter-video-region-record-mode`){let e=r.pageUrl,t=ea({onRegionPicked(n){t.destroy();let r=Sa(),i=pa({region:n,onStopClicked(){r.stop()},onCancelClicked(){r.cancel()}});r.start({region:n,onStarted(){i.setRecording()},onTick(e){i.setElapsed(e)},onStopped(t){i.destroy(),Oi({kind:`screen-recording`,blob:t.blob,mimeType:t.mimeType,durationSeconds:t.durationSeconds,width:t.region.width,height:t.region.height,pageUrl:e,projectId:s,projectName:b,platform:u.platform,onSaved(){},onClose(){}})},onCanceled(e,t){i.destroy(),e===`dialog-dismissed`?$(`Recording cancelled. You can try again any time.`):e===`recorder-error`&&$(`Recording stopped due to an error — the partial recording was discarded.`)}})},onCancel(e){t.destroy()}});a({ok:!0});return}if(r.kind===`enter-region-screenshot-mode`){let e=r.pageUrl,t=Gi({onCaptured(n){t.destroy(),di({srcUrl:n,pageUrl:e,projectId:s,projectName:b,platform:u.platform,sourceType:`region-screenshot`,onSaved(){},onClose(){}})},onCancel(e){t.destroy()},onError(e){t.destroy()}});a({ok:!0});return}if(r.kind===`start-review-scrape`){let e=r.pageUrl;if(ee(e)){let t=v.find(t=>ie(e,t.url));if(!t){$(`Couldn't find a saved Competitor URL for this Amazon product. Open the product page first and click + Add to save it, then come back here and re-run the scrape.`),a({ok:!1});return}let n=re(e);if(!n){$(`Couldn't read the product code from this Amazon page. Try refreshing and re-running.`),a({ok:!1});return}let r=t,i=r.productName,o={scopeLabel:i?`Amazon reviews — ${i}`:`Amazon reviews`,defaultCapPerStar:r.reviewScrapeCap&&r.reviewScrapeCap>0?r.reviewScrapeCap:200};rn(o).then(e=>{if(e===null)return;let t=[];for(let n of e.selectedStars){let e=J(n);e&&t.push(e)}de({projectId:s,competitorUrlId:r.id,asin:n,capPerStar:e.capPerStar,starsToVisit:t,scopeLabel:o.scopeLabel,async saveReview(e){await y(s,r.id,{clientId:e.clientId,starRating:e.starRating,title:e.title??void 0,body:e.body,reviewerName:e.reviewerName??void 0,reviewDate:e.reviewDate??void 0,helpfulCount:e.helpfulCount??void 0,platform:e.platform,source:e.source})}}).catch(e=>{console.error(`[PLOS] Amazon review scrape failed:`,e)})}),a({ok:!0});return}if(De(e)){let t=v.find(t=>Me(e,t.url));if(!t){$(`Couldn't find a saved Competitor URL for this eBay listing. Open the listing page first and click + Add to save it, then come back here and re-run the scrape.`),a({ok:!1});return}let n=Ae(e);if(!n){$(`Couldn't read the item ID from this eBay page. Try refreshing and re-running.`),a({ok:!1});return}let r=t,i=r.productName;(async()=>{let t=null;if(Ee(e)&&(t=je(e)),!t)try{let e=await fetch(we(n),{credentials:`include`,headers:{Accept:`text/html`}});if(e.ok){let n=await e.text();t=Re(n),t||=ze(new DOMParser().parseFromString(n,`text/html`))}}catch(e){console.warn(`[PLOS] eBay seller-resolve fetch failed:`,e)}let a={scopeLabel:i?`eBay feedback — ${i}`:`eBay feedback`,defaultCapPerStar:r.reviewScrapeCap&&r.reviewScrapeCap>0?r.reviewScrapeCap:200,selectableStars:[1,3],defaultSelectedStars:[1,3],sellerInput:{label:`eBay seller username`,defaultValue:t??``,placeholder:`e.g. hot.girls`,hint:t?`Auto-detected from this page — edit if wrong.`:"Couldn't auto-detect from the listing page DOM — paste from the seller's feedback page URL (the `username=…` part)."}};rn(a).then(e=>{if(e===null)return;let t=e.seller?.trim();if(!t){$(`Enter the eBay seller name and try again.`);return}let i=[];for(let t of e.selectedStars){let e=Se(t);e&&i.push(e)}if(i.length===0){$(`Pick at least one feedback type (Neutral or Negative) to scrape.`);return}let o=t;Ve({projectId:s,competitorUrlId:r.id,itemId:n,seller:o,capPerFilter:e.capPerStar,filtersToVisit:i,scopeLabel:a.scopeLabel,async saveReview(e){await y(s,r.id,{clientId:e.clientId,starRating:e.starRating,title:e.title??void 0,body:e.body,reviewerName:e.reviewerName??void 0,reviewDate:e.reviewDate??void 0,helpfulCount:e.helpfulCount??void 0,platform:e.platform,source:e.source})}}).catch(e=>{console.error(`[PLOS] eBay review scrape failed:`,e)})})})(),a({ok:!0});return}if(tt(e)){let t=v.find(t=>it(e,t.url));if(!t){$(`Couldn't find a saved Competitor URL for this Etsy listing. Open the listing page first and click + Add to save it, then come back here and re-run the scrape.`),a({ok:!1});return}let n=rt(e);if(!n){$(`Couldn't read the listing ID from this Etsy page. Try refreshing and re-running.`),a({ok:!1});return}let r=t,i=r.productName,o={scopeLabel:i?`Etsy reviews — ${i}`:`Etsy reviews`,defaultCapPerStar:r.reviewScrapeCap&&r.reviewScrapeCap>0?r.reviewScrapeCap:200,selectableStars:[...Ze],defaultSelectedStars:[...Qe]};rn(o).then(e=>{if(e===null)return;let t=[];for(let n of e.selectedStars)$e(n)&&t.push(n);if(t.length===0){$(`Pick at least one star rating to scrape.`);return}yt({projectId:s,competitorUrlId:r.id,listingId:n,capPerStar:e.capPerStar,starsToVisit:t,scopeLabel:o.scopeLabel,async saveReview(e){await y(s,r.id,{clientId:e.clientId,starRating:e.starRating,title:e.title??void 0,body:e.body,reviewerName:e.reviewerName??void 0,reviewDate:e.reviewDate??void 0,helpfulCount:e.helpfulCount??void 0,platform:e.platform,source:e.source})}}).catch(e=>{console.error(`[PLOS] Etsy review scrape failed:`,e)})}),a({ok:!0});return}if(Lt(e)){let t=v.find(t=>Vt(e,t.url));if(!t){$(`Couldn't find a saved Competitor URL for this Walmart product. Open the product page first and click + Add to save it, then come back here and re-run the scrape.`),a({ok:!1});return}let n=Bt(e);if(!n){$(`Couldn't read the product ID from this Walmart page. Try refreshing and re-running.`),a({ok:!1});return}let r=t,i=r.productName,o={scopeLabel:i?`Walmart reviews — ${i}`:`Walmart reviews`,defaultCapPerStar:r.reviewScrapeCap&&r.reviewScrapeCap>0?r.reviewScrapeCap:200,selectableStars:[...Mt],defaultSelectedStars:[...Nt]};rn(o).then(e=>{if(e===null)return;let t=[];for(let n of e.selectedStars)Pt(n)&&t.push(n);if(t.length===0){$(`Pick at least one star rating to scrape.`);return}Zt({projectId:s,competitorUrlId:r.id,productId:n,capPerStar:e.capPerStar,starsToVisit:t,scopeLabel:o.scopeLabel,async saveReview(e){await y(s,r.id,{clientId:e.clientId,starRating:e.starRating,title:e.title??void 0,body:e.body,reviewerName:e.reviewerName??void 0,reviewDate:e.reviewDate??void 0,helpfulCount:e.helpfulCount??void 0,platform:e.platform,source:e.source})}}).catch(e=>{console.error(`[PLOS] Walmart review scrape failed:`,e)})}),a({ok:!0});return}$(`Review scraping is currently available on Amazon, eBay, Etsy, and Walmart product pages. This page isn’t one of those.`),a({ok:!1});return}}};return chrome.runtime.onMessage.addListener(ne),function(){x?.disconnect(),x=null,window.removeEventListener(`popstate`,Q),window.removeEventListener(`scroll`,te,{capture:!0}),window.removeEventListener(`resize`,te),i(),chrome.runtime.onMessage.removeListener(ne),w.destroy(),Hn(),F(),D.clear(),V(),I.clear(),W(),A.clear(),C!==null&&(C.destroy(),C=null),q!==null&&(clearTimeout(q),q=null),Z!==null&&(clearTimeout(Z),Z=null),mo()}}function mo(){document.body.removeAttribute(fo)}var ho=l({matches:[`https://*.amazon.com/*`,`https://*.ebay.com/*`,`https://*.etsy.com/*`,`https://*.walmart.com/*`],runAt:`document_idle`,async main(e){let t=await po();e.onInvalidated(t)}}),go={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},_o=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,vo=class e extends Event{static EVENT_NAME=yo(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function yo(e){return`${_o?.runtime?.id}:content:${e}`}var bo=typeof globalThis.navigation?.addEventListener==`function`;function xo(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),bo?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new vo(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new vo(e,t)),t=e)},1e3))}}}var So=class e{static SCRIPT_STARTED_MESSAGE_TYPE=yo(`wxt:content-script-started`);id;abortController;locationWatcher=xo(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return _o.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?yo(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),go.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},Co={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=ho;return await e(new So(`content`,t))}catch(e){throw Co.error(`The content script "content" crashed on startup!`,e),e}})()})();
content;